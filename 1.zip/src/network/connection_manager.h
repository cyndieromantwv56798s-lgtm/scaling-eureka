#pragma once

#include <string>
#include <map>
#include <vector>
#include <memory>
#include <mutex>
#include <atomic>
#include <chrono>
#include <set>

namespace kotana {

enum class ConnectionState {
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
    DISCONNECTED,
    FAILED
};

struct Connection {
    std::string id;
    std::string client_address;
    uint16_t client_port;
    ConnectionState state;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point last_activity;
    uint64_t bytes_sent;
    uint64_t bytes_received;
    uint64_t requests_handled;
    bool is_authenticated;
    std::string username;
    
    Connection();
    bool isActive() const;
    std::chrono::seconds getIdleTime() const;
};

struct ConnectionPoolConfig {
    size_t max_connections;
    size_t min_connections;
    std::chrono::seconds idle_timeout;
    std::chrono::seconds connection_timeout;
    bool enable_keepalive;
    std::chrono::seconds keepalive_interval;
    
    ConnectionPoolConfig();
};

struct ConnectionStats {
    size_t total_connections;
    size_t active_connections;
    size_t idle_connections;
    size_t failed_connections;
    uint64_t total_bytes_sent;
    uint64_t total_bytes_received;
    double avg_requests_per_connection;
    std::chrono::milliseconds avg_connection_duration;
    
    ConnectionStats();
};

class ConnectionManager {
public:
    explicit ConnectionManager(const ConnectionPoolConfig& config);
    ~ConnectionManager();
    
    bool start();
    void stop();
    bool isRunning() const;
    
    std::string createConnection(const std::string& client_address, uint16_t client_port);
    bool closeConnection(const std::string& connection_id);
    bool closeAllConnections();
    
    Connection* getConnection(const std::string& connection_id);
    std::vector<Connection> getActiveConnections();
    std::vector<Connection> getIdleConnections();
    std::vector<Connection> getAllConnections();
    
    bool updateConnectionActivity(const std::string& connection_id);
    bool recordRequest(const std::string& connection_id, size_t bytes_sent, size_t bytes_received);
    bool authenticateConnection(const std::string& connection_id, const std::string& username);
    
    ConnectionStats getStats();
    void resetStats();
    
    void setConfig(const ConnectionPoolConfig& config);
    ConnectionPoolConfig getConfig() const;
    
    size_t getConnectionCount() const;
    size_t getActiveCount() const;
    size_t getIdleCount() const;
    
    void closeIdleConnections();
    void closeFailedConnections();

private:
    void maintenanceLoop();
    void keepaliveLoop();
    void cleanupExpiredConnections();
    void sendKeepalive(Connection& conn);
    
    std::string generateConnectionId();
    
    ConnectionPoolConfig config_;
    std::map<std::string, Connection> connections_;
    ConnectionStats stats_;
    
    std::atomic<bool> running_;
    mutable std::mutex connection_mutex_;
    
    std::thread maintenance_thread_;
    std::thread keepalive_thread_;
};

} // namespace kotana
