#pragma once

#include "core/cluster.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <atomic>
#include <chrono>
#include <deque>

namespace kotana {

enum class LoadBalancingStrategy {
    ROUND_ROBIN,
    LEAST_CONNECTIONS,
    LEAST_RESPONSE_TIME,
    WEIGHTED_ROUND_ROBIN,
    CONSISTENT_HASHING,
    RANDOM,
    IP_HASH
};

struct BackendServer {
    std::string id;
    std::string address;
    uint16_t port;
    double weight;
    bool is_healthy;
    uint64_t active_connections;
    std::chrono::microseconds avg_response_time;
    std::chrono::system_clock::time_point last_health_check;
    uint64_t total_requests;
    uint64_t failed_requests;
    
    BackendServer();
    BackendServer(const std::string& server_id, const std::string& addr, uint16_t p);
};

struct LoadBalancerStats {
    uint64_t total_requests;
    uint64_t total_failures;
    uint64_t active_connections;
    std::map<std::string, uint64_t> requests_per_server;
    std::map<std::string, std::chrono::microseconds> avg_response_times;
    double overall_success_rate;
    std::chrono::microseconds avg_response_time;
    
    LoadBalancerStats();
};

struct HealthCheckConfig {
    std::chrono::seconds interval;
    std::chrono::milliseconds timeout;
    uint32_t max_retries;
    std::string health_check_path;
    bool enabled;
    
    HealthCheckConfig();
};

class LoadBalancer {
public:
    explicit LoadBalancer(LoadBalancingStrategy strategy = LoadBalancingStrategy::ROUND_ROBIN);
    ~LoadBalancer();
    
    bool start();
    void stop();
    bool isRunning() const;
    
    bool addServer(const BackendServer& server);
    bool removeServer(const std::string& server_id);
    bool updateServerWeight(const std::string& server_id, double weight);
    bool markServerUnhealthy(const std::string& server_id);
    bool markServerHealthy(const std::string& server_id);
    
    BackendServer* selectServer(const std::string& client_id = "");
    void recordRequest(const std::string& server_id, std::chrono::microseconds response_time, bool success);
    void releaseConnection(const std::string& server_id);
    
    std::vector<BackendServer> getHealthyServers();
    std::vector<BackendServer> getAllServers();
    BackendServer* getServer(const std::string& server_id);
    
    void setStrategy(LoadBalancingStrategy strategy);
    LoadBalancingStrategy getStrategy() const;
    
    void setHealthCheckConfig(const HealthCheckConfig& config);
    HealthCheckConfig getHealthCheckConfig() const;
    
    LoadBalancerStats getStats();
    void resetStats();
    
    void enableStickySessions(bool enable);
    void setSessionTimeout(std::chrono::seconds timeout);
    
private:
    BackendServer* selectRoundRobin();
    BackendServer* selectLeastConnections();
    BackendServer* selectLeastResponseTime();
    BackendServer* selectWeightedRoundRobin();
    BackendServer* selectConsistentHashing(const std::string& client_id);
    BackendServer* selectRandom();
    BackendServer* selectIPHash(const std::string& client_ip);
    
    void healthCheckLoop();
    bool performHealthCheck(BackendServer& server);
    void updateServerMetrics();
    
    std::map<std::string, BackendServer> servers_;
    LoadBalancingStrategy strategy_;
    
    std::mutex lb_mutex_;
    std::atomic<bool> running_;
    std::thread health_check_thread_;
    
    size_t round_robin_index_;
    HealthCheckConfig health_check_config_;
    LoadBalancerStats stats_;
    
    bool sticky_sessions_;
    std::chrono::seconds session_timeout_;
    std::map<std::string, std::string> session_to_server_;
    std::map<std::string, std::chrono::system_clock::time_point> session_timestamps_;
};

} // namespace kotana
