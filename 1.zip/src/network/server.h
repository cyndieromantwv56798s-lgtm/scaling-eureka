#pragma once

#include "protocol.h"
#include "query/executor.h"
#include "storage/storage_engine.h"
#include <memory>
#include <thread>
#include <vector>
#include <atomic>

namespace kotana {

class Server {
public:
    struct Config {
        std::string host;
        uint16_t port;
        size_t num_threads;
        size_t max_connections;
        
        Config() : host("0.0.0.0"), port(9042), 
                  num_threads(std::thread::hardware_concurrency()), max_connections(1000) {}
    };
    
    explicit Server(std::shared_ptr<StorageEngine> storage);
    explicit Server(std::shared_ptr<StorageEngine> storage, const Config& config);
    ~Server();
    
    bool start();
    void stop();
    bool isRunning() const;
    const Config& config() const;

private:
    void acceptLoop();
    void workerThread();
    void handleClient(int client_fd);
    Message processMessage(const Message& request);
    std::string formatResult(const QueryResult& result);
    
    std::shared_ptr<StorageEngine> storage_;
    std::shared_ptr<QueryExecutor> executor_;
    Config config_;
    
    std::atomic<bool> running_;
    int server_fd_;
    
    std::thread accept_thread_;
    std::vector<std::thread> worker_threads_;
};

} // namespace kotana
