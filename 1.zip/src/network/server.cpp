#include "server.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include <sstream>

namespace kotana {

Server::Server(std::shared_ptr<StorageEngine> storage)
    : Server(storage, Config()) {}

Server::Server(std::shared_ptr<StorageEngine> storage, const Config& config)
    : storage_(storage),
      executor_(std::make_shared<QueryExecutor>(storage)),
      config_(config),
      running_(false),
      server_fd_(-1) {}

Server::~Server() {
    stop();
}

bool Server::start() {
    if (running_.exchange(true)) {
        return false;
    }
    
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ < 0) {
        std::cerr << "Failed to create socket\n";
        running_ = false;
        return false;
    }
    
    int opt = 1;
    if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        std::cerr << "Failed to set socket options\n";
        close(server_fd_);
        running_ = false;
        return false;
    }
    
    struct sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(config_.port);
    
    if (bind(server_fd_, (struct sockaddr*)&address, sizeof(address)) < 0) {
        std::cerr << "Failed to bind to port " << config_.port << "\n";
        close(server_fd_);
        running_ = false;
        return false;
    }
    
    if (listen(server_fd_, 128) < 0) {
        std::cerr << "Failed to listen on socket\n";
        close(server_fd_);
        running_ = false;
        return false;
    }
    
    std::cout << "Kotosploit Kotana server listening on " 
              << config_.host << ":" << config_.port << "\n";
    
    for (size_t i = 0; i < config_.num_threads; ++i) {
        worker_threads_.emplace_back(&Server::workerThread, this);
    }
    
    accept_thread_ = std::thread(&Server::acceptLoop, this);
    
    return true;
}

void Server::stop() {
    if (!running_.exchange(false)) {
        return;
    }
    
    if (server_fd_ >= 0) {
        close(server_fd_);
        server_fd_ = -1;
    }
    
    if (accept_thread_.joinable()) {
        accept_thread_.join();
    }
    
    for (auto& thread : worker_threads_) {
        if (thread.joinable()) {
            thread.join();
        }
    }
}

bool Server::isRunning() const {
    return running_.load();
}

const Server::Config& Server::config() const {
    return config_;
}

void Server::acceptLoop() {
    while (running_) {
        struct sockaddr_in client_addr;
        socklen_t addr_len = sizeof(client_addr);
        
        int client_fd = accept(server_fd_, (struct sockaddr*)&client_addr, &addr_len);
        
        if (client_fd < 0) {
            if (running_) {
                std::cerr << "Failed to accept connection\n";
            }
            continue;
        }
        
        std::thread(&Server::handleClient, this, client_fd).detach();
    }
}

void Server::workerThread() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void Server::handleClient(int client_fd) {
    std::vector<uint8_t> buffer(8192);
    
    while (running_) {
        ssize_t bytes_read = recv(client_fd, buffer.data(), buffer.size(), 0);
        
        if (bytes_read <= 0) {
            break;
        }
        
        try {
            Message request = Message::deserialize(buffer.data(), bytes_read);
            Message response = processMessage(request);
            
            auto response_data = response.serialize();
            send(client_fd, response_data.data(), response_data.size(), 0);
            
        } catch (const std::exception& e) {
            Message error = Message::createError(e.what());
            auto error_data = error.serialize();
            send(client_fd, error_data.data(), error_data.size(), 0);
        }
    }
    
    close(client_fd);
}

Message Server::processMessage(const Message& request) {
    switch (request.type) {
        case MessageType::QUERY_REQUEST: {
            std::string query = request.payloadAsString();
            QueryResult result = executor_->execute(query);
            
            if (result.success) {
                std::string response = formatResult(result);
                return Message::createResponse(response);
            } else {
                return Message::createError(result.error_message);
            }
        }
        
        case MessageType::PING:
            return Message::createPong();
        
        default:
            return Message::createError("Unknown message type");
    }
}

std::string Server::formatResult(const QueryResult& result) {
    std::ostringstream oss;
    
    if (result.rows.empty()) {
        oss << "OK (" << result.rows_affected << " rows affected)";
    } else {
        oss << "Result (" << result.rows.size() << " rows):\n";
        
        for (const auto& row : result.rows) {
            oss << "{ ";
            bool first = true;
            for (const auto& [col_name, value] : row.columns()) {
                if (!first) oss << ", ";
                oss << col_name << ": " << value.toString();
                first = false;
            }
            oss << " }\n";
        }
    }
    
    return oss.str();
}

} // namespace kotana
