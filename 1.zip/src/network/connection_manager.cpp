#include "connection_manager.h"
#include <algorithm>
#include <random>
#include <sstream>
#include <thread>

namespace kotana {

Connection::Connection()
    : client_port(0),
      state(ConnectionState::DISCONNECTED),
      created_at(std::chrono::system_clock::now()),
      last_activity(std::chrono::system_clock::now()),
      bytes_sent(0),
      bytes_received(0),
      requests_handled(0),
      is_authenticated(false) {}

bool Connection::isActive() const {
    return state == ConnectionState::CONNECTED && 
           std::chrono::duration_cast<std::chrono::seconds>(
               std::chrono::system_clock::now() - last_activity).count() < 300;
}

std::chrono::seconds Connection::getIdleTime() const {
    return std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now() - last_activity);
}

ConnectionPoolConfig::ConnectionPoolConfig()
    : max_connections(1000),
      min_connections(10),
      idle_timeout(std::chrono::seconds(300)),
      connection_timeout(std::chrono::seconds(30)),
      enable_keepalive(true),
      keepalive_interval(std::chrono::seconds(60)) {}

ConnectionStats::ConnectionStats()
    : total_connections(0),
      active_connections(0),
      idle_connections(0),
      failed_connections(0),
      total_bytes_sent(0),
      total_bytes_received(0),
      avg_requests_per_connection(0.0),
      avg_connection_duration(0) {}

ConnectionManager::ConnectionManager(const ConnectionPoolConfig& config)
    : config_(config), running_(false) {}

ConnectionManager::~ConnectionManager() {
    stop();
}

bool ConnectionManager::start() {
    if (running_.exchange(true)) {
        return false;
    }
    
    maintenance_thread_ = std::thread(&ConnectionManager::maintenanceLoop, this);
    
    if (config_.enable_keepalive) {
        keepalive_thread_ = std::thread(&ConnectionManager::keepaliveLoop, this);
    }
    
    return true;
}

void ConnectionManager::stop() {
    if (!running_.exchange(false)) {
        return;
    }
    
    if (maintenance_thread_.joinable()) {
        maintenance_thread_.join();
    }
    if (keepalive_thread_.joinable()) {
        keepalive_thread_.join();
    }
    
    closeAllConnections();
}

bool ConnectionManager::isRunning() const {
    return running_.load();
}

std::string ConnectionManager::createConnection(const std::string& client_address, uint16_t client_port) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    if (connections_.size() >= config_.max_connections) {
        return "";
    }
    
    Connection conn;
    conn.id = generateConnectionId();
    conn.client_address = client_address;
    conn.client_port = client_port;
    conn.state = ConnectionState::CONNECTED;
    conn.created_at = std::chrono::system_clock::now();
    conn.last_activity = conn.created_at;
    
    connections_[conn.id] = conn;
    stats_.total_connections++;
    stats_.active_connections++;
    
    return conn.id;
}

bool ConnectionManager::closeConnection(const std::string& connection_id) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto it = connections_.find(connection_id);
    if (it == connections_.end()) {
        return false;
    }
    
    it->second.state = ConnectionState::DISCONNECTED;
    
    if (stats_.active_connections > 0) {
        stats_.active_connections--;
    }
    
    connections_.erase(it);
    
    return true;
}

bool ConnectionManager::closeAllConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    for (auto& [id, conn] : connections_) {
        conn.state = ConnectionState::DISCONNECTED;
    }
    
    connections_.clear();
    stats_.active_connections = 0;
    stats_.idle_connections = 0;
    
    return true;
}

Connection* ConnectionManager::getConnection(const std::string& connection_id) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto it = connections_.find(connection_id);
    if (it == connections_.end()) {
        return nullptr;
    }
    
    return &it->second;
}

std::vector<Connection> ConnectionManager::getActiveConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    std::vector<Connection> active;
    for (const auto& [id, conn] : connections_) {
        if (conn.isActive()) {
            active.push_back(conn);
        }
    }
    return active;
}

std::vector<Connection> ConnectionManager::getIdleConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    std::vector<Connection> idle;
    for (const auto& [id, conn] : connections_) {
        if (!conn.isActive() && conn.state == ConnectionState::CONNECTED) {
            idle.push_back(conn);
        }
    }
    return idle;
}

std::vector<Connection> ConnectionManager::getAllConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    std::vector<Connection> all;
    for (const auto& [id, conn] : connections_) {
        all.push_back(conn);
    }
    return all;
}

bool ConnectionManager::updateConnectionActivity(const std::string& connection_id) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto it = connections_.find(connection_id);
    if (it == connections_.end()) {
        return false;
    }
    
    it->second.last_activity = std::chrono::system_clock::now();
    return true;
}

bool ConnectionManager::recordRequest(const std::string& connection_id, 
                                     size_t bytes_sent, size_t bytes_received) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto it = connections_.find(connection_id);
    if (it == connections_.end()) {
        return false;
    }
    
    it->second.bytes_sent += bytes_sent;
    it->second.bytes_received += bytes_received;
    it->second.requests_handled++;
    it->second.last_activity = std::chrono::system_clock::now();
    
    stats_.total_bytes_sent += bytes_sent;
    stats_.total_bytes_received += bytes_received;
    
    return true;
}

bool ConnectionManager::authenticateConnection(const std::string& connection_id, 
                                               const std::string& username) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto it = connections_.find(connection_id);
    if (it == connections_.end()) {
        return false;
    }
    
    it->second.is_authenticated = true;
    it->second.username = username;
    
    return true;
}

ConnectionStats ConnectionManager::getStats() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    stats_.active_connections = 0;
    stats_.idle_connections = 0;
    stats_.failed_connections = 0;
    
    uint64_t total_requests = 0;
    std::chrono::milliseconds total_duration(0);
    
    for (const auto& [id, conn] : connections_) {
        if (conn.isActive()) {
            stats_.active_connections++;
        } else if (conn.state == ConnectionState::CONNECTED) {
            stats_.idle_connections++;
        } else if (conn.state == ConnectionState::FAILED) {
            stats_.failed_connections++;
        }
        
        total_requests += conn.requests_handled;
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            conn.last_activity - conn.created_at);
        total_duration += duration;
    }
    
    if (!connections_.empty()) {
        stats_.avg_requests_per_connection = static_cast<double>(total_requests) / connections_.size();
        stats_.avg_connection_duration = std::chrono::milliseconds(
            total_duration.count() / connections_.size());
    }
    
    return stats_;
}

void ConnectionManager::resetStats() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    stats_ = ConnectionStats();
}

void ConnectionManager::setConfig(const ConnectionPoolConfig& config) {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    config_ = config;
}

ConnectionPoolConfig ConnectionManager::getConfig() const {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    return config_;
}

size_t ConnectionManager::getConnectionCount() const {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    return connections_.size();
}

size_t ConnectionManager::getActiveCount() const {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    size_t count = 0;
    for (const auto& [id, conn] : connections_) {
        if (conn.isActive()) {
            count++;
        }
    }
    return count;
}

size_t ConnectionManager::getIdleCount() const {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    size_t count = 0;
    for (const auto& [id, conn] : connections_) {
        if (!conn.isActive() && conn.state == ConnectionState::CONNECTED) {
            count++;
        }
    }
    return count;
}

void ConnectionManager::closeIdleConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    std::vector<std::string> to_close;
    for (const auto& [id, conn] : connections_) {
        if (!conn.isActive() && conn.getIdleTime() > config_.idle_timeout) {
            to_close.push_back(id);
        }
    }
    
    for (const auto& id : to_close) {
        connections_.erase(id);
        if (stats_.active_connections > 0) {
            stats_.active_connections--;
        }
    }
}

void ConnectionManager::closeFailedConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    std::vector<std::string> to_close;
    for (const auto& [id, conn] : connections_) {
        if (conn.state == ConnectionState::FAILED) {
            to_close.push_back(id);
        }
    }
    
    for (const auto& id : to_close) {
        connections_.erase(id);
    }
}

void ConnectionManager::maintenanceLoop() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        
        cleanupExpiredConnections();
        closeIdleConnections();
        closeFailedConnections();
    }
}

void ConnectionManager::keepaliveLoop() {
    while (running_) {
        std::this_thread::sleep_for(config_.keepalive_interval);
        
        std::lock_guard<std::mutex> lock(connection_mutex_);
        for (auto& [id, conn] : connections_) {
            if (conn.state == ConnectionState::CONNECTED) {
                sendKeepalive(conn);
            }
        }
    }
}

void ConnectionManager::cleanupExpiredConnections() {
    std::lock_guard<std::mutex> lock(connection_mutex_);
    
    auto now = std::chrono::system_clock::now();
    std::vector<std::string> expired;
    
    for (const auto& [id, conn] : connections_) {
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(
            now - conn.last_activity);
        
        if (elapsed > config_.idle_timeout) {
            expired.push_back(id);
        }
    }
    
    for (const auto& id : expired) {
        connections_.erase(id);
        if (stats_.active_connections > 0) {
            stats_.active_connections--;
        }
    }
}

void ConnectionManager::sendKeepalive(Connection& conn) {
    conn.last_activity = std::chrono::system_clock::now();
}

std::string ConnectionManager::generateConnectionId() {
    static std::random_device rd;
    static std::mt19937_64 gen(rd());
    static std::uniform_int_distribution<uint64_t> dis;
    
    auto now = std::chrono::system_clock::now();
    auto timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count();
    
    std::stringstream ss;
    ss << "conn_" << timestamp << "_" << std::hex << dis(gen);
    return ss.str();
}

} // namespace kotana
