#include "load_balancer.h"
#include <algorithm>
#include <random>
#include <numeric>
#include <cmath>

namespace kotana {

BackendServer::BackendServer()
    : port(0),
      weight(1.0),
      is_healthy(true),
      active_connections(0),
      avg_response_time(0),
      last_health_check(std::chrono::system_clock::now()),
      total_requests(0),
      failed_requests(0) {}

BackendServer::BackendServer(const std::string& server_id, const std::string& addr, uint16_t p)
    : id(server_id),
      address(addr),
      port(p),
      weight(1.0),
      is_healthy(true),
      active_connections(0),
      avg_response_time(0),
      last_health_check(std::chrono::system_clock::now()),
      total_requests(0),
      failed_requests(0) {}

LoadBalancerStats::LoadBalancerStats()
    : total_requests(0),
      total_failures(0),
      active_connections(0),
      overall_success_rate(100.0),
      avg_response_time(0) {}

HealthCheckConfig::HealthCheckConfig()
    : interval(10),
      timeout(std::chrono::milliseconds(2000)),
      max_retries(3),
      health_check_path("/health"),
      enabled(true) {}

LoadBalancer::LoadBalancer(LoadBalancingStrategy strategy)
    : strategy_(strategy),
      running_(false),
      round_robin_index_(0),
      sticky_sessions_(false),
      session_timeout_(std::chrono::seconds(3600)) {}

LoadBalancer::~LoadBalancer() {
    stop();
}

bool LoadBalancer::start() {
    if (running_.exchange(true)) {
        return false;
    }
    
    if (health_check_config_.enabled) {
        health_check_thread_ = std::thread(&LoadBalancer::healthCheckLoop, this);
    }
    
    return true;
}

void LoadBalancer::stop() {
    if (!running_.exchange(false)) {
        return;
    }
    
    if (health_check_thread_.joinable()) {
        health_check_thread_.join();
    }
}

bool LoadBalancer::isRunning() const {
    return running_.load();
}

bool LoadBalancer::addServer(const BackendServer& server) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    if (servers_.find(server.id) != servers_.end()) {
        return false;
    }
    
    servers_[server.id] = server;
    return true;
}

bool LoadBalancer::removeServer(const std::string& server_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return false;
    }
    
    for (auto session_it = session_to_server_.begin(); session_it != session_to_server_.end();) {
        if (session_it->second == server_id) {
            session_it = session_to_server_.erase(session_it);
        } else {
            ++session_it;
        }
    }
    
    servers_.erase(it);
    return true;
}

bool LoadBalancer::updateServerWeight(const std::string& server_id, double weight) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return false;
    }
    
    it->second.weight = std::max(0.1, std::min(10.0, weight));
    return true;
}

bool LoadBalancer::markServerUnhealthy(const std::string& server_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return false;
    }
    
    it->second.is_healthy = false;
    return true;
}

bool LoadBalancer::markServerHealthy(const std::string& server_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return false;
    }
    
    it->second.is_healthy = true;
    return true;
}

BackendServer* LoadBalancer::selectServer(const std::string& client_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    if (sticky_sessions_ && !client_id.empty()) {
        auto it = session_to_server_.find(client_id);
        if (it != session_to_server_.end()) {
            auto server_it = servers_.find(it->second);
            if (server_it != servers_.end() && server_it->second.is_healthy) {
                session_timestamps_[client_id] = std::chrono::system_clock::now();
                return &server_it->second;
            }
        }
    }
    
    BackendServer* selected = nullptr;
    
    switch (strategy_) {
        case LoadBalancingStrategy::ROUND_ROBIN:
            selected = selectRoundRobin();
            break;
        case LoadBalancingStrategy::LEAST_CONNECTIONS:
            selected = selectLeastConnections();
            break;
        case LoadBalancingStrategy::LEAST_RESPONSE_TIME:
            selected = selectLeastResponseTime();
            break;
        case LoadBalancingStrategy::WEIGHTED_ROUND_ROBIN:
            selected = selectWeightedRoundRobin();
            break;
        case LoadBalancingStrategy::CONSISTENT_HASHING:
            selected = selectConsistentHashing(client_id);
            break;
        case LoadBalancingStrategy::RANDOM:
            selected = selectRandom();
            break;
        case LoadBalancingStrategy::IP_HASH:
            selected = selectIPHash(client_id);
            break;
    }
    
    if (selected && sticky_sessions_ && !client_id.empty()) {
        session_to_server_[client_id] = selected->id;
        session_timestamps_[client_id] = std::chrono::system_clock::now();
    }
    
    if (selected) {
        selected->active_connections++;
        stats_.active_connections++;
    }
    
    return selected;
}

void LoadBalancer::recordRequest(const std::string& server_id,
                                 std::chrono::microseconds response_time,
                                 bool success) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return;
    }
    
    it->second.total_requests++;
    if (!success) {
        it->second.failed_requests++;
        stats_.total_failures++;
    }
    
    auto& avg = it->second.avg_response_time;
    avg = std::chrono::microseconds(
        (avg.count() * (it->second.total_requests - 1) + response_time.count()) /
        it->second.total_requests
    );
    
    stats_.total_requests++;
    stats_.requests_per_server[server_id]++;
    stats_.avg_response_times[server_id] = it->second.avg_response_time;
    
    if (stats_.total_requests > 0) {
        stats_.overall_success_rate = 100.0 * 
            (1.0 - static_cast<double>(stats_.total_failures) / stats_.total_requests);
    }
}

void LoadBalancer::releaseConnection(const std::string& server_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it != servers_.end() && it->second.active_connections > 0) {
        it->second.active_connections--;
        if (stats_.active_connections > 0) {
            stats_.active_connections--;
        }
    }
}

std::vector<BackendServer> LoadBalancer::getHealthyServers() {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    std::vector<BackendServer> healthy;
    for (const auto& [id, server] : servers_) {
        if (server.is_healthy) {
            healthy.push_back(server);
        }
    }
    return healthy;
}

std::vector<BackendServer> LoadBalancer::getAllServers() {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    std::vector<BackendServer> all;
    for (const auto& [id, server] : servers_) {
        all.push_back(server);
    }
    return all;
}

BackendServer* LoadBalancer::getServer(const std::string& server_id) {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    
    auto it = servers_.find(server_id);
    if (it == servers_.end()) {
        return nullptr;
    }
    return &it->second;
}

void LoadBalancer::setStrategy(LoadBalancingStrategy strategy) {
    strategy_ = strategy;
}

LoadBalancingStrategy LoadBalancer::getStrategy() const {
    return strategy_;
}

void LoadBalancer::setHealthCheckConfig(const HealthCheckConfig& config) {
    health_check_config_ = config;
}

HealthCheckConfig LoadBalancer::getHealthCheckConfig() const {
    return health_check_config_;
}

LoadBalancerStats LoadBalancer::getStats() {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    return stats_;
}

void LoadBalancer::resetStats() {
    std::lock_guard<std::mutex> lock(lb_mutex_);
    stats_ = LoadBalancerStats();
}

void LoadBalancer::enableStickySessions(bool enable) {
    sticky_sessions_ = enable;
}

void LoadBalancer::setSessionTimeout(std::chrono::seconds timeout) {
    session_timeout_ = timeout;
}

BackendServer* LoadBalancer::selectRoundRobin() {
    auto healthy = getHealthyServers();
    if (healthy.empty()) {
        return nullptr;
    }
    
    size_t index = round_robin_index_ % healthy.size();
    round_robin_index_ = (round_robin_index_ + 1) % healthy.size();
    
    return &servers_[healthy[index].id];
}

BackendServer* LoadBalancer::selectLeastConnections() {
    BackendServer* selected = nullptr;
    uint64_t min_connections = std::numeric_limits<uint64_t>::max();
    
    for (auto& [id, server] : servers_) {
        if (server.is_healthy && server.active_connections < min_connections) {
            min_connections = server.active_connections;
            selected = &server;
        }
    }
    
    return selected;
}

BackendServer* LoadBalancer::selectLeastResponseTime() {
    BackendServer* selected = nullptr;
    auto min_response_time = std::chrono::microseconds::max();
    
    for (auto& [id, server] : servers_) {
        if (server.is_healthy && server.avg_response_time < min_response_time) {
            min_response_time = server.avg_response_time;
            selected = &server;
        }
    }
    
    return selected;
}

BackendServer* LoadBalancer::selectWeightedRoundRobin() {
    std::vector<BackendServer*> weighted_servers;
    
    for (auto& [id, server] : servers_) {
        if (server.is_healthy) {
            int weight_count = static_cast<int>(server.weight * 10);
            for (int i = 0; i < weight_count; ++i) {
                weighted_servers.push_back(&server);
            }
        }
    }
    
    if (weighted_servers.empty()) {
        return nullptr;
    }
    
    size_t index = round_robin_index_ % weighted_servers.size();
    round_robin_index_ = (round_robin_index_ + 1) % weighted_servers.size();
    
    return weighted_servers[index];
}

BackendServer* LoadBalancer::selectConsistentHashing(const std::string& client_id) {
    auto healthy = getHealthyServers();
    if (healthy.empty()) {
        return nullptr;
    }
    
    std::hash<std::string> hasher;
    size_t hash = hasher(client_id);
    size_t index = hash % healthy.size();
    
    return &servers_[healthy[index].id];
}

BackendServer* LoadBalancer::selectRandom() {
    auto healthy = getHealthyServers();
    if (healthy.empty()) {
        return nullptr;
    }
    
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<size_t> dis(0, healthy.size() - 1);
    
    return &servers_[healthy[dis(gen)].id];
}

BackendServer* LoadBalancer::selectIPHash(const std::string& client_ip) {
    return selectConsistentHashing(client_ip);
}

void LoadBalancer::healthCheckLoop() {
    while (running_) {
        {
            std::lock_guard<std::mutex> lock(lb_mutex_);
            for (auto& [id, server] : servers_) {
                performHealthCheck(server);
            }
            
            auto now = std::chrono::system_clock::now();
            for (auto it = session_timestamps_.begin(); it != session_timestamps_.end();) {
                auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(
                    now - it->second);
                
                if (elapsed > session_timeout_) {
                    session_to_server_.erase(it->first);
                    it = session_timestamps_.erase(it);
                } else {
                    ++it;
                }
            }
        }
        
        std::this_thread::sleep_for(health_check_config_.interval);
    }
}

bool LoadBalancer::performHealthCheck(BackendServer& server) {
    server.last_health_check = std::chrono::system_clock::now();
    
    if (server.total_requests > 0) {
        double failure_rate = static_cast<double>(server.failed_requests) / server.total_requests;
        if (failure_rate > 0.5) {
            server.is_healthy = false;
            return false;
        }
    }
    
    server.is_healthy = true;
    return true;
}

void LoadBalancer::updateServerMetrics() {
}

} // namespace kotana
