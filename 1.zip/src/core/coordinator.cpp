#include "coordinator.h"
#include <algorithm>
#include <random>
#include <sstream>
#include <thread>

namespace kotana {

Proposal::Proposal()
    : type(ProposalType::READ),
      status(ProposalStatus::PENDING),
      created_at(std::chrono::system_clock::now()),
      ballot_number(0),
      required_votes(0) {}

bool Proposal::hasQuorum() const {
    return getAcceptVotes() >= required_votes;
}

size_t Proposal::getAcceptVotes() const {
    size_t count = 0;
    for (const auto& [node_id, vote] : votes) {
        if (vote) ++count;
    }
    return count;
}

size_t Proposal::getRejectVotes() const {
    size_t count = 0;
    for (const auto& [node_id, vote] : votes) {
        if (!vote) ++count;
    }
    return count;
}

ConsensusState::ConsensusState()
    : current_ballot(0),
      last_heartbeat(std::chrono::system_clock::now()),
      in_leader_election(false) {}

DistributedCoordinator::DistributedCoordinator(std::shared_ptr<ClusterManager> cluster)
    : cluster_(cluster),
      running_(false),
      quorum_size_(2),
      auto_commit_(true),
      commit_timeout_(std::chrono::milliseconds(5000)),
      ballot_counter_(0) {}

DistributedCoordinator::~DistributedCoordinator() {
    stop();
}

bool DistributedCoordinator::start() {
    if (running_.exchange(true)) {
        return false;
    }
    
    state_.current_ballot = 0;
    state_.in_leader_election = true;
    
    coordination_thread_ = std::thread(&DistributedCoordinator::coordinationLoop, this);
    leader_election_thread_ = std::thread(&DistributedCoordinator::leaderElectionLoop, this);
    timeout_thread_ = std::thread(&DistributedCoordinator::proposalTimeoutLoop, this);
    
    return true;
}

void DistributedCoordinator::stop() {
    if (!running_.exchange(false)) {
        return;
    }
    
    if (coordination_thread_.joinable()) {
        coordination_thread_.join();
    }
    if (leader_election_thread_.joinable()) {
        leader_election_thread_.join();
    }
    if (timeout_thread_.joinable()) {
        timeout_thread_.join();
    }
}

bool DistributedCoordinator::isRunning() const {
    return running_.load();
}

std::string DistributedCoordinator::proposeWrite(const std::string& key,
                                                 const std::vector<uint8_t>& value) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    if (!canProposeAsLeader()) {
        return "";
    }
    
    Proposal proposal;
    proposal.proposal_id = generateProposalId();
    proposal.type = ProposalType::WRITE;
    proposal.status = ProposalStatus::PENDING;
    proposal.proposer_node_id = cluster_->getLocalNode().id;
    proposal.data = value;
    proposal.ballot_number = getNextBallotNumber();
    proposal.required_votes = quorum_size_;
    
    state_.active_proposals[proposal.proposal_id] = proposal;
    
    return proposal.proposal_id;
}

std::string DistributedCoordinator::proposeRead(const std::string& key) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    Proposal proposal;
    proposal.proposal_id = generateProposalId();
    proposal.type = ProposalType::READ;
    proposal.status = ProposalStatus::PENDING;
    proposal.proposer_node_id = cluster_->getLocalNode().id;
    proposal.ballot_number = getNextBallotNumber();
    proposal.required_votes = quorum_size_;
    
    state_.active_proposals[proposal.proposal_id] = proposal;
    
    return proposal.proposal_id;
}

std::string DistributedCoordinator::proposeDelete(const std::string& key) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    Proposal proposal;
    proposal.proposal_id = generateProposalId();
    proposal.type = ProposalType::DELETE;
    proposal.status = ProposalStatus::PENDING;
    proposal.proposer_node_id = cluster_->getLocalNode().id;
    proposal.ballot_number = getNextBallotNumber();
    proposal.required_votes = quorum_size_;
    
    state_.active_proposals[proposal.proposal_id] = proposal;
    
    return proposal.proposal_id;
}

std::string DistributedCoordinator::proposeSchemaChange(const std::string& change_description) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    Proposal proposal;
    proposal.proposal_id = generateProposalId();
    proposal.type = ProposalType::SCHEMA_CHANGE;
    proposal.status = ProposalStatus::PENDING;
    proposal.proposer_node_id = cluster_->getLocalNode().id;
    proposal.ballot_number = getNextBallotNumber();
    proposal.required_votes = quorum_size_;
    
    state_.active_proposals[proposal.proposal_id] = proposal;
    
    return proposal.proposal_id;
}

bool DistributedCoordinator::commitProposal(const std::string& proposal_id) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    auto it = state_.active_proposals.find(proposal_id);
    if (it == state_.active_proposals.end()) {
        return false;
    }
    
    if (!it->second.hasQuorum()) {
        return false;
    }
    
    it->second.status = ProposalStatus::COMMITTED;
    it->second.committed_at = std::chrono::system_clock::now();
    
    notifyCommit(proposal_id);
    
    return true;
}

bool DistributedCoordinator::abortProposal(const std::string& proposal_id) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    auto it = state_.active_proposals.find(proposal_id);
    if (it == state_.active_proposals.end()) {
        return false;
    }
    
    it->second.status = ProposalStatus::ABORTED;
    
    notifyAbort(proposal_id);
    
    return true;
}

ProposalStatus DistributedCoordinator::getProposalStatus(const std::string& proposal_id) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    auto it = state_.active_proposals.find(proposal_id);
    if (it == state_.active_proposals.end()) {
        return ProposalStatus::ABORTED;
    }
    
    return it->second.status;
}

bool DistributedCoordinator::voteOnProposal(const std::string& proposal_id, bool accept) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    auto it = state_.active_proposals.find(proposal_id);
    if (it == state_.active_proposals.end()) {
        return false;
    }
    
    std::string node_id = cluster_->getLocalNode().id;
    it->second.votes[node_id] = accept;
    
    if (accept) {
        it->second.status = ProposalStatus::ACCEPTED;
    } else {
        it->second.status = ProposalStatus::REJECTED;
    }
    
    if (auto_commit_ && it->second.hasQuorum()) {
        commitProposal(proposal_id);
    }
    
    return true;
}

std::vector<Proposal> DistributedCoordinator::getPendingProposals() {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    std::vector<Proposal> pending;
    for (const auto& [id, proposal] : state_.active_proposals) {
        if (proposal.status == ProposalStatus::PENDING ||
            proposal.status == ProposalStatus::ACCEPTED) {
            pending.push_back(proposal);
        }
    }
    
    return pending;
}

bool DistributedCoordinator::electLeader() {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    auto alive_nodes = cluster_->getAliveNodes();
    if (alive_nodes.empty()) {
        return false;
    }
    
    std::sort(alive_nodes.begin(), alive_nodes.end(),
        [](const Node& a, const Node& b) {
            return a.id < b.id;
        });
    
    state_.current_leader = alive_nodes[0].id;
    state_.current_ballot = getNextBallotNumber();
    state_.in_leader_election = false;
    
    return true;
}

bool DistributedCoordinator::isLeader() const {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    return state_.current_leader == cluster_->getLocalNode().id;
}

std::string DistributedCoordinator::getCurrentLeader() const {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    return state_.current_leader;
}

void DistributedCoordinator::handleNodeFailure(const std::string& node_id) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    
    if (state_.current_leader == node_id) {
        state_.in_leader_election = true;
    }
    
    for (auto& [id, proposal] : state_.active_proposals) {
        proposal.votes.erase(node_id);
        
        if (proposal.status == ProposalStatus::PENDING && !proposal.hasQuorum()) {
            proposal.status = ProposalStatus::ABORTED;
        }
    }
}

void DistributedCoordinator::handleNodeRecovery(const std::string& node_id) {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
}

ConsensusState DistributedCoordinator::getConsensusState() const {
    std::lock_guard<std::mutex> lock(coordinator_mutex_);
    return state_;
}

void DistributedCoordinator::setQuorumSize(size_t size) {
    quorum_size_ = std::max(size_t(1), size);
}

size_t DistributedCoordinator::getQuorumSize() const {
    return quorum_size_;
}

void DistributedCoordinator::enableAutoCommit(bool enable) {
    auto_commit_ = enable;
}

void DistributedCoordinator::setCommitTimeout(std::chrono::milliseconds timeout) {
    commit_timeout_ = timeout;
}

std::string DistributedCoordinator::generateProposalId() {
    static std::random_device rd;
    static std::mt19937_64 gen(rd());
    static std::uniform_int_distribution<uint64_t> dis;
    
    auto now = std::chrono::system_clock::now();
    auto timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count();
    
    std::stringstream ss;
    ss << "prop_" << timestamp << "_" << std::hex << dis(gen);
    return ss.str();
}

void DistributedCoordinator::coordinationLoop() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        
        std::lock_guard<std::mutex> lock(coordinator_mutex_);
        
        for (auto& [id, proposal] : state_.active_proposals) {
            if (proposal.status == ProposalStatus::ACCEPTED && proposal.hasQuorum()) {
                if (auto_commit_) {
                    proposal.status = ProposalStatus::COMMITTED;
                    proposal.committed_at = std::chrono::system_clock::now();
                }
            }
        }
    }
}

void DistributedCoordinator::leaderElectionLoop() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::seconds(5));
        
        if (state_.in_leader_election) {
            electLeader();
        }
    }
}

void DistributedCoordinator::proposalTimeoutLoop() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        
        std::lock_guard<std::mutex> lock(coordinator_mutex_);
        
        auto now = std::chrono::system_clock::now();
        
        for (auto& [id, proposal] : state_.active_proposals) {
            if (proposal.status == ProposalStatus::PENDING) {
                auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                    now - proposal.created_at);
                
                if (elapsed > commit_timeout_) {
                    proposal.status = ProposalStatus::ABORTED;
                }
            }
        }
    }
}

bool DistributedCoordinator::sendProposal(const Proposal& proposal, const std::string& node_id) {
    return true;
}

bool DistributedCoordinator::collectVotes(Proposal& proposal) {
    auto alive_nodes = cluster_->getAliveNodes();
    
    for (const auto& node : alive_nodes) {
        if (sendProposal(proposal, node.id)) {
            proposal.votes[node.id] = true;
        }
    }
    
    return proposal.hasQuorum();
}

void DistributedCoordinator::notifyCommit(const std::string& proposal_id) {
}

void DistributedCoordinator::notifyAbort(const std::string& proposal_id) {
}

uint64_t DistributedCoordinator::getNextBallotNumber() {
    return ballot_counter_.fetch_add(1);
}

bool DistributedCoordinator::canProposeAsLeader() {
    return isLeader() && !state_.in_leader_election;
}

} // namespace kotana
