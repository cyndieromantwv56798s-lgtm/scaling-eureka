#include "rate_limiter.h"
#include <algorithm>

namespace kotana {

RateLimitConfig::RateLimitConfig()
    : max_requests(100),
      window_duration(std::chrono::seconds(60)),
      algorithm(RateLimitAlgorithm::TOKEN_BUCKET),
      enable_burst(true),
      burst_size(20) {}

RateLimitInfo::RateLimitInfo()
    : remaining_requests(0),
      reset_time(std::chrono::system_clock::now()),
      is_limited(false),
      retry_after(0) {}

RateLimiter::RateLimiter(const RateLimitConfig& config)
    : config_(config) {}

RateLimiter::~RateLimiter() = default;

bool RateLimiter::allowRequest(const std::string& client_id) {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    
    switch (config_.algorithm) {
        case RateLimitAlgorithm::TOKEN_BUCKET:
            return allowTokenBucket(client_id);
        case RateLimitAlgorithm::LEAKY_BUCKET:
            return allowLeakyBucket(client_id);
        case RateLimitAlgorithm::FIXED_WINDOW:
            return allowFixedWindow(client_id);
        case RateLimitAlgorithm::SLIDING_WINDOW:
            return allowSlidingWindow(client_id);
    }
    
    return true;
}

RateLimitInfo RateLimiter::getInfo(const std::string& client_id) {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    
    RateLimitInfo info;
    
    auto it = client_states_.find(client_id);
    if (it == client_states_.end()) {
        info.remaining_requests = config_.max_requests;
        info.reset_time = std::chrono::system_clock::now() + config_.window_duration;
        info.is_limited = false;
        return info;
    }
    
    refillTokens(client_id);
    
    info.remaining_requests = it->second.tokens;
    info.reset_time = it->second.last_refill + config_.window_duration;
    info.is_limited = (it->second.tokens == 0);
    
    if (info.is_limited) {
        auto now = std::chrono::system_clock::now();
        auto time_until_reset = std::chrono::duration_cast<std::chrono::milliseconds>(
            info.reset_time - now);
        info.retry_after = time_until_reset;
    }
    
    return info;
}

void RateLimiter::setConfig(const RateLimitConfig& config) {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    config_ = config;
}

RateLimitConfig RateLimiter::getConfig() const {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    return config_;
}

void RateLimiter::reset(const std::string& client_id) {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    client_states_.erase(client_id);
}

void RateLimiter::resetAll() {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    client_states_.clear();
}

size_t RateLimiter::getClientCount() const {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    return client_states_.size();
}

std::vector<std::string> RateLimiter::getBlockedClients() {
    std::lock_guard<std::mutex> lock(limiter_mutex_);
    
    std::vector<std::string> blocked;
    for (const auto& [client_id, state] : client_states_) {
        if (state.tokens == 0) {
            blocked.push_back(client_id);
        }
    }
    return blocked;
}

bool RateLimiter::allowTokenBucket(const std::string& client_id) {
    auto& state = client_states_[client_id];
    
    refillTokens(client_id);
    
    if (state.tokens > 0) {
        state.tokens--;
        return true;
    }
    
    return false;
}

bool RateLimiter::allowLeakyBucket(const std::string& client_id) {
    return allowTokenBucket(client_id);
}

bool RateLimiter::allowFixedWindow(const std::string& client_id) {
    auto& state = client_states_[client_id];
    auto now = std::chrono::system_clock::now();
    
    if (state.window_start == std::chrono::system_clock::time_point{}) {
        state.window_start = now;
        state.requests_in_window = 0;
    }
    
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - state.window_start);
    
    if (elapsed >= config_.window_duration) {
        state.window_start = now;
        state.requests_in_window = 0;
    }
    
    if (state.requests_in_window < config_.max_requests) {
        state.requests_in_window++;
        return true;
    }
    
    return false;
}

bool RateLimiter::allowSlidingWindow(const std::string& client_id) {
    auto& state = client_states_[client_id];
    auto now = std::chrono::system_clock::now();
    
    while (!state.request_times.empty()) {
        auto& oldest = state.request_times.front();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - oldest);
        
        if (elapsed >= config_.window_duration) {
            state.request_times.pop_front();
        } else {
            break;
        }
    }
    
    if (state.request_times.size() < config_.max_requests) {
        state.request_times.push_back(now);
        return true;
    }
    
    return false;
}

void RateLimiter::refillTokens(const std::string& client_id) {
    auto& state = client_states_[client_id];
    auto now = std::chrono::system_clock::now();
    
    if (state.last_refill == std::chrono::system_clock::time_point{}) {
        state.last_refill = now;
        state.tokens = config_.max_requests;
        if (config_.enable_burst) {
            state.tokens += config_.burst_size;
        }
        return;
    }
    
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - state.last_refill);
    
    if (elapsed >= config_.window_duration) {
        state.tokens = config_.max_requests;
        if (config_.enable_burst) {
            state.tokens += config_.burst_size;
        }
        state.last_refill = now;
    } else {
        double refill_rate = static_cast<double>(config_.max_requests) / 
                            config_.window_duration.count();
        size_t tokens_to_add = static_cast<size_t>(refill_rate * elapsed.count());
        
        state.tokens = std::min(state.tokens + tokens_to_add, config_.max_requests);
        if (tokens_to_add > 0) {
            state.last_refill = now;
        }
    }
}

} // namespace kotana
