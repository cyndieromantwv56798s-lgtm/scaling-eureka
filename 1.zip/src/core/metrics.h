#pragma once

#include <atomic>
#include <chrono>
#include <map>
#include <string>
#include <mutex>
#include <vector>
#include <algorithm>
#include <iostream>
#include <iomanip>

namespace kotana {

class MetricsCollector {
public:
    struct Metrics {
        std::atomic<uint64_t> total_queries{0};
        std::atomic<uint64_t> successful_queries{0};
        std::atomic<uint64_t> failed_queries{0};
        std::atomic<uint64_t> total_reads{0};
        std::atomic<uint64_t> total_writes{0};
        std::atomic<uint64_t> total_deletes{0};
        
        std::atomic<uint64_t> cache_hits{0};
        std::atomic<uint64_t> cache_misses{0};
        
        std::atomic<uint64_t> compactions_completed{0};
        std::atomic<uint64_t> sstables_created{0};
        std::atomic<uint64_t> sstables_merged{0};
        
        std::atomic<uint64_t> bytes_read{0};
        std::atomic<uint64_t> bytes_written{0};
        
        std::atomic<uint64_t> active_connections{0};
        std::atomic<uint64_t> total_connections{0};
    };
    
    static MetricsCollector& instance() {
        static MetricsCollector instance;
        return instance;
    }
    
    void incrementQueries() { metrics_.total_queries++; }
    void incrementSuccessfulQueries() { metrics_.successful_queries++; }
    void incrementFailedQueries() { metrics_.failed_queries++; }
    void incrementReads() { metrics_.total_reads++; }
    void incrementWrites() { metrics_.total_writes++; }
    void incrementDeletes() { metrics_.total_deletes++; }
    
    void incrementCacheHits() { metrics_.cache_hits++; }
    void incrementCacheMisses() { metrics_.cache_misses++; }
    
    void incrementCompactions() { metrics_.compactions_completed++; }
    void incrementSSTablesCreated() { metrics_.sstables_created++; }
    void incrementSSTablesMerged() { metrics_.sstables_merged++; }
    
    void addBytesRead(uint64_t bytes) { metrics_.bytes_read += bytes; }
    void addBytesWritten(uint64_t bytes) { metrics_.bytes_written += bytes; }
    
    void incrementActiveConnections() { 
        metrics_.active_connections++; 
        metrics_.total_connections++;
    }
    void decrementActiveConnections() { metrics_.active_connections--; }
    
    void recordLatency(const std::string& operation, uint64_t latency_us) {
        std::lock_guard<std::mutex> lock(latency_mutex_);
        latencies_[operation].push_back(latency_us);
        
        if (latencies_[operation].size() > 10000) {
            latencies_[operation].erase(latencies_[operation].begin());
        }
    }
    
    const Metrics& getMetrics() const { return metrics_; }
    
    void printMetrics() const {
        std::cout << "\n╔═══════════════════════════════════════════════════════════════════╗\n";
        std::cout << "║                      SYSTEM METRICS                               ║\n";
        std::cout << "╚═══════════════════════════════════════════════════════════════════╝\n\n";
        
        std::cout << "Query Statistics:\n";
        std::cout << "  Total Queries:         " << metrics_.total_queries.load() << "\n";
        std::cout << "  Successful:            " << metrics_.successful_queries.load() << "\n";
        std::cout << "  Failed:                " << metrics_.failed_queries.load() << "\n";
        std::cout << "  Total Reads:           " << metrics_.total_reads.load() << "\n";
        std::cout << "  Total Writes:          " << metrics_.total_writes.load() << "\n";
        std::cout << "  Total Deletes:         " << metrics_.total_deletes.load() << "\n";
        std::cout << "\n";
        
        std::cout << "Cache Statistics:\n";
        std::cout << "  Cache Hits:            " << metrics_.cache_hits.load() << "\n";
        std::cout << "  Cache Misses:          " << metrics_.cache_misses.load() << "\n";
        
        uint64_t total_cache_ops = metrics_.cache_hits.load() + metrics_.cache_misses.load();
        if (total_cache_ops > 0) {
            double hit_rate = (double)metrics_.cache_hits.load() / total_cache_ops * 100.0;
            std::cout << "  Hit Rate:              " << std::fixed << std::setprecision(2) 
                      << hit_rate << "%\n";
        }
        std::cout << "\n";
        
        std::cout << "Storage Statistics:\n";
        std::cout << "  Compactions:           " << metrics_.compactions_completed.load() << "\n";
        std::cout << "  SSTables Created:      " << metrics_.sstables_created.load() << "\n";
        std::cout << "  SSTables Merged:       " << metrics_.sstables_merged.load() << "\n";
        std::cout << "  Bytes Read:            " << formatBytes(metrics_.bytes_read.load()) << "\n";
        std::cout << "  Bytes Written:         " << formatBytes(metrics_.bytes_written.load()) << "\n";
        std::cout << "\n";
        
        std::cout << "Connection Statistics:\n";
        std::cout << "  Active Connections:    " << metrics_.active_connections.load() << "\n";
        std::cout << "  Total Connections:     " << metrics_.total_connections.load() << "\n";
        std::cout << "\n";
        
        printLatencyStats();
    }
    
    void reset() {
        metrics_ = Metrics();
        std::lock_guard<std::mutex> lock(latency_mutex_);
        latencies_.clear();
    }

private:
    MetricsCollector() = default;
    MetricsCollector(const MetricsCollector&) = delete;
    MetricsCollector& operator=(const MetricsCollector&) = delete;
    
    void printLatencyStats() const {
        std::lock_guard<std::mutex> lock(latency_mutex_);
        
        if (latencies_.empty()) {
            return;
        }
        
        std::cout << "Latency Statistics (microseconds):\n";
        
        for (const auto& [op, lats] : latencies_) {
            if (lats.empty()) continue;
            
            std::vector<uint64_t> sorted_lats = lats;
            std::sort(sorted_lats.begin(), sorted_lats.end());
            
            uint64_t avg = 0;
            for (auto lat : sorted_lats) avg += lat;
            avg /= sorted_lats.size();
            
            size_t p50_idx = sorted_lats.size() * 50 / 100;
            size_t p95_idx = sorted_lats.size() * 95 / 100;
            size_t p99_idx = sorted_lats.size() * 99 / 100;
            
            std::cout << "  " << op << ":\n";
            std::cout << "    Avg: " << avg << " μs, ";
            std::cout << "P50: " << sorted_lats[p50_idx] << " μs, ";
            std::cout << "P95: " << sorted_lats[p95_idx] << " μs, ";
            std::cout << "P99: " << sorted_lats[p99_idx] << " μs\n";
        }
        std::cout << "\n";
    }
    
    std::string formatBytes(uint64_t bytes) const {
        const char* units[] = {"B", "KB", "MB", "GB", "TB"};
        int unit_idx = 0;
        double size = bytes;
        
        while (size >= 1024.0 && unit_idx < 4) {
            size /= 1024.0;
            ++unit_idx;
        }
        
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(2) << size << " " << units[unit_idx];
        return oss.str();
    }
    
    Metrics metrics_;
    mutable std::mutex latency_mutex_;
    std::map<std::string, std::vector<uint64_t>> latencies_;
};

class LatencyTimer {
public:
    LatencyTimer(const std::string& operation)
        : operation_(operation),
          start_(std::chrono::high_resolution_clock::now()) {}
    
    ~LatencyTimer() {
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start_);
        MetricsCollector::instance().recordLatency(operation_, duration.count());
    }

private:
    std::string operation_;
    std::chrono::high_resolution_clock::time_point start_;
};

} // namespace kotana
