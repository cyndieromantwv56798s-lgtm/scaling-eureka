#pragma once

#include "hash_ring.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <atomic>
#include <set>
#include <chrono>

namespace kotana {

enum class NodeStatus {
    ALIVE,
    SUSPECT,
    DEAD,
    JOINING,
    LEAVING
};

struct Node {
    std::string id;
    std::string address;
    uint16_t port;
    NodeStatus status;
    std::chrono::system_clock::time_point last_heartbeat;
    uint64_t data_size;
    double cpu_usage;
    double memory_usage;
    std::set<std::string> owned_ranges;
    
    Node();
    Node(const std::string& node_id, const std::string& addr, uint16_t p);
    
    bool isHealthy() const;
    std::chrono::milliseconds timeSinceLastHeartbeat() const;
};

struct ClusterConfig {
    std::string local_node_id;
    std::string local_address;
    uint16_t local_port;
    std::vector<std::string> seed_nodes;
    std::chrono::seconds heartbeat_interval;
    std::chrono::seconds failure_detection_timeout;
    size_t replication_factor;
    
    ClusterConfig();
};

class ClusterManager {
public:
    explicit ClusterManager(const ClusterConfig& config);
    ~ClusterManager();
    
    bool start();
    void stop();
    bool isRunning() const;
    
    bool joinCluster();
    bool leaveCluster();
    
    bool addNode(const Node& node);
    bool removeNode(const std::string& node_id);
    bool updateNodeStatus(const std::string& node_id, NodeStatus status);
    
    std::vector<Node> getAliveNodes();
    std::vector<Node> getAllNodes();
    Node* getNode(const std::string& node_id);
    Node getLocalNode() const;
    
    std::vector<std::string> getNodesForKey(const std::string& key);
    std::string getPrimaryNodeForKey(const std::string& key);
    bool isLocalNodeResponsibleFor(const std::string& key);
    
    void sendHeartbeat();
    void receiveHeartbeat(const std::string& node_id);
    void detectFailures();
    
    size_t getClusterSize() const;
    size_t getHealthyNodeCount() const;
    bool isClusterHealthy() const;
    
    void rebalance();
    void redistributeData(const std::string& from_node, const std::string& to_node);

private:
    void heartbeatLoop();
    void failureDetectionLoop();
    void gossipLoop();
    
    void broadcastNodeJoin(const Node& node);
    void broadcastNodeLeave(const std::string& node_id);
    
    void updateHashRing();
    
    ClusterConfig config_;
    Node local_node_;
    std::map<std::string, Node> nodes_;
    std::unique_ptr<ConsistentHashRing> hash_ring_;
    
    std::atomic<bool> running_;
    std::mutex nodes_mutex_;
    
    std::thread heartbeat_thread_;
    std::thread failure_detection_thread_;
    std::thread gossip_thread_;
};

} // namespace kotana
