#pragma once

#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <iostream>

namespace kotana {

class Configuration {
public:
    Configuration() {
        setDefaults();
    }
    
    void load(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Warning: Could not open config file: " << filename << "\n";
            return;
        }
        
        std::string line;
        while (std::getline(file, line)) {
            if (line.empty() || line[0] == '#') {
                continue;
            }
            
            size_t pos = line.find('=');
            if (pos != std::string::npos) {
                std::string key = trim(line.substr(0, pos));
                std::string value = trim(line.substr(pos + 1));
                config_[key] = value;
            }
        }
    }
    
    void save(const std::string& filename) const {
        std::ofstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Could not write config file: " << filename << "\n";
            return;
        }
        
        file << "# Kotosploit Kotana Configuration\n";
        file << "# Auto-generated configuration file\n\n";
        
        for (const auto& [key, value] : config_) {
            file << key << " = " << value << "\n";
        }
    }
    
    std::string get(const std::string& key, const std::string& default_value = "") const {
        auto it = config_.find(key);
        return (it != config_.end()) ? it->second : default_value;
    }
    
    int getInt(const std::string& key, int default_value = 0) const {
        auto value = get(key);
        return value.empty() ? default_value : std::stoi(value);
    }
    
    uint64_t getUInt64(const std::string& key, uint64_t default_value = 0) const {
        auto value = get(key);
        return value.empty() ? default_value : std::stoull(value);
    }
    
    bool getBool(const std::string& key, bool default_value = false) const {
        auto value = get(key);
        if (value.empty()) return default_value;
        return value == "true" || value == "1" || value == "yes";
    }
    
    double getDouble(const std::string& key, double default_value = 0.0) const {
        auto value = get(key);
        return value.empty() ? default_value : std::stod(value);
    }
    
    void set(const std::string& key, const std::string& value) {
        config_[key] = value;
    }
    
    void set(const std::string& key, int value) {
        config_[key] = std::to_string(value);
    }
    
    void set(const std::string& key, uint64_t value) {
        config_[key] = std::to_string(value);
    }
    
    void set(const std::string& key, bool value) {
        config_[key] = value ? "true" : "false";
    }
    
    void set(const std::string& key, double value) {
        config_[key] = std::to_string(value);
    }
    
    bool has(const std::string& key) const {
        return config_.find(key) != config_.end();
    }
    
    void printAll() const {
        std::cout << "Current Configuration:\n";
        for (const auto& [key, value] : config_) {
            std::cout << "  " << key << " = " << value << "\n";
        }
    }

private:
    void setDefaults() {
        config_["server.host"] = "0.0.0.0";
        config_["server.port"] = "9042";
        config_["server.threads"] = std::to_string(std::thread::hardware_concurrency());
        config_["server.max_connections"] = "1000";
        
        config_["storage.data_dir"] = "./data";
        config_["storage.memtable_size"] = std::to_string(64 * 1024 * 1024);
        config_["storage.num_memtables"] = "3";
        config_["storage.compaction_threshold"] = "4";
        config_["storage.enable_wal"] = "true";
        
        config_["performance.enable_simd"] = "true";
        config_["performance.enable_async_io"] = "true";
        config_["performance.cache_size"] = std::to_string(256 * 1024 * 1024);
        
        config_["logging.level"] = "info";
        config_["logging.file"] = "kotana.log";
        config_["logging.console"] = "true";
        
        config_["cluster.node_id"] = "node1";
        config_["cluster.replication_factor"] = "1";
        config_["cluster.consistency_level"] = "one";
    }
    
    std::string trim(const std::string& str) const {
        size_t first = str.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) return "";
        size_t last = str.find_last_not_of(" \t\r\n");
        return str.substr(first, last - first + 1);
    }
    
    std::map<std::string, std::string> config_;
};

} // namespace kotana
