#pragma once

#include "core/types.h"
#include "query/ast.h"
#include <string>
#include <map>
#include <vector>
#include <memory>
#include <mutex>
#include <chrono>
#include <deque>

namespace kotana {

struct QueryStatistics {
    std::string query_hash;
    std::string query_text;
    uint64_t execution_count;
    std::chrono::microseconds total_execution_time;
    std::chrono::microseconds min_execution_time;
    std::chrono::microseconds max_execution_time;
    std::chrono::microseconds avg_execution_time;
    uint64_t total_rows_scanned;
    uint64_t total_rows_returned;
    std::chrono::system_clock::time_point first_seen;
    std::chrono::system_clock::time_point last_seen;
    std::vector<std::string> tables_accessed;
    
    QueryStatistics();
    void update(std::chrono::microseconds exec_time, uint64_t rows_scanned, uint64_t rows_returned);
};

struct TableStatistics {
    std::string table_name;
    uint64_t row_count;
    uint64_t total_size_bytes;
    uint64_t index_size_bytes;
    double avg_row_size;
    std::chrono::system_clock::time_point last_analyzed;
    std::map<std::string, ColumnStatistics> column_stats;
    std::vector<std::string> hot_keys;
    double read_count;
    double write_count;
    double delete_count;
    
    TableStatistics();
};

struct ColumnStatistics {
    std::string column_name;
    DataType data_type;
    uint64_t distinct_count;
    uint64_t null_count;
    Value min_value;
    Value max_value;
    double avg_value;
    std::vector<Value> most_common_values;
    std::vector<uint64_t> value_frequencies;
    
    ColumnStatistics();
};

struct SystemStatistics {
    std::chrono::system_clock::time_point start_time;
    uint64_t total_queries_executed;
    uint64_t total_queries_failed;
    uint64_t total_bytes_read;
    uint64_t total_bytes_written;
    uint64_t cache_hits;
    uint64_t cache_misses;
    double avg_query_latency_ms;
    uint64_t active_connections;
    uint64_t peak_connections;
    std::map<std::string, uint64_t> error_counts;
    
    SystemStatistics();
};

class StatisticsCollector {
public:
    StatisticsCollector();
    ~StatisticsCollector();
    
    void recordQuery(const std::string& query, std::chrono::microseconds exec_time,
                    uint64_t rows_scanned, uint64_t rows_returned);
    void recordTableAccess(const std::string& table, bool is_write);
    void recordCacheHit(bool hit);
    void recordError(const std::string& error_type);
    void recordConnection(bool connected);
    
    QueryStatistics* getQueryStatistics(const std::string& query_hash);
    std::vector<QueryStatistics> getTopQueries(size_t limit = 10);
    std::vector<QueryStatistics> getSlowestQueries(size_t limit = 10);
    std::vector<QueryStatistics> getMostFrequentQueries(size_t limit = 10);
    
    TableStatistics* getTableStatistics(const std::string& table);
    void updateTableStatistics(const std::string& table);
    void analyzeTable(const std::string& table);
    
    SystemStatistics getSystemStatistics();
    void resetStatistics();
    void resetQueryStatistics();
    
    void enableAutoAnalyze(bool enable);
    void setAnalyzeInterval(std::chrono::seconds interval);
    
    std::string exportCSV();
    std::string exportJSON();
    void saveToFile(const std::string& filepath);
    void loadFromFile(const std::string& filepath);

private:
    std::string hashQuery(const std::string& query);
    void autoAnalyzeLoop();
    void pruneOldStatistics();
    
    std::map<std::string, QueryStatistics> query_stats_;
    std::map<std::string, TableStatistics> table_stats_;
    SystemStatistics system_stats_;
    
    std::mutex stats_mutex_;
    bool auto_analyze_;
    std::chrono::seconds analyze_interval_;
    std::thread analyze_thread_;
    std::atomic<bool> running_;
    
    static const size_t MAX_QUERY_STATS = 10000;
    std::deque<std::string> query_history_;
};

} // namespace kotana
