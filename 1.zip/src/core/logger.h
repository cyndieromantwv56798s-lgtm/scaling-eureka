#pragma once

#include "utils.h"
#include <string>
#include <fstream>
#include <mutex>
#include <queue>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <iostream>
#include <sstream>

namespace kotana {

enum class LogLevel {
    TRACE,
    DEBUG,
    INFO,
    WARNING,
    ERROR,
    FATAL
};

class Logger {
public:
    struct LogEntry {
        LogLevel level;
        std::string message;
        std::string file;
        int line;
        std::string function;
        uint64_t timestamp;
        std::thread::id thread_id;
        
        LogEntry() : level(LogLevel::INFO), line(0), timestamp(0) {}
        
        LogEntry(LogLevel lvl, const std::string& msg, const std::string& f, 
                int l, const std::string& func)
            : level(lvl), message(msg), file(f), line(l), function(func),
              timestamp(Utils::getCurrentTimestamp()),
              thread_id(std::this_thread::get_id()) {}
        
        std::string format() const {
            std::ostringstream oss;
            oss << "[" << Utils::getCurrentTimeString() << "] ";
            oss << "[" << levelToString(level) << "] ";
            oss << "[" << thread_id << "] ";
            oss << message;
            oss << " (" << file << ":" << line << " " << function << ")";
            return oss.str();
        }
        
        static std::string levelToString(LogLevel level) {
            switch (level) {
                case LogLevel::TRACE: return "TRACE";
                case LogLevel::DEBUG: return "DEBUG";
                case LogLevel::INFO: return "INFO";
                case LogLevel::WARNING: return "WARN";
                case LogLevel::ERROR: return "ERROR";
                case LogLevel::FATAL: return "FATAL";
                default: return "UNKNOWN";
            }
        }
    };
    
    static Logger& instance() {
        static Logger instance;
        return instance;
    }
    
    void setLevel(LogLevel level) {
        min_level_ = level;
    }
    
    void setLogFile(const std::string& filename) {
        std::unique_lock<std::mutex> lock(file_mutex_);
        
        if (log_file_.is_open()) {
            log_file_.close();
        }
        
        log_file_.open(filename, std::ios::out | std::ios::app);
        if (!log_file_.is_open()) {
            std::cerr << "Failed to open log file: " << filename << std::endl;
        }
        
        log_filename_ = filename;
    }
    
    void enableConsole(bool enable) {
        console_enabled_ = enable;
    }
    
    void enableFile(bool enable) {
        file_enabled_ = enable;
    }
    
    void log(const LogEntry& entry) {
        if (entry.level < min_level_) {
            return;
        }
        
        std::string formatted = entry.format();
        
        if (console_enabled_) {
            std::unique_lock<std::mutex> lock(console_mutex_);
            
            if (entry.level >= LogLevel::ERROR) {
                std::cerr << formatted << std::endl;
            } else {
                std::cout << formatted << std::endl;
            }
        }
        
        if (file_enabled_) {
            std::unique_lock<std::mutex> lock(log_queue_mutex_);
            log_queue_.push(formatted);
            log_cv_.notify_one();
        }
    }
    
    void log(LogLevel level, const std::string& message, 
            const std::string& file, int line, const std::string& function) {
        LogEntry entry(level, message, file, line, function);
        log(entry);
    }
    
    void flush() {
        std::unique_lock<std::mutex> lock(file_mutex_);
        if (log_file_.is_open()) {
            log_file_.flush();
        }
    }
    
    void shutdown() {
        if (shutdown_.exchange(true)) {
            return;
        }
        
        {
            std::unique_lock<std::mutex> lock(log_queue_mutex_);
            log_cv_.notify_all();
        }
        
        if (log_thread_.joinable()) {
            log_thread_.join();
        }
        
        std::unique_lock<std::mutex> lock(file_mutex_);
        if (log_file_.is_open()) {
            log_file_.close();
        }
    }
    
    ~Logger() {
        shutdown();
    }

private:
    Logger()
        : min_level_(LogLevel::INFO),
          console_enabled_(true),
          file_enabled_(false),
          shutdown_(false) {
        
        log_thread_ = std::thread(&Logger::logWorker, this);
    }
    
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;
    
    void logWorker() {
        while (!shutdown_) {
            std::unique_lock<std::mutex> lock(log_queue_mutex_);
            
            log_cv_.wait(lock, [this] {
                return !log_queue_.empty() || shutdown_;
            });
            
            while (!log_queue_.empty()) {
                std::string entry = log_queue_.front();
                log_queue_.pop();
                
                lock.unlock();
                writeToFile(entry);
                lock.lock();
            }
        }
        
        while (!log_queue_.empty()) {
            writeToFile(log_queue_.front());
            log_queue_.pop();
        }
    }
    
    void writeToFile(const std::string& entry) {
        std::unique_lock<std::mutex> lock(file_mutex_);
        if (log_file_.is_open()) {
            log_file_ << entry << std::endl;
        }
    }
    
    LogLevel min_level_;
    bool console_enabled_;
    bool file_enabled_;
    std::atomic<bool> shutdown_;
    
    std::string log_filename_;
    std::ofstream log_file_;
    
    std::queue<std::string> log_queue_;
    std::thread log_thread_;
    
    std::mutex console_mutex_;
    std::mutex file_mutex_;
    std::mutex log_queue_mutex_;
    std::condition_variable log_cv_;
};

#define LOG_TRACE(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::TRACE, msg, __FILE__, __LINE__, __FUNCTION__)

#define LOG_DEBUG(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::DEBUG, msg, __FILE__, __LINE__, __FUNCTION__)

#define LOG_INFO(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::INFO, msg, __FILE__, __LINE__, __FUNCTION__)

#define LOG_WARNING(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::WARNING, msg, __FILE__, __LINE__, __FUNCTION__)

#define LOG_ERROR(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::ERROR, msg, __FILE__, __LINE__, __FUNCTION__)

#define LOG_FATAL(msg) \
    kotana::Logger::instance().log(kotana::LogLevel::FATAL, msg, __FILE__, __LINE__, __FUNCTION__)

} // namespace kotana
