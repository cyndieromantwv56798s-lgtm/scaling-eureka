#include "encryption.h"
#include <random>
#include <sstream>
#include <iomanip>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/rand.h>

namespace kotana {

EncryptionKey::EncryptionKey()
    : algorithm(EncryptionAlgorithm::AES_256),
      created_at(std::chrono::system_clock::now()),
      expires_at(std::chrono::system_clock::now() + std::chrono::hours(24 * 365)),
      is_active(true) {}

EncryptionManager::EncryptionManager()
    : encryption_at_rest_(false),
      encryption_in_transit_(false) {
    generateKey(EncryptionAlgorithm::AES_256);
}

EncryptionManager::~EncryptionManager() = default;

std::string EncryptionManager::generateKey(EncryptionAlgorithm algorithm) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    size_t key_size = 32;
    if (algorithm == EncryptionAlgorithm::AES_128) {
        key_size = 16;
    }
    
    std::vector<uint8_t> key_data(key_size);
    RAND_bytes(key_data.data(), key_size);
    
    static std::random_device rd;
    static std::mt19937_64 gen(rd());
    static std::uniform_int_distribution<uint64_t> dis;
    
    std::stringstream ss;
    ss << "key_" << std::hex << dis(gen);
    std::string key_id = ss.str();
    
    EncryptionKey key;
    key.key_id = key_id;
    key.key_data = std::move(key_data);
    key.algorithm = algorithm;
    
    keys_[key_id] = key;
    
    if (active_key_id_.empty()) {
        active_key_id_ = key_id;
    }
    
    return key_id;
}

bool EncryptionManager::loadKey(const std::string& key_id, const std::vector<uint8_t>& key_data) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    if (keys_.find(key_id) != keys_.end()) {
        return false;
    }
    
    EncryptionKey key;
    key.key_id = key_id;
    key.key_data = key_data;
    
    if (key_data.size() == 16) {
        key.algorithm = EncryptionAlgorithm::AES_128;
    } else if (key_data.size() == 32) {
        key.algorithm = EncryptionAlgorithm::AES_256;
    }
    
    keys_[key_id] = key;
    return true;
}

bool EncryptionManager::deleteKey(const std::string& key_id) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    if (key_id == active_key_id_) {
        return false;
    }
    
    return keys_.erase(key_id) > 0;
}

std::vector<uint8_t> EncryptionManager::encrypt(const std::vector<uint8_t>& plaintext,
                                                const std::string& key_id) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    std::string actual_key_id = key_id.empty() ? active_key_id_ : key_id;
    
    auto it = keys_.find(actual_key_id);
    if (it == keys_.end()) {
        return {};
    }
    
    auto iv = generateIV();
    auto ciphertext = encryptAES(plaintext, it->second.key_data, iv);
    
    std::vector<uint8_t> result;
    result.reserve(iv.size() + ciphertext.size());
    result.insert(result.end(), iv.begin(), iv.end());
    result.insert(result.end(), ciphertext.begin(), ciphertext.end());
    
    return result;
}

std::vector<uint8_t> EncryptionManager::decrypt(const std::vector<uint8_t>& ciphertext,
                                                const std::string& key_id) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    std::string actual_key_id = key_id.empty() ? active_key_id_ : key_id;
    
    auto it = keys_.find(actual_key_id);
    if (it == keys_.end() || ciphertext.size() < 16) {
        return {};
    }
    
    std::vector<uint8_t> iv(ciphertext.begin(), ciphertext.begin() + 16);
    std::vector<uint8_t> encrypted_data(ciphertext.begin() + 16, ciphertext.end());
    
    return decryptAES(encrypted_data, it->second.key_data, iv);
}

std::string EncryptionManager::encryptString(const std::string& plaintext, const std::string& key_id) {
    std::vector<uint8_t> plain_bytes(plaintext.begin(), plaintext.end());
    auto encrypted = encrypt(plain_bytes, key_id);
    
    std::stringstream ss;
    for (uint8_t byte : encrypted) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(byte);
    }
    return ss.str();
}

std::string EncryptionManager::decryptString(const std::string& ciphertext, const std::string& key_id) {
    std::vector<uint8_t> cipher_bytes;
    for (size_t i = 0; i < ciphertext.length(); i += 2) {
        std::string byte_str = ciphertext.substr(i, 2);
        cipher_bytes.push_back(static_cast<uint8_t>(std::stoi(byte_str, nullptr, 16)));
    }
    
    auto decrypted = decrypt(cipher_bytes, key_id);
    return std::string(decrypted.begin(), decrypted.end());
}

std::vector<uint8_t> EncryptionManager::deriveKey(const std::string& password,
                                                  const std::vector<uint8_t>& salt,
                                                  KeyDerivationFunction kdf,
                                                  size_t key_length) {
    std::vector<uint8_t> derived_key(key_length);
    
    if (kdf == KeyDerivationFunction::PBKDF2) {
        PKCS5_PBKDF2_HMAC(password.c_str(), password.length(),
                         salt.data(), salt.size(),
                         100000, EVP_sha256(),
                         key_length, derived_key.data());
    }
    
    return derived_key;
}

std::vector<uint8_t> EncryptionManager::generateSalt(size_t length) {
    std::vector<uint8_t> salt(length);
    RAND_bytes(salt.data(), length);
    return salt;
}

std::vector<uint8_t> EncryptionManager::generateIV(size_t length) {
    std::vector<uint8_t> iv(length);
    RAND_bytes(iv.data(), length);
    return iv;
}

bool EncryptionManager::rotateKey(const std::string& old_key_id, const std::string& new_key_id) {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    if (keys_.find(old_key_id) == keys_.end() || keys_.find(new_key_id) == keys_.end()) {
        return false;
    }
    
    active_key_id_ = new_key_id;
    keys_[old_key_id].is_active = false;
    keys_[new_key_id].is_active = true;
    
    return true;
}

std::vector<std::string> EncryptionManager::listKeys() {
    std::lock_guard<std::mutex> lock(encryption_mutex_);
    
    std::vector<std::string> key_ids;
    for (const auto& [id, key] : keys_) {
        key_ids.push_back(id);
    }
    return key_ids;
}

void EncryptionManager::enableEncryptionAtRest(bool enable) {
    encryption_at_rest_ = enable;
}

void EncryptionManager::enableEncryptionInTransit(bool enable) {
    encryption_in_transit_ = enable;
}

bool EncryptionManager::isEncryptionAtRestEnabled() const {
    return encryption_at_rest_;
}

bool EncryptionManager::isEncryptionInTransitEnabled() const {
    return encryption_in_transit_;
}

std::vector<uint8_t> EncryptionManager::encryptAES(const std::vector<uint8_t>& plaintext,
                                                   const std::vector<uint8_t>& key,
                                                   const std::vector<uint8_t>& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    
    const EVP_CIPHER* cipher = key.size() == 16 ? EVP_aes_128_cbc() : EVP_aes_256_cbc();
    
    EVP_EncryptInit_ex(ctx, cipher, nullptr, key.data(), iv.data());
    
    std::vector<uint8_t> ciphertext(plaintext.size() + EVP_CIPHER_block_size(cipher));
    int len = 0;
    int ciphertext_len = 0;
    
    EVP_EncryptUpdate(ctx, ciphertext.data(), &len, plaintext.data(), plaintext.size());
    ciphertext_len = len;
    
    EVP_EncryptFinal_ex(ctx, ciphertext.data() + len, &len);
    ciphertext_len += len;
    
    EVP_CIPHER_CTX_free(ctx);
    
    ciphertext.resize(ciphertext_len);
    return ciphertext;
}

std::vector<uint8_t> EncryptionManager::decryptAES(const std::vector<uint8_t>& ciphertext,
                                                   const std::vector<uint8_t>& key,
                                                   const std::vector<uint8_t>& iv) {
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    
    const EVP_CIPHER* cipher = key.size() == 16 ? EVP_aes_128_cbc() : EVP_aes_256_cbc();
    
    EVP_DecryptInit_ex(ctx, cipher, nullptr, key.data(), iv.data());
    
    std::vector<uint8_t> plaintext(ciphertext.size());
    int len = 0;
    int plaintext_len = 0;
    
    EVP_DecryptUpdate(ctx, plaintext.data(), &len, ciphertext.data(), ciphertext.size());
    plaintext_len = len;
    
    EVP_DecryptFinal_ex(ctx, plaintext.data() + len, &len);
    plaintext_len += len;
    
    EVP_CIPHER_CTX_free(ctx);
    
    plaintext.resize(plaintext_len);
    return plaintext;
}

} // namespace kotana
