#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <cstdint>
#include <variant>
#include <optional>

namespace kotana {

// Data types
enum class DataType {
    INT32,
    INT64,
    FLOAT,
    DOUBLE,
    STRING,
    BLOB,
    BOOLEAN,
    TIMESTAMP,
    UUID
};

// Value representation
class Value {
public:
    using ValueType = std::variant<
        int32_t, int64_t, float, double, 
        std::string, std::vector<uint8_t>, 
        bool, uint64_t
    >;

    Value() : type_(DataType::INT32), data_(int32_t(0)) {}
    
    explicit Value(int32_t v) : type_(DataType::INT32), data_(v) {}
    explicit Value(int64_t v) : type_(DataType::INT64), data_(v) {}
    explicit Value(float v) : type_(DataType::FLOAT), data_(v) {}
    explicit Value(double v) : type_(DataType::DOUBLE), data_(v) {}
    explicit Value(const std::string& v) : type_(DataType::STRING), data_(v) {}
    explicit Value(std::string&& v) : type_(DataType::STRING), data_(std::move(v)) {}
    explicit Value(bool v) : type_(DataType::BOOLEAN), data_(v) {}
    explicit Value(const std::vector<uint8_t>& v) : type_(DataType::BLOB), data_(v) {}

    DataType type() const { return type_; }
    const ValueType& data() const { return data_; }
    
    int32_t asInt32() const { return std::get<int32_t>(data_); }
    int64_t asInt64() const { return std::get<int64_t>(data_); }
    float asFloat() const { return std::get<float>(data_); }
    double asDouble() const { return std::get<double>(data_); }
    const std::string& asString() const { return std::get<std::string>(data_); }
    bool asBool() const { return std::get<bool>(data_); }
    const std::vector<uint8_t>& asBlob() const { return std::get<std::vector<uint8_t>>(data_); }

    std::string toString() const;
    size_t serializedSize() const;
    std::vector<uint8_t> serialize() const;
    static Value deserialize(const uint8_t* data, size_t& offset);

private:
    DataType type_;
    ValueType data_;
};

// Column definition
struct ColumnDef {
    std::string name;
    DataType type;
    bool is_primary_key;
    bool is_clustering_key;
    
    ColumnDef(const std::string& n, DataType t, bool pk = false, bool ck = false)
        : name(n), type(t), is_primary_key(pk), is_clustering_key(ck) {}
};

// Row representation
class Row {
public:
    Row() = default;
    
    void addColumn(const std::string& name, const Value& value) {
        columns_[name] = value;
    }
    
    void addColumn(const std::string& name, Value&& value) {
        columns_[name] = std::move(value);
    }
    
    const Value* getColumn(const std::string& name) const {
        auto it = columns_.find(name);
        return it != columns_.end() ? &it->second : nullptr;
    }
    
    const std::map<std::string, Value>& columns() const { return columns_; }
    
    std::vector<uint8_t> serialize() const;
    static Row deserialize(const uint8_t* data, size_t size);
    
private:
    std::map<std::string, Value> columns_;
};

// Table schema
class TableSchema {
public:
    TableSchema() = default;
    explicit TableSchema(const std::string& name) : table_name_(name) {}
    
    void setName(const std::string& name) { table_name_ = name; }
    const std::string& name() const { return table_name_; }
    
    void addColumn(const ColumnDef& col) {
        columns_.push_back(col);
        if (col.is_primary_key) {
            partition_keys_.push_back(col.name);
        }
        if (col.is_clustering_key) {
            clustering_keys_.push_back(col.name);
        }
    }
    
    const std::vector<ColumnDef>& columns() const { return columns_; }
    const std::vector<std::string>& partitionKeys() const { return partition_keys_; }
    const std::vector<std::string>& clusteringKeys() const { return clustering_keys_; }
    
    const ColumnDef* findColumn(const std::string& name) const {
        for (const auto& col : columns_) {
            if (col.name == name) return &col;
        }
        return nullptr;
    }
    
private:
    std::string table_name_;
    std::vector<ColumnDef> columns_;
    std::vector<std::string> partition_keys_;
    std::vector<std::string> clustering_keys_;
};

// Query result
struct QueryResult {
    bool success;
    std::string error_message;
    std::vector<Row> rows;
    uint64_t rows_affected;
    
    QueryResult() : success(true), rows_affected(0) {}
    
    static QueryResult ok(uint64_t affected = 0) {
        QueryResult r;
        r.success = true;
        r.rows_affected = affected;
        return r;
    }
    
    static QueryResult error(const std::string& msg) {
        QueryResult r;
        r.success = false;
        r.error_message = msg;
        return r;
    }
};

} // namespace kotana
