#include "thread_pool.h"

namespace kotana {

ThreadPool::ThreadPool(size_t num_threads)
    : stop_(false), paused_(false), active_threads_(0) {
    
    for (size_t i = 0; i < num_threads; ++i) {
        workers_.emplace_back(&ThreadPool::workerThread, this);
    }
}

ThreadPool::~ThreadPool() {
    {
        std::unique_lock<std::mutex> lock(queue_mutex_);
        stop_ = true;
    }
    condition_.notify_all();
    
    for (std::thread& worker : workers_) {
        if (worker.joinable()) {
            worker.join();
        }
    }
}

void ThreadPool::wait() {
    std::unique_lock<std::mutex> lock(queue_mutex_);
    condition_.wait(lock, [this] {
        return tasks_.empty() && active_threads_ == 0;
    });
}

size_t ThreadPool::getNumThreads() const {
    return workers_.size();
}

size_t ThreadPool::getQueueSize() const {
    std::unique_lock<std::mutex> lock(queue_mutex_);
    return tasks_.size();
}

size_t ThreadPool::getActiveThreads() const {
    return active_threads_.load();
}

void ThreadPool::pause() {
    paused_ = true;
}

void ThreadPool::resume() {
    paused_ = false;
    condition_.notify_all();
}

bool ThreadPool::isPaused() const {
    return paused_.load();
}

void ThreadPool::workerThread() {
    while (true) {
        std::function<void()> task;
        
        {
            std::unique_lock<std::mutex> lock(queue_mutex_);
            condition_.wait(lock, [this] {
                return stop_ || (!tasks_.empty() && !paused_);
            });
            
            if (stop_ && tasks_.empty()) {
                return;
            }
            
            if (!tasks_.empty()) {
                task = std::move(tasks_.front());
                tasks_.pop();
            }
        }
        
        if (task) {
            active_threads_++;
            task();
            active_threads_--;
            condition_.notify_all();
        }
    }
}

} // namespace kotana
