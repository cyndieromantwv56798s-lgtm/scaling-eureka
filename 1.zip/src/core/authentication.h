#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <chrono>
#include <set>

namespace kotana {

enum class Permission {
    CREATE,
    DROP,
    SELECT,
    INSERT,
    UPDATE,
    DELETE,
    ALTER,
    GRANT,
    REVOKE,
    ADMIN
};

enum class Role {
    ADMIN,
    DEVELOPER,
    ANALYST,
    READONLY,
    CUSTOM
};

struct User {
    std::string username;
    std::string password_hash;
    Role role;
    std::set<Permission> permissions;
    bool is_active;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point last_login;
    
    User();
    User(const std::string& user, const std::string& pass_hash, Role r);
};

struct Session {
    std::string session_id;
    std::string username;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point expires_at;
    std::string ip_address;
    
    bool isValid() const;
    bool isExpired() const;
};

class AuthenticationManager {
public:
    AuthenticationManager();
    ~AuthenticationManager();
    
    bool createUser(const std::string& username, const std::string& password, Role role);
    bool deleteUser(const std::string& username);
    bool authenticate(const std::string& username, const std::string& password);
    
    std::string createSession(const std::string& username, const std::string& ip_address);
    bool validateSession(const std::string& session_id);
    void invalidateSession(const std::string& session_id);
    
    bool hasPermission(const std::string& username, Permission perm);
    bool grantPermission(const std::string& username, Permission perm);
    bool revokePermission(const std::string& username, Permission perm);
    
    bool changePassword(const std::string& username, const std::string& old_password, 
                       const std::string& new_password);
    bool updateRole(const std::string& username, Role new_role);
    
    std::vector<std::string> listUsers();
    User* getUser(const std::string& username);
    
private:
    std::string hashPassword(const std::string& password);
    bool verifyPassword(const std::string& password, const std::string& hash);
    std::string generateSessionId();
    void cleanupExpiredSessions();
    std::set<Permission> getDefaultPermissions(Role role);
    
    std::map<std::string, User> users_;
    std::map<std::string, Session> sessions_;
    std::mutex auth_mutex_;
    std::chrono::hours session_duration_;
};

} // namespace kotana
