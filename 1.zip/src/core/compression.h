#pragma once

#include <string>
#include <vector>
#include <memory>
#include <map>

namespace kotana {

enum class CompressionAlgorithm {
    NONE,
    GZIP,
    LZ4,
    ZSTD,
    SNAPPY
};

struct CompressionStats {
    size_t original_size;
    size_t compressed_size;
    double compression_ratio;
    std::chrono::microseconds compression_time;
    std::chrono::microseconds decompression_time;
    
    CompressionStats();
};

class CompressionManager {
public:
    CompressionManager();
    ~CompressionManager();
    
    std::vector<uint8_t> compress(const std::vector<uint8_t>& data,
                                  CompressionAlgorithm algorithm = CompressionAlgorithm::LZ4);
    std::vector<uint8_t> decompress(const std::vector<uint8_t>& compressed_data,
                                    CompressionAlgorithm algorithm = CompressionAlgorithm::LZ4);
    
    std::string compressString(const std::string& str,
                              CompressionAlgorithm algorithm = CompressionAlgorithm::LZ4);
    std::string decompressString(const std::string& compressed_str,
                                CompressionAlgorithm algorithm = CompressionAlgorithm::LZ4);
    
    CompressionStats getStats(const std::vector<uint8_t>& data,
                             CompressionAlgorithm algorithm);
    
    void setDefaultAlgorithm(CompressionAlgorithm algorithm);
    CompressionAlgorithm getDefaultAlgorithm() const;
    
    void setCompressionLevel(int level);
    int getCompressionLevel() const;
    
    double estimateCompressionRatio(const std::vector<uint8_t>& data,
                                   CompressionAlgorithm algorithm);
    
    bool isCompressed(const std::vector<uint8_t>& data);
    CompressionAlgorithm detectAlgorithm(const std::vector<uint8_t>& data);

private:
    std::vector<uint8_t> compressGzip(const std::vector<uint8_t>& data);
    std::vector<uint8_t> decompressGzip(const std::vector<uint8_t>& data);
    
    std::vector<uint8_t> compressLZ4(const std::vector<uint8_t>& data);
    std::vector<uint8_t> decompressLZ4(const std::vector<uint8_t>& data);
    
    std::vector<uint8_t> compressZstd(const std::vector<uint8_t>& data);
    std::vector<uint8_t> decompressZstd(const std::vector<uint8_t>& data);
    
    std::vector<uint8_t> compressSnappy(const std::vector<uint8_t>& data);
    std::vector<uint8_t> decompressSnappy(const std::vector<uint8_t>& data);
    
    CompressionAlgorithm default_algorithm_;
    int compression_level_;
    std::map<CompressionAlgorithm, CompressionStats> stats_cache_;
};

} // namespace kotana
