#pragma once

#include <string>
#include <map>
#include <vector>
#include <chrono>
#include <atomic>
#include <mutex>
#include <memory>
#include <deque>

namespace kotana {

enum class MetricType {
    COUNTER,
    GAUGE,
    HISTOGRAM,
    TIMER
};

struct MetricValue {
    double value;
    std::chrono::system_clock::time_point timestamp;
    std::map<std::string, std::string> tags;
    
    MetricValue();
    MetricValue(double v);
};

struct HistogramBucket {
    double upper_bound;
    uint64_t count;
    
    HistogramBucket(double bound);
};

class Metric {
public:
    explicit Metric(const std::string& name, MetricType type);
    virtual ~Metric() = default;
    
    std::string getName() const;
    MetricType getType() const;
    
    virtual void record(double value) = 0;
    virtual double getValue() const = 0;
    virtual std::vector<MetricValue> getHistory(size_t count) const = 0;

protected:
    std::string name_;
    MetricType type_;
    mutable std::mutex metric_mutex_;
};

class Counter : public Metric {
public:
    explicit Counter(const std::string& name);
    
    void increment(double delta = 1.0);
    void record(double value) override;
    double getValue() const override;
    std::vector<MetricValue> getHistory(size_t count) const override;
    void reset();

private:
    std::atomic<double> value_;
    std::deque<MetricValue> history_;
    static const size_t MAX_HISTORY = 1000;
};

class Gauge : public Metric {
public:
    explicit Gauge(const std::string& name);
    
    void set(double value);
    void increment(double delta = 1.0);
    void decrement(double delta = 1.0);
    void record(double value) override;
    double getValue() const override;
    std::vector<MetricValue> getHistory(size_t count) const override;

private:
    std::atomic<double> value_;
    std::deque<MetricValue> history_;
    static const size_t MAX_HISTORY = 1000;
};

class Histogram : public Metric {
public:
    explicit Histogram(const std::string& name, const std::vector<double>& buckets);
    
    void observe(double value);
    void record(double value) override;
    double getValue() const override;
    std::vector<MetricValue> getHistory(size_t count) const override;
    
    std::vector<HistogramBucket> getBuckets() const;
    double getSum() const;
    uint64_t getCount() const;
    double getMean() const;

private:
    std::vector<HistogramBucket> buckets_;
    std::atomic<double> sum_;
    std::atomic<uint64_t> count_;
    std::deque<double> samples_;
    static const size_t MAX_SAMPLES = 10000;
};

class Timer : public Metric {
public:
    explicit Timer(const std::string& name);
    
    class Scope {
    public:
        explicit Scope(Timer& timer);
        ~Scope();
    private:
        Timer& timer_;
        std::chrono::high_resolution_clock::time_point start_;
    };
    
    void recordDuration(std::chrono::nanoseconds duration);
    void record(double value) override;
    double getValue() const override;
    std::vector<MetricValue> getHistory(size_t count) const override;
    
    double getMeanMs() const;
    double getP50Ms() const;
    double getP95Ms() const;
    double getP99Ms() const;
    uint64_t getCount() const;

private:
    std::deque<double> durations_ms_;
    std::atomic<uint64_t> count_;
    mutable std::mutex durations_mutex_;
    static const size_t MAX_DURATIONS = 10000;
};

class MonitoringSystem {
public:
    MonitoringSystem();
    ~MonitoringSystem();
    
    std::shared_ptr<Counter> createCounter(const std::string& name);
    std::shared_ptr<Gauge> createGauge(const std::string& name);
    std::shared_ptr<Histogram> createHistogram(const std::string& name,
                                               const std::vector<double>& buckets);
    std::shared_ptr<Timer> createTimer(const std::string& name);
    
    std::shared_ptr<Metric> getMetric(const std::string& name);
    std::vector<std::shared_ptr<Metric>> getAllMetrics();
    
    bool deleteMetric(const std::string& name);
    void clear();
    
    std::string exportPrometheus();
    std::map<std::string, double> getSnapshot();

private:
    std::map<std::string, std::shared_ptr<Metric>> metrics_;
    std::mutex metrics_mutex_;
};

} // namespace kotana
