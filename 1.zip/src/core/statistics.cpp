#include "statistics.h"
#include <algorithm>
#include <fstream>
#include <sstream>
#include <openssl/sha.h>
#include <iomanip>

namespace kotana {

QueryStatistics::QueryStatistics()
    : execution_count(0),
      total_execution_time(0),
      min_execution_time(std::chrono::microseconds::max()),
      max_execution_time(0),
      avg_execution_time(0),
      total_rows_scanned(0),
      total_rows_returned(0),
      first_seen(std::chrono::system_clock::now()),
      last_seen(std::chrono::system_clock::now()) {}

void QueryStatistics::update(std::chrono::microseconds exec_time,
                            uint64_t rows_scanned,
                            uint64_t rows_returned) {
    execution_count++;
    total_execution_time += exec_time;
    min_execution_time = std::min(min_execution_time, exec_time);
    max_execution_time = std::max(max_execution_time, exec_time);
    avg_execution_time = total_execution_time / execution_count;
    total_rows_scanned += rows_scanned;
    total_rows_returned += rows_returned;
    last_seen = std::chrono::system_clock::now();
}

TableStatistics::TableStatistics()
    : row_count(0),
      total_size_bytes(0),
      index_size_bytes(0),
      avg_row_size(0.0),
      last_analyzed(std::chrono::system_clock::now()),
      read_count(0),
      write_count(0),
      delete_count(0) {}

ColumnStatistics::ColumnStatistics()
    : data_type(DataType::STRING),
      distinct_count(0),
      null_count(0),
      avg_value(0.0) {}

SystemStatistics::SystemStatistics()
    : start_time(std::chrono::system_clock::now()),
      total_queries_executed(0),
      total_queries_failed(0),
      total_bytes_read(0),
      total_bytes_written(0),
      cache_hits(0),
      cache_misses(0),
      avg_query_latency_ms(0.0),
      active_connections(0),
      peak_connections(0) {}

StatisticsCollector::StatisticsCollector()
    : auto_analyze_(false),
      analyze_interval_(300),
      running_(false) {}

StatisticsCollector::~StatisticsCollector() {
    running_ = false;
    if (analyze_thread_.joinable()) {
        analyze_thread_.join();
    }
}

void StatisticsCollector::recordQuery(const std::string& query,
                                     std::chrono::microseconds exec_time,
                                     uint64_t rows_scanned,
                                     uint64_t rows_returned) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::string hash = hashQuery(query);
    
    auto& stats = query_stats_[hash];
    if (stats.execution_count == 0) {
        stats.query_hash = hash;
        stats.query_text = query;
    }
    
    stats.update(exec_time, rows_scanned, rows_returned);
    
    system_stats_.total_queries_executed++;
    
    double latency_ms = exec_time.count() / 1000.0;
    system_stats_.avg_query_latency_ms = 
        (system_stats_.avg_query_latency_ms * (system_stats_.total_queries_executed - 1) + latency_ms) /
        system_stats_.total_queries_executed;
    
    query_history_.push_back(hash);
    if (query_history_.size() > MAX_QUERY_STATS) {
        query_history_.pop_front();
    }
}

void StatisticsCollector::recordTableAccess(const std::string& table, bool is_write) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    auto& stats = table_stats_[table];
    if (stats.table_name.empty()) {
        stats.table_name = table;
    }
    
    if (is_write) {
        stats.write_count++;
        system_stats_.total_bytes_written += 1;
    } else {
        stats.read_count++;
        system_stats_.total_bytes_read += 1;
    }
}

void StatisticsCollector::recordCacheHit(bool hit) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    if (hit) {
        system_stats_.cache_hits++;
    } else {
        system_stats_.cache_misses++;
    }
}

void StatisticsCollector::recordError(const std::string& error_type) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    system_stats_.total_queries_failed++;
    system_stats_.error_counts[error_type]++;
}

void StatisticsCollector::recordConnection(bool connected) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    if (connected) {
        system_stats_.active_connections++;
        system_stats_.peak_connections = std::max(system_stats_.peak_connections,
                                                  system_stats_.active_connections);
    } else {
        if (system_stats_.active_connections > 0) {
            system_stats_.active_connections--;
        }
    }
}

QueryStatistics* StatisticsCollector::getQueryStatistics(const std::string& query_hash) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    auto it = query_stats_.find(query_hash);
    if (it == query_stats_.end()) {
        return nullptr;
    }
    return &it->second;
}

std::vector<QueryStatistics> StatisticsCollector::getTopQueries(size_t limit) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::vector<QueryStatistics> queries;
    for (const auto& [hash, stats] : query_stats_) {
        queries.push_back(stats);
    }
    
    std::sort(queries.begin(), queries.end(),
        [](const QueryStatistics& a, const QueryStatistics& b) {
            return a.total_execution_time > b.total_execution_time;
        });
    
    if (queries.size() > limit) {
        queries.resize(limit);
    }
    
    return queries;
}

std::vector<QueryStatistics> StatisticsCollector::getSlowestQueries(size_t limit) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::vector<QueryStatistics> queries;
    for (const auto& [hash, stats] : query_stats_) {
        queries.push_back(stats);
    }
    
    std::sort(queries.begin(), queries.end(),
        [](const QueryStatistics& a, const QueryStatistics& b) {
            return a.avg_execution_time > b.avg_execution_time;
        });
    
    if (queries.size() > limit) {
        queries.resize(limit);
    }
    
    return queries;
}

std::vector<QueryStatistics> StatisticsCollector::getMostFrequentQueries(size_t limit) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::vector<QueryStatistics> queries;
    for (const auto& [hash, stats] : query_stats_) {
        queries.push_back(stats);
    }
    
    std::sort(queries.begin(), queries.end(),
        [](const QueryStatistics& a, const QueryStatistics& b) {
            return a.execution_count > b.execution_count;
        });
    
    if (queries.size() > limit) {
        queries.resize(limit);
    }
    
    return queries;
}

TableStatistics* StatisticsCollector::getTableStatistics(const std::string& table) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    auto it = table_stats_.find(table);
    if (it == table_stats_.end()) {
        return nullptr;
    }
    return &it->second;
}

void StatisticsCollector::updateTableStatistics(const std::string& table) {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    auto& stats = table_stats_[table];
    if (stats.table_name.empty()) {
        stats.table_name = table;
    }
    stats.last_analyzed = std::chrono::system_clock::now();
}

void StatisticsCollector::analyzeTable(const std::string& table) {
    updateTableStatistics(table);
}

SystemStatistics StatisticsCollector::getSystemStatistics() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    return system_stats_;
}

void StatisticsCollector::resetStatistics() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    query_stats_.clear();
    table_stats_.clear();
    system_stats_ = SystemStatistics();
    query_history_.clear();
}

void StatisticsCollector::resetQueryStatistics() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    query_stats_.clear();
    query_history_.clear();
}

void StatisticsCollector::enableAutoAnalyze(bool enable) {
    auto_analyze_ = enable;
    
    if (enable && !running_) {
        running_ = true;
        analyze_thread_ = std::thread(&StatisticsCollector::autoAnalyzeLoop, this);
    } else if (!enable && running_) {
        running_ = false;
        if (analyze_thread_.joinable()) {
            analyze_thread_.join();
        }
    }
}

void StatisticsCollector::setAnalyzeInterval(std::chrono::seconds interval) {
    analyze_interval_ = interval;
}

std::string StatisticsCollector::exportCSV() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::ostringstream oss;
    oss << "query_hash,execution_count,avg_time_us,total_rows_scanned,total_rows_returned\n";
    
    for (const auto& [hash, stats] : query_stats_) {
        oss << hash << ","
            << stats.execution_count << ","
            << stats.avg_execution_time.count() << ","
            << stats.total_rows_scanned << ","
            << stats.total_rows_returned << "\n";
    }
    
    return oss.str();
}

std::string StatisticsCollector::exportJSON() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    std::ostringstream oss;
    oss << "{\n";
    oss << "  \"queries\": [\n";
    
    bool first = true;
    for (const auto& [hash, stats] : query_stats_) {
        if (!first) oss << ",\n";
        oss << "    {\n";
        oss << "      \"hash\": \"" << hash << "\",\n";
        oss << "      \"count\": " << stats.execution_count << ",\n";
        oss << "      \"avg_time_us\": " << stats.avg_execution_time.count() << "\n";
        oss << "    }";
        first = false;
    }
    
    oss << "\n  ]\n";
    oss << "}\n";
    
    return oss.str();
}

void StatisticsCollector::saveToFile(const std::string& filepath) {
    std::ofstream file(filepath);
    if (file.is_open()) {
        file << exportJSON();
        file.close();
    }
}

void StatisticsCollector::loadFromFile(const std::string& filepath) {
    std::ifstream file(filepath);
    if (file.is_open()) {
        file.close();
    }
}

std::string StatisticsCollector::hashQuery(const std::string& query) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(query.c_str()), query.size(), hash);
    
    std::stringstream ss;
    for (int i = 0; i < 8; ++i) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }
    return ss.str();
}

void StatisticsCollector::autoAnalyzeLoop() {
    while (running_) {
        std::this_thread::sleep_for(analyze_interval_);
        
        if (!running_) break;
        
        std::lock_guard<std::mutex> lock(stats_mutex_);
        for (auto& [table, stats] : table_stats_) {
            stats.last_analyzed = std::chrono::system_clock::now();
        }
    }
}

void StatisticsCollector::pruneOldStatistics() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    if (query_stats_.size() > MAX_QUERY_STATS) {
        std::vector<std::pair<std::string, uint64_t>> query_counts;
        for (const auto& [hash, stats] : query_stats_) {
            query_counts.push_back({hash, stats.execution_count});
        }
        
        std::sort(query_counts.begin(), query_counts.end(),
            [](const auto& a, const auto& b) {
                return a.second < b.second;
            });
        
        size_t to_remove = query_stats_.size() - MAX_QUERY_STATS;
        for (size_t i = 0; i < to_remove; ++i) {
            query_stats_.erase(query_counts[i].first);
        }
    }
}

} // namespace kotana
