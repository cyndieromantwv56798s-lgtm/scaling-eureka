#include "authentication.h"
#include <random>
#include <sstream>
#include <iomanip>
#include <cstring>
#include <openssl/sha.h>

namespace kotana {

User::User() 
    : role(Role::READONLY), 
      is_active(true),
      created_at(std::chrono::system_clock::now()),
      last_login(std::chrono::system_clock::now()) {}

User::User(const std::string& user, const std::string& pass_hash, Role r)
    : username(user),
      password_hash(pass_hash),
      role(r),
      is_active(true),
      created_at(std::chrono::system_clock::now()),
      last_login(std::chrono::system_clock::now()) {}

bool Session::isValid() const {
    return !isExpired();
}

bool Session::isExpired() const {
    return std::chrono::system_clock::now() > expires_at;
}

AuthenticationManager::AuthenticationManager()
    : session_duration_(24) {
    createUser("admin", "admin123", Role::ADMIN);
}

AuthenticationManager::~AuthenticationManager() = default;

bool AuthenticationManager::createUser(const std::string& username, const std::string& password, Role role) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    if (users_.find(username) != users_.end()) {
        return false;
    }
    
    std::string hash = hashPassword(password);
    User user(username, hash, role);
    user.permissions = getDefaultPermissions(role);
    
    users_[username] = user;
    return true;
}

bool AuthenticationManager::deleteUser(const std::string& username) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    if (username == "admin") {
        return false;
    }
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    for (auto session_it = sessions_.begin(); session_it != sessions_.end();) {
        if (session_it->second.username == username) {
            session_it = sessions_.erase(session_it);
        } else {
            ++session_it;
        }
    }
    
    users_.erase(it);
    return true;
}

bool AuthenticationManager::authenticate(const std::string& username, const std::string& password) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end() || !it->second.is_active) {
        return false;
    }
    
    if (verifyPassword(password, it->second.password_hash)) {
        it->second.last_login = std::chrono::system_clock::now();
        return true;
    }
    
    return false;
}

std::string AuthenticationManager::createSession(const std::string& username, const std::string& ip_address) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    if (users_.find(username) == users_.end()) {
        return "";
    }
    
    Session session;
    session.session_id = generateSessionId();
    session.username = username;
    session.created_at = std::chrono::system_clock::now();
    session.expires_at = session.created_at + session_duration_;
    session.ip_address = ip_address;
    
    sessions_[session.session_id] = session;
    cleanupExpiredSessions();
    
    return session.session_id;
}

bool AuthenticationManager::validateSession(const std::string& session_id) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = sessions_.find(session_id);
    if (it == sessions_.end()) {
        return false;
    }
    
    return it->second.isValid();
}

void AuthenticationManager::invalidateSession(const std::string& session_id) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    sessions_.erase(session_id);
}

bool AuthenticationManager::hasPermission(const std::string& username, Permission perm) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    return it->second.permissions.count(perm) > 0 || 
           it->second.permissions.count(Permission::ADMIN) > 0;
}

bool AuthenticationManager::grantPermission(const std::string& username, Permission perm) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    it->second.permissions.insert(perm);
    return true;
}

bool AuthenticationManager::revokePermission(const std::string& username, Permission perm) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    it->second.permissions.erase(perm);
    return true;
}

bool AuthenticationManager::changePassword(const std::string& username, 
                                          const std::string& old_password,
                                          const std::string& new_password) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    if (!verifyPassword(old_password, it->second.password_hash)) {
        return false;
    }
    
    it->second.password_hash = hashPassword(new_password);
    return true;
}

bool AuthenticationManager::updateRole(const std::string& username, Role new_role) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return false;
    }
    
    it->second.role = new_role;
    it->second.permissions = getDefaultPermissions(new_role);
    return true;
}

std::vector<std::string> AuthenticationManager::listUsers() {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    std::vector<std::string> usernames;
    for (const auto& [username, user] : users_) {
        usernames.push_back(username);
    }
    return usernames;
}

User* AuthenticationManager::getUser(const std::string& username) {
    std::lock_guard<std::mutex> lock(auth_mutex_);
    
    auto it = users_.find(username);
    if (it == users_.end()) {
        return nullptr;
    }
    return &it->second;
}

std::string AuthenticationManager::hashPassword(const std::string& password) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(password.c_str()), password.size(), hash);
    
    std::stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; ++i) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(hash[i]);
    }
    return ss.str();
}

bool AuthenticationManager::verifyPassword(const std::string& password, const std::string& hash) {
    return hashPassword(password) == hash;
}

std::string AuthenticationManager::generateSessionId() {
    static std::random_device rd;
    static std::mt19937_64 gen(rd());
    static std::uniform_int_distribution<uint64_t> dis;
    
    uint64_t id = dis(gen);
    std::stringstream ss;
    ss << std::hex << id;
    return ss.str();
}

void AuthenticationManager::cleanupExpiredSessions() {
    for (auto it = sessions_.begin(); it != sessions_.end();) {
        if (it->second.isExpired()) {
            it = sessions_.erase(it);
        } else {
            ++it;
        }
    }
}

std::set<Permission> AuthenticationManager::getDefaultPermissions(Role role) {
    std::set<Permission> perms;
    
    switch (role) {
        case Role::ADMIN:
            perms.insert(Permission::ADMIN);
            perms.insert(Permission::CREATE);
            perms.insert(Permission::DROP);
            perms.insert(Permission::SELECT);
            perms.insert(Permission::INSERT);
            perms.insert(Permission::UPDATE);
            perms.insert(Permission::DELETE);
            perms.insert(Permission::ALTER);
            perms.insert(Permission::GRANT);
            perms.insert(Permission::REVOKE);
            break;
        case Role::DEVELOPER:
            perms.insert(Permission::CREATE);
            perms.insert(Permission::SELECT);
            perms.insert(Permission::INSERT);
            perms.insert(Permission::UPDATE);
            perms.insert(Permission::DELETE);
            break;
        case Role::ANALYST:
            perms.insert(Permission::SELECT);
            break;
        case Role::READONLY:
            perms.insert(Permission::SELECT);
            break;
        case Role::CUSTOM:
            break;
    }
    
    return perms;
}

} // namespace kotana
