#pragma once

#include <string>
#include <map>
#include <mutex>
#include <chrono>
#include <deque>
#include <atomic>

namespace kotana {

enum class RateLimitAlgorithm {
    TOKEN_BUCKET,
    LEAKY_BUCKET,
    FIXED_WINDOW,
    SLIDING_WINDOW
};

struct RateLimitConfig {
    size_t max_requests;
    std::chrono::seconds window_duration;
    RateLimitAlgorithm algorithm;
    bool enable_burst;
    size_t burst_size;
    
    RateLimitConfig();
};

struct RateLimitInfo {
    size_t remaining_requests;
    std::chrono::system_clock::time_point reset_time;
    bool is_limited;
    std::chrono::milliseconds retry_after;
    
    RateLimitInfo();
};

class RateLimiter {
public:
    explicit RateLimiter(const RateLimitConfig& config);
    ~RateLimiter();
    
    bool allowRequest(const std::string& client_id);
    RateLimitInfo getInfo(const std::string& client_id);
    
    void setConfig(const RateLimitConfig& config);
    RateLimitConfig getConfig() const;
    
    void reset(const std::string& client_id);
    void resetAll();
    
    size_t getClientCount() const;
    std::vector<std::string> getBlockedClients();

private:
    bool allowTokenBucket(const std::string& client_id);
    bool allowLeakyBucket(const std::string& client_id);
    bool allowFixedWindow(const std::string& client_id);
    bool allowSlidingWindow(const std::string& client_id);
    
    void refillTokens(const std::string& client_id);
    
    struct ClientState {
        size_t tokens;
        std::chrono::system_clock::time_point last_refill;
        std::deque<std::chrono::system_clock::time_point> request_times;
        size_t requests_in_window;
        std::chrono::system_clock::time_point window_start;
    };
    
    RateLimitConfig config_;
    std::map<std::string, ClientState> client_states_;
    mutable std::mutex limiter_mutex_;
};

} // namespace kotana
