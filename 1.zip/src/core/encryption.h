#pragma once

#include <string>
#include <vector>
#include <memory>
#include <map>

namespace kotana {

enum class EncryptionAlgorithm {
    AES_128,
    AES_256,
    CHACHA20,
    NONE
};

enum class KeyDerivationFunction {
    PBKDF2,
    SCRYPT,
    ARGON2
};

struct EncryptionKey {
    std::vector<uint8_t> key_data;
    EncryptionAlgorithm algorithm;
    std::string key_id;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point expires_at;
    bool is_active;
    
    EncryptionKey();
};

class EncryptionManager {
public:
    EncryptionManager();
    ~EncryptionManager();
    
    std::string generateKey(EncryptionAlgorithm algorithm);
    bool loadKey(const std::string& key_id, const std::vector<uint8_t>& key_data);
    bool deleteKey(const std::string& key_id);
    
    std::vector<uint8_t> encrypt(const std::vector<uint8_t>& plaintext, 
                                 const std::string& key_id);
    std::vector<uint8_t> decrypt(const std::vector<uint8_t>& ciphertext,
                                 const std::string& key_id);
    
    std::string encryptString(const std::string& plaintext, const std::string& key_id);
    std::string decryptString(const std::string& ciphertext, const std::string& key_id);
    
    std::vector<uint8_t> deriveKey(const std::string& password,
                                   const std::vector<uint8_t>& salt,
                                   KeyDerivationFunction kdf,
                                   size_t key_length);
    
    std::vector<uint8_t> generateSalt(size_t length = 32);
    std::vector<uint8_t> generateIV(size_t length = 16);
    
    bool rotateKey(const std::string& old_key_id, const std::string& new_key_id);
    std::vector<std::string> listKeys();
    
    void enableEncryptionAtRest(bool enable);
    void enableEncryptionInTransit(bool enable);
    bool isEncryptionAtRestEnabled() const;
    bool isEncryptionInTransitEnabled() const;

private:
    std::vector<uint8_t> encryptAES(const std::vector<uint8_t>& plaintext,
                                    const std::vector<uint8_t>& key,
                                    const std::vector<uint8_t>& iv);
    std::vector<uint8_t> decryptAES(const std::vector<uint8_t>& ciphertext,
                                    const std::vector<uint8_t>& key,
                                    const std::vector<uint8_t>& iv);
    
    std::map<std::string, EncryptionKey> keys_;
    std::string active_key_id_;
    bool encryption_at_rest_;
    bool encryption_in_transit_;
    std::mutex encryption_mutex_;
};

} // namespace kotana
