#include "compression.h"
#include <zlib.h>
#include <chrono>
#include <cstring>

namespace kotana {

CompressionStats::CompressionStats()
    : original_size(0),
      compressed_size(0),
      compression_ratio(0.0) {}

CompressionManager::CompressionManager()
    : default_algorithm_(CompressionAlgorithm::LZ4),
      compression_level_(6) {}

CompressionManager::~CompressionManager() = default;

std::vector<uint8_t> CompressionManager::compress(const std::vector<uint8_t>& data,
                                                  CompressionAlgorithm algorithm) {
    if (algorithm == CompressionAlgorithm::NONE) {
        return data;
    }
    
    switch (algorithm) {
        case CompressionAlgorithm::GZIP:
            return compressGzip(data);
        case CompressionAlgorithm::LZ4:
            return compressLZ4(data);
        case CompressionAlgorithm::ZSTD:
            return compressZstd(data);
        case CompressionAlgorithm::SNAPPY:
            return compressSnappy(data);
        default:
            return data;
    }
}

std::vector<uint8_t> CompressionManager::decompress(const std::vector<uint8_t>& compressed_data,
                                                    CompressionAlgorithm algorithm) {
    if (algorithm == CompressionAlgorithm::NONE) {
        return compressed_data;
    }
    
    switch (algorithm) {
        case CompressionAlgorithm::GZIP:
            return decompressGzip(compressed_data);
        case CompressionAlgorithm::LZ4:
            return decompressLZ4(compressed_data);
        case CompressionAlgorithm::ZSTD:
            return decompressZstd(compressed_data);
        case CompressionAlgorithm::SNAPPY:
            return decompressSnappy(compressed_data);
        default:
            return compressed_data;
    }
}

std::string CompressionManager::compressString(const std::string& str,
                                              CompressionAlgorithm algorithm) {
    std::vector<uint8_t> data(str.begin(), str.end());
    auto compressed = compress(data, algorithm);
    return std::string(compressed.begin(), compressed.end());
}

std::string CompressionManager::decompressString(const std::string& compressed_str,
                                                CompressionAlgorithm algorithm) {
    std::vector<uint8_t> compressed(compressed_str.begin(), compressed_str.end());
    auto decompressed = decompress(compressed, algorithm);
    return std::string(decompressed.begin(), decompressed.end());
}

CompressionStats CompressionManager::getStats(const std::vector<uint8_t>& data,
                                             CompressionAlgorithm algorithm) {
    auto start = std::chrono::high_resolution_clock::now();
    auto compressed = compress(data, algorithm);
    auto compress_end = std::chrono::high_resolution_clock::now();
    auto decompressed = decompress(compressed, algorithm);
    auto decompress_end = std::chrono::high_resolution_clock::now();
    
    CompressionStats stats;
    stats.original_size = data.size();
    stats.compressed_size = compressed.size();
    stats.compression_ratio = stats.original_size > 0 ? 
        static_cast<double>(stats.compressed_size) / stats.original_size : 0.0;
    stats.compression_time = std::chrono::duration_cast<std::chrono::microseconds>(
        compress_end - start);
    stats.decompression_time = std::chrono::duration_cast<std::chrono::microseconds>(
        decompress_end - compress_end);
    
    return stats;
}

void CompressionManager::setDefaultAlgorithm(CompressionAlgorithm algorithm) {
    default_algorithm_ = algorithm;
}

CompressionAlgorithm CompressionManager::getDefaultAlgorithm() const {
    return default_algorithm_;
}

void CompressionManager::setCompressionLevel(int level) {
    compression_level_ = std::max(1, std::min(9, level));
}

int CompressionManager::getCompressionLevel() const {
    return compression_level_;
}

double CompressionManager::estimateCompressionRatio(const std::vector<uint8_t>& data,
                                                    CompressionAlgorithm algorithm) {
    if (data.empty()) return 0.0;
    
    size_t sample_size = std::min(data.size(), size_t(1024));
    std::vector<uint8_t> sample(data.begin(), data.begin() + sample_size);
    
    auto compressed = compress(sample, algorithm);
    return static_cast<double>(compressed.size()) / sample_size;
}

bool CompressionManager::isCompressed(const std::vector<uint8_t>& data) {
    if (data.size() < 2) return false;
    
    if (data[0] == 0x1f && data[1] == 0x8b) {
        return true;
    }
    
    return false;
}

CompressionAlgorithm CompressionManager::detectAlgorithm(const std::vector<uint8_t>& data) {
    if (data.size() < 2) return CompressionAlgorithm::NONE;
    
    if (data[0] == 0x1f && data[1] == 0x8b) {
        return CompressionAlgorithm::GZIP;
    }
    
    return CompressionAlgorithm::NONE;
}

std::vector<uint8_t> CompressionManager::compressGzip(const std::vector<uint8_t>& data) {
    uLongf compressed_size = compressBound(data.size());
    std::vector<uint8_t> compressed(compressed_size);
    
    int result = compress2(compressed.data(), &compressed_size,
                          data.data(), data.size(), compression_level_);
    
    if (result != Z_OK) {
        return data;
    }
    
    compressed.resize(compressed_size);
    return compressed;
}

std::vector<uint8_t> CompressionManager::decompressGzip(const std::vector<uint8_t>& data) {
    uLongf decompressed_size = data.size() * 4;
    std::vector<uint8_t> decompressed(decompressed_size);
    
    int result = uncompress(decompressed.data(), &decompressed_size,
                           data.data(), data.size());
    
    if (result != Z_OK) {
        return data;
    }
    
    decompressed.resize(decompressed_size);
    return decompressed;
}

std::vector<uint8_t> CompressionManager::compressLZ4(const std::vector<uint8_t>& data) {
    return data;
}

std::vector<uint8_t> CompressionManager::decompressLZ4(const std::vector<uint8_t>& data) {
    return data;
}

std::vector<uint8_t> CompressionManager::compressZstd(const std::vector<uint8_t>& data) {
    return data;
}

std::vector<uint8_t> CompressionManager::decompressZstd(const std::vector<uint8_t>& data) {
    return data;
}

std::vector<uint8_t> CompressionManager::compressSnappy(const std::vector<uint8_t>& data) {
    return data;
}

std::vector<uint8_t> CompressionManager::decompressSnappy(const std::vector<uint8_t>& data) {
    return data;
}

} // namespace kotana
