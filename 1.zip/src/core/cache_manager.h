#pragma once

#include <string>
#include <map>
#include <memory>
#include <mutex>
#include <chrono>
#include <list>
#include <atomic>

namespace kotana {

enum class CacheEvictionPolicy {
    LRU,
    LFU,
    FIFO,
    RANDOM,
    TTL
};

template<typename K, typename V>
struct CacheEntry {
    K key;
    V value;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point last_accessed;
    size_t access_count;
    std::chrono::seconds ttl;
    
    CacheEntry(const K& k, const V& v)
        : key(k), value(v), 
          created_at(std::chrono::system_clock::now()),
          last_accessed(std::chrono::system_clock::now()),
          access_count(0),
          ttl(0) {}
    
    bool isExpired() const {
        if (ttl.count() == 0) return false;
        auto now = std::chrono::system_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - created_at);
        return elapsed >= ttl;
    }
};

template<typename K, typename V>
class CacheManager {
public:
    explicit CacheManager(size_t max_size, CacheEvictionPolicy policy = CacheEvictionPolicy::LRU)
        : max_size_(max_size), policy_(policy), hits_(0), misses_(0) {}
    
    bool put(const K& key, const V& value, std::chrono::seconds ttl = std::chrono::seconds(0)) {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        
        if (cache_.size() >= max_size_ && cache_.find(key) == cache_.end()) {
            evict();
        }
        
        auto entry = std::make_shared<CacheEntry<K, V>>(key, value);
        entry->ttl = ttl;
        
        cache_[key] = entry;
        access_order_.push_front(key);
        
        return true;
    }
    
    bool get(const K& key, V& value) {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            misses_++;
            return false;
        }
        
        if (it->second->isExpired()) {
            cache_.erase(it);
            misses_++;
            return false;
        }
        
        value = it->second->value;
        it->second->last_accessed = std::chrono::system_clock::now();
        it->second->access_count++;
        
        updateAccessOrder(key);
        hits_++;
        
        return true;
    }
    
    bool remove(const K& key) {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        auto it = cache_.find(key);
        if (it == cache_.end()) {
            return false;
        }
        cache_.erase(it);
        access_order_.remove(key);
        return true;
    }
    
    void clear() {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        cache_.clear();
        access_order_.clear();
        hits_ = 0;
        misses_ = 0;
    }
    
    size_t size() const {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        return cache_.size();
    }
    
    bool contains(const K& key) const {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        auto it = cache_.find(key);
        return it != cache_.end() && !it->second->isExpired();
    }
    
    double getHitRate() const {
        uint64_t total = hits_ + misses_;
        return total > 0 ? static_cast<double>(hits_) / total : 0.0;
    }
    
    uint64_t getHits() const { return hits_.load(); }
    uint64_t getMisses() const { return misses_.load(); }
    
    void setMaxSize(size_t max_size) {
        std::lock_guard<std::mutex> lock(cache_mutex_);
        max_size_ = max_size;
        while (cache_.size() > max_size_) {
            evict();
        }
    }
    
    void setEvictionPolicy(CacheEvictionPolicy policy) {
        policy_ = policy;
    }

private:
    void evict() {
        if (cache_.empty()) return;
        
        K key_to_evict;
        
        switch (policy_) {
            case CacheEvictionPolicy::LRU:
                key_to_evict = access_order_.back();
                access_order_.pop_back();
                break;
            
            case CacheEvictionPolicy::FIFO:
                key_to_evict = access_order_.back();
                access_order_.pop_back();
                break;
            
            case CacheEvictionPolicy::LFU: {
                auto min_it = cache_.begin();
                for (auto it = cache_.begin(); it != cache_.end(); ++it) {
                    if (it->second->access_count < min_it->second->access_count) {
                        min_it = it;
                    }
                }
                key_to_evict = min_it->first;
                access_order_.remove(key_to_evict);
                break;
            }
            
            default:
                key_to_evict = access_order_.back();
                access_order_.pop_back();
                break;
        }
        
        cache_.erase(key_to_evict);
    }
    
    void updateAccessOrder(const K& key) {
        if (policy_ == CacheEvictionPolicy::LRU) {
            access_order_.remove(key);
            access_order_.push_front(key);
        }
    }
    
    std::map<K, std::shared_ptr<CacheEntry<K, V>>> cache_;
    std::list<K> access_order_;
    size_t max_size_;
    CacheEvictionPolicy policy_;
    std::atomic<uint64_t> hits_;
    std::atomic<uint64_t> misses_;
    mutable std::mutex cache_mutex_;
};

} // namespace kotana
