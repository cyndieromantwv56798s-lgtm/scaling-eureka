#include "monitoring.h"
#include <algorithm>
#include <numeric>
#include <sstream>
#include <cmath>

namespace kotana {

MetricValue::MetricValue()
    : value(0.0), timestamp(std::chrono::system_clock::now()) {}

MetricValue::MetricValue(double v)
    : value(v), timestamp(std::chrono::system_clock::now()) {}

HistogramBucket::HistogramBucket(double bound)
    : upper_bound(bound), count(0) {}

Metric::Metric(const std::string& name, MetricType type)
    : name_(name), type_(type) {}

std::string Metric::getName() const {
    return name_;
}

MetricType Metric::getType() const {
    return type_;
}

Counter::Counter(const std::string& name)
    : Metric(name, MetricType::COUNTER), value_(0.0) {}

void Counter::increment(double delta) {
    value_.fetch_add(delta);
    std::lock_guard<std::mutex> lock(metric_mutex_);
    history_.push_back(MetricValue(value_.load()));
    if (history_.size() > MAX_HISTORY) {
        history_.pop_front();
    }
}

void Counter::record(double value) {
    increment(value);
}

double Counter::getValue() const {
    return value_.load();
}

std::vector<MetricValue> Counter::getHistory(size_t count) const {
    std::lock_guard<std::mutex> lock(metric_mutex_);
    size_t start = history_.size() > count ? history_.size() - count : 0;
    return std::vector<MetricValue>(history_.begin() + start, history_.end());
}

void Counter::reset() {
    value_ = 0.0;
    std::lock_guard<std::mutex> lock(metric_mutex_);
    history_.clear();
}

Gauge::Gauge(const std::string& name)
    : Metric(name, MetricType::GAUGE), value_(0.0) {}

void Gauge::set(double value) {
    value_ = value;
    std::lock_guard<std::mutex> lock(metric_mutex_);
    history_.push_back(MetricValue(value));
    if (history_.size() > MAX_HISTORY) {
        history_.pop_front();
    }
}

void Gauge::increment(double delta) {
    value_.fetch_add(delta);
    set(value_.load());
}

void Gauge::decrement(double delta) {
    value_.fetch_sub(delta);
    set(value_.load());
}

void Gauge::record(double value) {
    set(value);
}

double Gauge::getValue() const {
    return value_.load();
}

std::vector<MetricValue> Gauge::getHistory(size_t count) const {
    std::lock_guard<std::mutex> lock(metric_mutex_);
    size_t start = history_.size() > count ? history_.size() - count : 0;
    return std::vector<MetricValue>(history_.begin() + start, history_.end());
}

Histogram::Histogram(const std::string& name, const std::vector<double>& buckets)
    : Metric(name, MetricType::HISTOGRAM), sum_(0.0), count_(0) {
    for (double bound : buckets) {
        buckets_.emplace_back(bound);
    }
    std::sort(buckets_.begin(), buckets_.end(),
              [](const HistogramBucket& a, const HistogramBucket& b) {
                  return a.upper_bound < b.upper_bound;
              });
}

void Histogram::observe(double value) {
    sum_.fetch_add(value);
    count_.fetch_add(1);
    
    std::lock_guard<std::mutex> lock(metric_mutex_);
    for (auto& bucket : buckets_) {
        if (value <= bucket.upper_bound) {
            bucket.count++;
        }
    }
    
    samples_.push_back(value);
    if (samples_.size() > MAX_SAMPLES) {
        samples_.pop_front();
    }
}

void Histogram::record(double value) {
    observe(value);
}

double Histogram::getValue() const {
    return getMean();
}

std::vector<MetricValue> Histogram::getHistory(size_t count) const {
    std::lock_guard<std::mutex> lock(metric_mutex_);
    std::vector<MetricValue> result;
    size_t start = samples_.size() > count ? samples_.size() - count : 0;
    for (size_t i = start; i < samples_.size(); ++i) {
        result.push_back(MetricValue(samples_[i]));
    }
    return result;
}

std::vector<HistogramBucket> Histogram::getBuckets() const {
    std::lock_guard<std::mutex> lock(metric_mutex_);
    return buckets_;
}

double Histogram::getSum() const {
    return sum_.load();
}

uint64_t Histogram::getCount() const {
    return count_.load();
}

double Histogram::getMean() const {
    uint64_t cnt = count_.load();
    return cnt > 0 ? sum_.load() / cnt : 0.0;
}

Timer::Timer(const std::string& name)
    : Metric(name, MetricType::TIMER), count_(0) {}

Timer::Scope::Scope(Timer& timer)
    : timer_(timer), start_(std::chrono::high_resolution_clock::now()) {}

Timer::Scope::~Scope() {
    auto end = std::chrono::high_resolution_clock::now();
    timer_.recordDuration(std::chrono::duration_cast<std::chrono::nanoseconds>(end - start_));
}

void Timer::recordDuration(std::chrono::nanoseconds duration) {
    double ms = duration.count() / 1000000.0;
    
    std::lock_guard<std::mutex> lock(durations_mutex_);
    durations_ms_.push_back(ms);
    if (durations_ms_.size() > MAX_DURATIONS) {
        durations_ms_.pop_front();
    }
    count_.fetch_add(1);
}

void Timer::record(double value) {
    recordDuration(std::chrono::nanoseconds(static_cast<int64_t>(value * 1000000)));
}

double Timer::getValue() const {
    return getMeanMs();
}

std::vector<MetricValue> Timer::getHistory(size_t count) const {
    std::lock_guard<std::mutex> lock(durations_mutex_);
    std::vector<MetricValue> result;
    size_t start = durations_ms_.size() > count ? durations_ms_.size() - count : 0;
    for (size_t i = start; i < durations_ms_.size(); ++i) {
        result.push_back(MetricValue(durations_ms_[i]));
    }
    return result;
}

double Timer::getMeanMs() const {
    std::lock_guard<std::mutex> lock(durations_mutex_);
    if (durations_ms_.empty()) return 0.0;
    return std::accumulate(durations_ms_.begin(), durations_ms_.end(), 0.0) / durations_ms_.size();
}

double Timer::getP50Ms() const {
    std::lock_guard<std::mutex> lock(durations_mutex_);
    if (durations_ms_.empty()) return 0.0;
    
    std::vector<double> sorted(durations_ms_.begin(), durations_ms_.end());
    std::sort(sorted.begin(), sorted.end());
    return sorted[sorted.size() / 2];
}

double Timer::getP95Ms() const {
    std::lock_guard<std::mutex> lock(durations_mutex_);
    if (durations_ms_.empty()) return 0.0;
    
    std::vector<double> sorted(durations_ms_.begin(), durations_ms_.end());
    std::sort(sorted.begin(), sorted.end());
    size_t idx = static_cast<size_t>(sorted.size() * 0.95);
    return sorted[std::min(idx, sorted.size() - 1)];
}

double Timer::getP99Ms() const {
    std::lock_guard<std::mutex> lock(durations_mutex_);
    if (durations_ms_.empty()) return 0.0;
    
    std::vector<double> sorted(durations_ms_.begin(), durations_ms_.end());
    std::sort(sorted.begin(), sorted.end());
    size_t idx = static_cast<size_t>(sorted.size() * 0.99);
    return sorted[std::min(idx, sorted.size() - 1)];
}

uint64_t Timer::getCount() const {
    return count_.load();
}

MonitoringSystem::MonitoringSystem() = default;

MonitoringSystem::~MonitoringSystem() = default;

std::shared_ptr<Counter> MonitoringSystem::createCounter(const std::string& name) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    if (metrics_.find(name) != metrics_.end()) {
        return std::dynamic_pointer_cast<Counter>(metrics_[name]);
    }
    
    auto counter = std::make_shared<Counter>(name);
    metrics_[name] = counter;
    return counter;
}

std::shared_ptr<Gauge> MonitoringSystem::createGauge(const std::string& name) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    if (metrics_.find(name) != metrics_.end()) {
        return std::dynamic_pointer_cast<Gauge>(metrics_[name]);
    }
    
    auto gauge = std::make_shared<Gauge>(name);
    metrics_[name] = gauge;
    return gauge;
}

std::shared_ptr<Histogram> MonitoringSystem::createHistogram(const std::string& name,
                                                            const std::vector<double>& buckets) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    if (metrics_.find(name) != metrics_.end()) {
        return std::dynamic_pointer_cast<Histogram>(metrics_[name]);
    }
    
    auto histogram = std::make_shared<Histogram>(name, buckets);
    metrics_[name] = histogram;
    return histogram;
}

std::shared_ptr<Timer> MonitoringSystem::createTimer(const std::string& name) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    if (metrics_.find(name) != metrics_.end()) {
        return std::dynamic_pointer_cast<Timer>(metrics_[name]);
    }
    
    auto timer = std::make_shared<Timer>(name);
    metrics_[name] = timer;
    return timer;
}

std::shared_ptr<Metric> MonitoringSystem::getMetric(const std::string& name) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    auto it = metrics_.find(name);
    if (it == metrics_.end()) {
        return nullptr;
    }
    return it->second;
}

std::vector<std::shared_ptr<Metric>> MonitoringSystem::getAllMetrics() {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    std::vector<std::shared_ptr<Metric>> result;
    for (const auto& [name, metric] : metrics_) {
        result.push_back(metric);
    }
    return result;
}

bool MonitoringSystem::deleteMetric(const std::string& name) {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    return metrics_.erase(name) > 0;
}

void MonitoringSystem::clear() {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    metrics_.clear();
}

std::string MonitoringSystem::exportPrometheus() {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    std::ostringstream oss;
    for (const auto& [name, metric] : metrics_) {
        oss << "# TYPE " << name << " ";
        switch (metric->getType()) {
            case MetricType::COUNTER:
                oss << "counter\n";
                break;
            case MetricType::GAUGE:
                oss << "gauge\n";
                break;
            case MetricType::HISTOGRAM:
                oss << "histogram\n";
                break;
            case MetricType::TIMER:
                oss << "summary\n";
                break;
        }
        oss << name << " " << metric->getValue() << "\n";
    }
    return oss.str();
}

std::map<std::string, double> MonitoringSystem::getSnapshot() {
    std::lock_guard<std::mutex> lock(metrics_mutex_);
    
    std::map<std::string, double> snapshot;
    for (const auto& [name, metric] : metrics_) {
        snapshot[name] = metric->getValue();
    }
    return snapshot;
}

} // namespace kotana
