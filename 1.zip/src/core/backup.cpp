#include "backup.h"
#include <fstream>
#include <sstream>
#include <random>
#include <zlib.h>
#include <sys/stat.h>

namespace kotana {

BackupMetadata::BackupMetadata()
    : type(BackupType::FULL),
      compression(CompressionType::NONE),
      created_at(std::chrono::system_clock::now()),
      data_size(0),
      compressed_size(0) {}

RestoreOptions::RestoreOptions()
    : verify_integrity(true),
      overwrite_existing(false) {}

BackupManager::BackupManager(std::shared_ptr<StorageEngine> storage)
    : storage_(storage),
      backup_directory_("./backups") {
    #ifdef __linux__
    mkdir(backup_directory_.c_str(), 0755);
    #endif
    loadMetadata();
}

BackupManager::~BackupManager() = default;

std::string BackupManager::createBackup(BackupType type, CompressionType compression,
                                       const std::string& description) {
    std::lock_guard<std::mutex> lock(backup_mutex_);
    
    std::string backup_id = generateBackupId();
    
    bool success = false;
    switch (type) {
        case BackupType::FULL:
            success = createFullBackup(backup_id, compression);
            break;
        case BackupType::INCREMENTAL:
            success = createIncrementalBackup(backup_id, compression);
            break;
        case BackupType::DIFFERENTIAL:
            success = createDifferentialBackup(backup_id, compression);
            break;
    }
    
    if (!success) {
        return "";
    }
    
    BackupMetadata metadata;
    metadata.backup_id = backup_id;
    metadata.type = type;
    metadata.compression = compression;
    metadata.description = description;
    metadata.created_at = std::chrono::system_clock::now();
    
    if (type == BackupType::FULL) {
        last_full_backup_id_ = backup_id;
    } else {
        metadata.parent_backup_id = last_full_backup_id_;
    }
    
    backups_[backup_id] = metadata;
    saveMetadata(metadata);
    
    return backup_id;
}

bool BackupManager::restoreBackup(const RestoreOptions& options) {
    std::lock_guard<std::mutex> lock(backup_mutex_);
    
    auto it = backups_.find(options.backup_id);
    if (it == backups_.end()) {
        return false;
    }
    
    if (options.verify_integrity && !verifyBackup(options.backup_id)) {
        return false;
    }
    
    auto data = readBackupFile(options.backup_id);
    if (data.empty()) {
        return false;
    }
    
    if (it->second.compression != CompressionType::NONE) {
        data = decompressData(data, it->second.compression);
    }
    
    return true;
}

bool BackupManager::deleteBackup(const std::string& backup_id) {
    std::lock_guard<std::mutex> lock(backup_mutex_);
    
    auto it = backups_.find(backup_id);
    if (it == backups_.end()) {
        return false;
    }
    
    std::string filepath = backup_directory_ + "/" + backup_id + ".bak";
    std::remove(filepath.c_str());
    
    backups_.erase(it);
    return true;
}

std::vector<BackupMetadata> BackupManager::listBackups() {
    std::lock_guard<std::mutex> lock(backup_mutex_);
    
    std::vector<BackupMetadata> result;
    for (const auto& [id, metadata] : backups_) {
        result.push_back(metadata);
    }
    return result;
}

BackupMetadata* BackupManager::getBackupMetadata(const std::string& backup_id) {
    std::lock_guard<std::mutex> lock(backup_mutex_);
    
    auto it = backups_.find(backup_id);
    if (it == backups_.end()) {
        return nullptr;
    }
    return &it->second;
}

bool BackupManager::verifyBackup(const std::string& backup_id) {
    auto data = readBackupFile(backup_id);
    return !data.empty();
}

size_t BackupManager::getBackupSize(const std::string& backup_id) {
    auto it = backups_.find(backup_id);
    if (it == backups_.end()) {
        return 0;
    }
    return it->second.compressed_size;
}

void BackupManager::setBackupDirectory(const std::string& directory) {
    backup_directory_ = directory;
    #ifdef __linux__
    mkdir(backup_directory_.c_str(), 0755);
    #endif
}

std::string BackupManager::getBackupDirectory() const {
    return backup_directory_;
}

void BackupManager::scheduleAutomaticBackup(std::chrono::hours interval, BackupType type) {
}

void BackupManager::cancelAutomaticBackup() {
}

std::string BackupManager::generateBackupId() {
    static std::random_device rd;
    static std::mt19937_64 gen(rd());
    static std::uniform_int_distribution<uint64_t> dis;
    
    auto now = std::chrono::system_clock::now();
    auto timestamp = std::chrono::duration_cast<std::chrono::seconds>(
        now.time_since_epoch()).count();
    
    std::stringstream ss;
    ss << "backup_" << timestamp << "_" << std::hex << dis(gen);
    return ss.str();
}

bool BackupManager::createFullBackup(const std::string& backup_id, CompressionType compression) {
    storage_->flush();
    
    std::vector<uint8_t> data;
    
    if (compression != CompressionType::NONE) {
        data = compressData(data, compression);
    }
    
    return writeBackupFile(backup_id, data);
}

bool BackupManager::createIncrementalBackup(const std::string& backup_id, CompressionType compression) {
    if (last_full_backup_id_.empty()) {
        return createFullBackup(backup_id, compression);
    }
    
    std::vector<uint8_t> data;
    
    if (compression != CompressionType::NONE) {
        data = compressData(data, compression);
    }
    
    return writeBackupFile(backup_id, data);
}

bool BackupManager::createDifferentialBackup(const std::string& backup_id, CompressionType compression) {
    if (last_full_backup_id_.empty()) {
        return createFullBackup(backup_id, compression);
    }
    
    std::vector<uint8_t> data;
    
    if (compression != CompressionType::NONE) {
        data = compressData(data, compression);
    }
    
    return writeBackupFile(backup_id, data);
}

std::vector<uint8_t> BackupManager::compressData(const std::vector<uint8_t>& data, CompressionType type) {
    if (type == CompressionType::GZIP) {
        uLongf compressed_size = compressBound(data.size());
        std::vector<uint8_t> compressed(compressed_size);
        
        compress(compressed.data(), &compressed_size, data.data(), data.size());
        compressed.resize(compressed_size);
        return compressed;
    }
    
    return data;
}

std::vector<uint8_t> BackupManager::decompressData(const std::vector<uint8_t>& data, CompressionType type) {
    if (type == CompressionType::GZIP) {
        uLongf decompressed_size = data.size() * 4;
        std::vector<uint8_t> decompressed(decompressed_size);
        
        uncompress(decompressed.data(), &decompressed_size, data.data(), data.size());
        decompressed.resize(decompressed_size);
        return decompressed;
    }
    
    return data;
}

bool BackupManager::writeBackupFile(const std::string& backup_id, const std::vector<uint8_t>& data) {
    std::string filepath = backup_directory_ + "/" + backup_id + ".bak";
    std::ofstream file(filepath, std::ios::binary);
    
    if (!file.is_open()) {
        return false;
    }
    
    file.write(reinterpret_cast<const char*>(data.data()), data.size());
    file.close();
    
    return true;
}

std::vector<uint8_t> BackupManager::readBackupFile(const std::string& backup_id) {
    std::string filepath = backup_directory_ + "/" + backup_id + ".bak";
    std::ifstream file(filepath, std::ios::binary | std::ios::ate);
    
    if (!file.is_open()) {
        return {};
    }
    
    size_t size = file.tellg();
    file.seekg(0, std::ios::beg);
    
    std::vector<uint8_t> data(size);
    file.read(reinterpret_cast<char*>(data.data()), size);
    file.close();
    
    return data;
}

void BackupManager::saveMetadata(const BackupMetadata& metadata) {
}

void BackupManager::loadMetadata() {
}

} // namespace kotana
