#pragma once

#include "cluster.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <atomic>
#include <chrono>

namespace kotana {

enum class ProposalType {
    READ,
    WRITE,
    DELETE,
    SCHEMA_CHANGE,
    CLUSTER_CONFIG
};

enum class ProposalStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    COMMITTED,
    ABORTED
};

struct Proposal {
    std::string proposal_id;
    ProposalType type;
    ProposalStatus status;
    std::string proposer_node_id;
    std::vector<uint8_t> data;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point committed_at;
    uint64_t ballot_number;
    std::map<std::string, bool> votes;
    size_t required_votes;
    
    Proposal();
    bool hasQuorum() const;
    size_t getAcceptVotes() const;
    size_t getRejectVotes() const;
};

struct ConsensusState {
    uint64_t current_ballot;
    std::string current_leader;
    std::map<std::string, Proposal> active_proposals;
    std::chrono::system_clock::time_point last_heartbeat;
    bool in_leader_election;
    
    ConsensusState();
};

class DistributedCoordinator {
public:
    explicit DistributedCoordinator(std::shared_ptr<ClusterManager> cluster);
    ~DistributedCoordinator();
    
    bool start();
    void stop();
    bool isRunning() const;
    
    std::string proposeWrite(const std::string& key, const std::vector<uint8_t>& value);
    std::string proposeRead(const std::string& key);
    std::string proposeDelete(const std::string& key);
    std::string proposeSchemaChange(const std::string& change_description);
    
    bool commitProposal(const std::string& proposal_id);
    bool abortProposal(const std::string& proposal_id);
    ProposalStatus getProposalStatus(const std::string& proposal_id);
    
    bool voteOnProposal(const std::string& proposal_id, bool accept);
    std::vector<Proposal> getPendingProposals();
    
    bool electLeader();
    bool isLeader() const;
    std::string getCurrentLeader() const;
    
    void handleNodeFailure(const std::string& node_id);
    void handleNodeRecovery(const std::string& node_id);
    
    ConsensusState getConsensusState() const;
    
    void setQuorumSize(size_t size);
    size_t getQuorumSize() const;
    
    void enableAutoCommit(bool enable);
    void setCommitTimeout(std::chrono::milliseconds timeout);

private:
    std::string generateProposalId();
    void coordinationLoop();
    void leaderElectionLoop();
    void proposalTimeoutLoop();
    
    bool sendProposal(const Proposal& proposal, const std::string& node_id);
    bool collectVotes(Proposal& proposal);
    void notifyCommit(const std::string& proposal_id);
    void notifyAbort(const std::string& proposal_id);
    
    uint64_t getNextBallotNumber();
    bool canProposeAsLeader();
    
    std::shared_ptr<ClusterManager> cluster_;
    ConsensusState state_;
    
    std::atomic<bool> running_;
    std::mutex coordinator_mutex_;
    
    std::thread coordination_thread_;
    std::thread leader_election_thread_;
    std::thread timeout_thread_;
    
    size_t quorum_size_;
    bool auto_commit_;
    std::chrono::milliseconds commit_timeout_;
    std::atomic<uint64_t> ballot_counter_;
};

} // namespace kotana
