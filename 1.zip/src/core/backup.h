#pragma once

#include "storage/storage_engine.h"
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <map>
#include <mutex>

namespace kotana {

enum class BackupType {
    FULL,
    INCREMENTAL,
    DIFFERENTIAL
};

enum class CompressionType {
    NONE,
    GZIP,
    LZ4,
    ZSTD
};

struct BackupMetadata {
    std::string backup_id;
    BackupType type;
    CompressionType compression;
    std::chrono::system_clock::time_point created_at;
    size_t data_size;
    size_t compressed_size;
    std::string description;
    std::vector<std::string> included_tables;
    std::string parent_backup_id;
    
    BackupMetadata();
};

struct RestoreOptions {
    std::string backup_id;
    bool verify_integrity;
    bool overwrite_existing;
    std::vector<std::string> tables_to_restore;
    std::string target_directory;
    
    RestoreOptions();
};

class BackupManager {
public:
    explicit BackupManager(std::shared_ptr<StorageEngine> storage);
    ~BackupManager();
    
    std::string createBackup(BackupType type, CompressionType compression,
                            const std::string& description = "");
    bool restoreBackup(const RestoreOptions& options);
    bool deleteBackup(const std::string& backup_id);
    
    std::vector<BackupMetadata> listBackups();
    BackupMetadata* getBackupMetadata(const std::string& backup_id);
    
    bool verifyBackup(const std::string& backup_id);
    size_t getBackupSize(const std::string& backup_id);
    
    void setBackupDirectory(const std::string& directory);
    std::string getBackupDirectory() const;
    
    void scheduleAutomaticBackup(std::chrono::hours interval, BackupType type);
    void cancelAutomaticBackup();
    
private:
    std::string generateBackupId();
    bool createFullBackup(const std::string& backup_id, CompressionType compression);
    bool createIncrementalBackup(const std::string& backup_id, CompressionType compression);
    bool createDifferentialBackup(const std::string& backup_id, CompressionType compression);
    
    std::vector<uint8_t> compressData(const std::vector<uint8_t>& data, CompressionType type);
    std::vector<uint8_t> decompressData(const std::vector<uint8_t>& data, CompressionType type);
    
    bool writeBackupFile(const std::string& backup_id, const std::vector<uint8_t>& data);
    std::vector<uint8_t> readBackupFile(const std::string& backup_id);
    
    void saveMetadata(const BackupMetadata& metadata);
    void loadMetadata();
    
    std::shared_ptr<StorageEngine> storage_;
    std::string backup_directory_;
    std::map<std::string, BackupMetadata> backups_;
    std::mutex backup_mutex_;
    std::string last_full_backup_id_;
};

} // namespace kotana
