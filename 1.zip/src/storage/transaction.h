#pragma once

#include "core/types.h"
#include "core/utils.h"
#include <map>
#include <set>
#include <vector>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <atomic>
#include <optional>
#include <chrono>

namespace kotana {

enum class IsolationLevel {
    READ_UNCOMMITTED,
    READ_COMMITTED,
    REPEATABLE_READ,
    SERIALIZABLE
};

enum class TransactionState {
    ACTIVE,
    PREPARING,
    PREPARED,
    COMMITTING,
    COMMITTED,
    ABORTING,
    ABORTED
};

class Transaction {
public:
    using TransactionId = uint64_t;
    
    explicit Transaction(TransactionId id, IsolationLevel isolation = IsolationLevel::READ_COMMITTED)
        : id_(id),
          isolation_level_(isolation),
          state_(TransactionState::ACTIVE),
          start_timestamp_(Utils::getCurrentTimestamp()),
          commit_timestamp_(0) {}
    
    TransactionId id() const { return id_; }
    IsolationLevel isolationLevel() const { return isolation_level_; }
    TransactionState state() const { return state_; }
    
    uint64_t startTimestamp() const { return start_timestamp_; }
    uint64_t commitTimestamp() const { return commit_timestamp_; }
    
    void addRead(const std::string& key) {
        std::unique_lock<std::mutex> lock(mutex_);
        read_set_.insert(key);
    }
    
    void addWrite(const std::string& key, const Row& row) {
        std::unique_lock<std::mutex> lock(mutex_);
        write_set_[key] = row;
    }
    
    void addDelete(const std::string& key) {
        std::unique_lock<std::mutex> lock(mutex_);
        delete_set_.insert(key);
        write_set_.erase(key);
    }
    
    const std::set<std::string>& readSet() const { return read_set_; }
    const std::map<std::string, Row>& writeSet() const { return write_set_; }
    const std::set<std::string>& deleteSet() const { return delete_set_; }
    
    bool prepare() {
        TransactionState expected = TransactionState::ACTIVE;
        if (state_.compare_exchange_strong(expected, TransactionState::PREPARING)) {
            state_ = TransactionState::PREPARED;
            return true;
        }
        return false;
    }
    
    bool commit() {
        TransactionState expected = TransactionState::PREPARED;
        if (!state_.compare_exchange_strong(expected, TransactionState::COMMITTING)) {
            expected = TransactionState::ACTIVE;
            if (!state_.compare_exchange_strong(expected, TransactionState::COMMITTING)) {
                return false;
            }
        }
        
        commit_timestamp_ = Utils::getCurrentTimestamp();
        state_ = TransactionState::COMMITTED;
        return true;
    }
    
    bool abort() {
        TransactionState expected = state_.load();
        if (expected == TransactionState::COMMITTED || expected == TransactionState::ABORTED) {
            return false;
        }
        
        state_ = TransactionState::ABORTING;
        
        std::unique_lock<std::mutex> lock(mutex_);
        read_set_.clear();
        write_set_.clear();
        delete_set_.clear();
        
        state_ = TransactionState::ABORTED;
        return true;
    }
    
    bool isActive() const {
        auto s = state_.load();
        return s == TransactionState::ACTIVE || s == TransactionState::PREPARING;
    }
    
    bool isCommitted() const {
        return state_.load() == TransactionState::COMMITTED;
    }
    
    bool isAborted() const {
        return state_.load() == TransactionState::ABORTED;
    }
    
    uint64_t duration() const {
        uint64_t end = commit_timestamp_ > 0 ? commit_timestamp_ : Utils::getCurrentTimestamp();
        return end - start_timestamp_;
    }

private:
    TransactionId id_;
    IsolationLevel isolation_level_;
    std::atomic<TransactionState> state_;
    
    uint64_t start_timestamp_;
    uint64_t commit_timestamp_;
    
    std::set<std::string> read_set_;
    std::map<std::string, Row> write_set_;
    std::set<std::string> delete_set_;
    
    mutable std::mutex mutex_;
};

class TransactionManager {
public:
    using TransactionId = Transaction::TransactionId;
    
    TransactionManager()
        : next_transaction_id_(1),
          active_transactions_(0),
          committed_transactions_(0),
          aborted_transactions_(0) {}
    
    std::shared_ptr<Transaction> begin(IsolationLevel isolation = IsolationLevel::READ_COMMITTED) {
        TransactionId id = next_transaction_id_++;
        auto txn = std::make_shared<Transaction>(id, isolation);
        
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            transactions_[id] = txn;
        }
        
        ++active_transactions_;
        return txn;
    }
    
    bool commit(TransactionId id) {
        auto txn = getTransaction(id);
        if (!txn) {
            return false;
        }
        
        if (!validateTransaction(txn)) {
            abort(id);
            return false;
        }
        
        if (!txn->prepare()) {
            return false;
        }
        
        if (!txn->commit()) {
            return false;
        }
        
        applyWrites(txn);
        
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            transactions_.erase(id);
        }
        
        --active_transactions_;
        ++committed_transactions_;
        
        return true;
    }
    
    bool abort(TransactionId id) {
        auto txn = getTransaction(id);
        if (!txn) {
            return false;
        }
        
        if (!txn->abort()) {
            return false;
        }
        
        {
            std::unique_lock<std::shared_mutex> lock(mutex_);
            transactions_.erase(id);
        }
        
        --active_transactions_;
        ++aborted_transactions_;
        
        return true;
    }
    
    std::shared_ptr<Transaction> getTransaction(TransactionId id) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        auto it = transactions_.find(id);
        return it != transactions_.end() ? it->second : nullptr;
    }
    
    std::vector<std::shared_ptr<Transaction>> getActiveTransactions() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::vector<std::shared_ptr<Transaction>> result;
        result.reserve(transactions_.size());
        
        for (const auto& [_, txn] : transactions_) {
            if (txn->isActive()) {
                result.push_back(txn);
            }
        }
        
        return result;
    }
    
    bool hasConflict(const std::shared_ptr<Transaction>& txn, const std::string& key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        for (const auto& [_, other_txn] : transactions_) {
            if (other_txn->id() == txn->id()) {
                continue;
            }
            
            if (!other_txn->isActive()) {
                continue;
            }
            
            if (other_txn->writeSet().count(key) > 0 || 
                other_txn->deleteSet().count(key) > 0) {
                return true;
            }
        }
        
        return false;
    }
    
    size_t activeTransactionCount() const { return active_transactions_.load(); }
    size_t committedTransactionCount() const { return committed_transactions_.load(); }
    size_t abortedTransactionCount() const { return aborted_transactions_.load(); }
    
    void getStats(std::map<std::string, uint64_t>& stats) const {
        stats["active_transactions"] = active_transactions_.load();
        stats["committed_transactions"] = committed_transactions_.load();
        stats["aborted_transactions"] = aborted_transactions_.load();
        stats["total_transactions"] = next_transaction_id_.load() - 1;
    }
    
    void cleanupOldTransactions(uint64_t max_age_ms) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        uint64_t now = Utils::getCurrentTimestamp();
        std::vector<TransactionId> to_remove;
        
        for (const auto& [id, txn] : transactions_) {
            if (!txn->isActive() && txn->duration() > max_age_ms * 1000) {
                to_remove.push_back(id);
            }
        }
        
        for (auto id : to_remove) {
            transactions_.erase(id);
        }
    }

private:
    bool validateTransaction(const std::shared_ptr<Transaction>& txn) const {
        switch (txn->isolationLevel()) {
            case IsolationLevel::READ_UNCOMMITTED:
                return true;
            
            case IsolationLevel::READ_COMMITTED:
                return validateReadCommitted(txn);
            
            case IsolationLevel::REPEATABLE_READ:
                return validateRepeatableRead(txn);
            
            case IsolationLevel::SERIALIZABLE:
                return validateSerializable(txn);
            
            default:
                return true;
        }
    }
    
    bool validateReadCommitted(const std::shared_ptr<Transaction>& txn) const {
        for (const auto& [key, _] : txn->writeSet()) {
            if (hasConflict(txn, key)) {
                return false;
            }
        }
        
        for (const auto& key : txn->deleteSet()) {
            if (hasConflict(txn, key)) {
                return false;
            }
        }
        
        return true;
    }
    
    bool validateRepeatableRead(const std::shared_ptr<Transaction>& txn) const {
        for (const auto& key : txn->readSet()) {
            if (hasWriteConflict(txn, key)) {
                return false;
            }
        }
        
        return validateReadCommitted(txn);
    }
    
    bool validateSerializable(const std::shared_ptr<Transaction>& txn) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        for (const auto& [_, other_txn] : transactions_) {
            if (other_txn->id() == txn->id()) {
                continue;
            }
            
            if (!other_txn->isActive()) {
                continue;
            }
            
            if (hasReadWriteConflict(txn, other_txn) ||
                hasWriteReadConflict(txn, other_txn) ||
                hasWriteWriteConflict(txn, other_txn)) {
                return false;
            }
        }
        
        return true;
    }
    
    bool hasWriteConflict(const std::shared_ptr<Transaction>& txn, const std::string& key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        for (const auto& [_, other_txn] : transactions_) {
            if (other_txn->id() == txn->id()) {
                continue;
            }
            
            if (!other_txn->isActive()) {
                continue;
            }
            
            if (other_txn->startTimestamp() > txn->startTimestamp() &&
                (other_txn->writeSet().count(key) > 0 || other_txn->deleteSet().count(key) > 0)) {
                return true;
            }
        }
        
        return false;
    }
    
    bool hasReadWriteConflict(const std::shared_ptr<Transaction>& txn,
                             const std::shared_ptr<Transaction>& other) const {
        for (const auto& key : txn->readSet()) {
            if (other->writeSet().count(key) > 0 || other->deleteSet().count(key) > 0) {
                return true;
            }
        }
        return false;
    }
    
    bool hasWriteReadConflict(const std::shared_ptr<Transaction>& txn,
                             const std::shared_ptr<Transaction>& other) const {
        for (const auto& [key, _] : txn->writeSet()) {
            if (other->readSet().count(key) > 0) {
                return true;
            }
        }
        
        for (const auto& key : txn->deleteSet()) {
            if (other->readSet().count(key) > 0) {
                return true;
            }
        }
        
        return false;
    }
    
    bool hasWriteWriteConflict(const std::shared_ptr<Transaction>& txn,
                              const std::shared_ptr<Transaction>& other) const {
        for (const auto& [key, _] : txn->writeSet()) {
            if (other->writeSet().count(key) > 0 || other->deleteSet().count(key) > 0) {
                return true;
            }
        }
        
        for (const auto& key : txn->deleteSet()) {
            if (other->writeSet().count(key) > 0 || other->deleteSet().count(key) > 0) {
                return true;
            }
        }
        
        return false;
    }
    
    void applyWrites(const std::shared_ptr<Transaction>& txn) {
    }
    
    std::atomic<TransactionId> next_transaction_id_;
    std::atomic<size_t> active_transactions_;
    std::atomic<size_t> committed_transactions_;
    std::atomic<size_t> aborted_transactions_;
    
    std::map<TransactionId, std::shared_ptr<Transaction>> transactions_;
    mutable std::shared_mutex mutex_;
};

class MVCCVersionManager {
public:
    struct Version {
        Row row;
        uint64_t transaction_id;
        uint64_t timestamp;
        bool deleted;
        
        Version() : transaction_id(0), timestamp(0), deleted(false) {}
        Version(const Row& r, uint64_t txn_id, uint64_t ts)
            : row(r), transaction_id(txn_id), timestamp(ts), deleted(false) {}
    };
    
    MVCCVersionManager() = default;
    
    void addVersion(const std::string& key, const Row& row, uint64_t txn_id) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        uint64_t timestamp = Utils::getCurrentTimestamp();
        versions_[key].emplace_back(row, txn_id, timestamp);
        
        if (versions_[key].size() > 100) {
            cleanupVersions(key);
        }
    }
    
    void deleteVersion(const std::string& key, uint64_t txn_id) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        uint64_t timestamp = Utils::getCurrentTimestamp();
        Version v;
        v.transaction_id = txn_id;
        v.timestamp = timestamp;
        v.deleted = true;
        
        versions_[key].push_back(v);
    }
    
    bool getVersion(const std::string& key, uint64_t as_of_timestamp, Row& row) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        auto it = versions_.find(key);
        if (it == versions_.end()) {
            return false;
        }
        
        const Version* best_version = nullptr;
        
        for (const auto& version : it->second) {
            if (version.timestamp <= as_of_timestamp) {
                if (!best_version || version.timestamp > best_version->timestamp) {
                    best_version = &version;
                }
            }
        }
        
        if (best_version && !best_version->deleted) {
            row = best_version->row;
            return true;
        }
        
        return false;
    }
    
    std::vector<Version> getAllVersions(const std::string& key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        auto it = versions_.find(key);
        if (it != versions_.end()) {
            return it->second;
        }
        
        return {};
    }
    
    void cleanup(uint64_t before_timestamp) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        for (auto& [key, version_list] : versions_) {
            cleanupVersions(key, before_timestamp);
        }
    }
    
    size_t totalVersions() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        size_t total = 0;
        for (const auto& [_, version_list] : versions_) {
            total += version_list.size();
        }
        return total;
    }

private:
    void cleanupVersions(const std::string& key, uint64_t before_timestamp = 0) {
        auto& version_list = versions_[key];
        
        if (version_list.size() <= 10) {
            return;
        }
        
        std::sort(version_list.begin(), version_list.end(),
            [](const Version& a, const Version& b) {
                return a.timestamp > b.timestamp;
            });
        
        size_t keep_count = 10;
        if (before_timestamp > 0) {
            for (size_t i = 0; i < version_list.size(); ++i) {
                if (version_list[i].timestamp < before_timestamp) {
                    keep_count = i + 1;
                    break;
                }
            }
        }
        
        if (version_list.size() > keep_count) {
            version_list.resize(keep_count);
        }
    }
    
    std::map<std::string, std::vector<Version>> versions_;
    mutable std::shared_mutex mutex_;
};

} // namespace kotana
