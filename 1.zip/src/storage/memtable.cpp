#include "memtable.h"

namespace kotana {

MemTable::MemTable(size_t max_size) 
    : max_size_(max_size), current_size_(0), num_entries_(0) {}

bool MemTable::put(const std::string& key, const Row& row) {
    std::unique_lock<std::shared_mutex> lock(mutex_);
    
    auto serialized = row.serialize();
    size_t entry_size = key.size() + serialized.size();
    
    if (current_size_ + entry_size > max_size_) {
        return false;
    }
    
    auto it = data_.find(key);
    if (it != data_.end()) {
        current_size_ -= it->second.size();
    }
    
    data_[key] = std::move(serialized);
    current_size_ += entry_size;
    ++num_entries_;
    
    return true;
}

bool MemTable::get(const std::string& key, Row& row) const {
    std::shared_lock<std::shared_mutex> lock(mutex_);
    
    auto it = data_.find(key);
    if (it == data_.end()) {
        return false;
    }
    
    row = Row::deserialize(it->second.data(), it->second.size());
    return true;
}

bool MemTable::remove(const std::string& key) {
    std::unique_lock<std::shared_mutex> lock(mutex_);
    
    auto it = data_.find(key);
    if (it == data_.end()) {
        return false;
    }
    
    current_size_ -= (key.size() + it->second.size());
    data_.erase(it);
    --num_entries_;
    
    return true;
}

bool MemTable::isFull() const {
    return current_size_.load() >= max_size_;
}

size_t MemTable::size() const {
    return current_size_.load();
}

size_t MemTable::numEntries() const {
    return num_entries_.load();
}

size_t MemTable::maxSize() const {
    return max_size_;
}

void MemTable::clear() {
    std::unique_lock<std::shared_mutex> lock(mutex_);
    data_.clear();
    current_size_ = 0;
    num_entries_ = 0;
}

std::map<std::string, std::vector<uint8_t>> MemTable::snapshot() const {
    std::shared_lock<std::shared_mutex> lock(mutex_);
    return data_;
}

void MemTable::forEach(std::function<void(const std::string&, const Row&)> callback) const {
    std::shared_lock<std::shared_mutex> lock(mutex_);
    for (const auto& [key, data] : data_) {
        Row row = Row::deserialize(data.data(), data.size());
        callback(key, row);
    }
}

} // namespace kotana
