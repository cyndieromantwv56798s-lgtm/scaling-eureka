#pragma once

#include "core/types.h"
#include <map>
#include <mutex>
#include <atomic>
#include <memory>
#include <shared_mutex>
#include <functional>

namespace kotana {

class MemTable {
public:
    explicit MemTable(size_t max_size = 64 * 1024 * 1024);
    
    bool put(const std::string& key, const Row& row);
    bool get(const std::string& key, Row& row) const;
    bool remove(const std::string& key);
    
    bool isFull() const;
    size_t size() const;
    size_t numEntries() const;
    size_t maxSize() const;
    
    void clear();
    std::map<std::string, std::vector<uint8_t>> snapshot() const;
    void forEach(std::function<void(const std::string&, const Row&)> callback) const;

private:
    size_t max_size_;
    std::atomic<size_t> current_size_;
    std::atomic<size_t> num_entries_;
    std::map<std::string, std::vector<uint8_t>> data_;
    mutable std::shared_mutex mutex_;
};

} // namespace kotana
