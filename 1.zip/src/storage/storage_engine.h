#pragma once

#include "memtable.h"
#include "sstable.h"
#include "wal.h"
#include "core/types.h"
#include <vector>
#include <memory>
#include <string>
#include <mutex>
#include <thread>
#include <atomic>
#include <condition_variable>

namespace kotana {

class StorageEngine {
public:
    struct Config {
        std::string data_dir;
        size_t memtable_size;
        size_t num_memtables;
        size_t compaction_threshold;
        bool enable_wal;
        
        Config();
    };
    
    StorageEngine();
    explicit StorageEngine(const Config& config);
    ~StorageEngine();
    
    bool put(const std::string& key, const Row& row);
    bool get(const std::string& key, Row& row);
    bool remove(const std::string& key);
    
    void flush();
    void compact();
    void shutdown();
    
    size_t memtableSize() const;
    size_t sstableCount() const;
    void getStats(std::map<std::string, uint64_t>& stats);
    
    std::vector<std::string> getAllKeys(const std::string& prefix = "");
    bool exists(const std::string& key);

private:
    void createDataDirectory();
    void flushMemTable();
    void writeSSTable(const std::map<std::string, std::vector<uint8_t>>& data);
    void loadSSTables();
    void recoverFromWAL();
    void triggerCompaction();
    void compactionWorker();
    void performCompaction();
    uint64_t getTotalSSTableSize() const;
    
    Config config_;
    std::shared_ptr<MemTable> current_memtable_;
    std::vector<std::shared_ptr<MemTable>> immutable_memtables_;
    std::vector<std::shared_ptr<SSTable>> sstables_;
    std::unique_ptr<WriteAheadLog> wal_;
    
    std::atomic<uint64_t> next_sstable_id_;
    std::atomic<bool> compaction_running_;
    std::atomic<bool> shutdown_;
    std::atomic<uint64_t> total_writes_{0};
    std::atomic<uint64_t> total_reads_{0};
    std::atomic<uint64_t> total_compactions_{0};
    
    std::mutex write_mutex_;
    mutable std::shared_mutex immutable_mutex_;
    mutable std::shared_mutex sstable_mutex_;
    std::mutex compaction_mutex_;
    std::condition_variable compaction_cv_;
    std::thread compaction_thread_;
};

} // namespace kotana
