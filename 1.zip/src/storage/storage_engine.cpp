#include "storage_engine.h"
#include <sys/stat.h>
#include <algorithm>
#include <thread>

namespace kotana {

StorageEngine::Config::Config()
    : data_dir("./data"), 
      memtable_size(64 * 1024 * 1024), 
      num_memtables(3), 
      compaction_threshold(4), 
      enable_wal(true) {}

StorageEngine::StorageEngine()
    : StorageEngine(Config()) {}

StorageEngine::StorageEngine(const Config& config)
    : config_(config),
      next_sstable_id_(0),
      compaction_running_(false),
      shutdown_(false) {
    
    createDataDirectory();
    
    current_memtable_ = std::make_shared<MemTable>(config_.memtable_size);
    
    if (config_.enable_wal) {
        wal_ = std::make_unique<WriteAheadLog>(config_.data_dir + "/wal.log");
        recoverFromWAL();
    }
    
    loadSSTables();
    
    compaction_thread_ = std::thread(&StorageEngine::compactionWorker, this);
}

StorageEngine::~StorageEngine() {
    shutdown();
}

bool StorageEngine::put(const std::string& key, const Row& row) {
    std::lock_guard<std::mutex> lock(write_mutex_);
    
    if (wal_) {
        wal_->appendPut(key, row);
    }
    
    if (current_memtable_->isFull()) {
        flushMemTable();
    }
    
    return current_memtable_->put(key, row);
}

bool StorageEngine::get(const std::string& key, Row& row) {
    if (current_memtable_->get(key, row)) {
        return true;
    }
    
    {
        std::shared_lock<std::shared_mutex> lock(immutable_mutex_);
        for (const auto& memtable : immutable_memtables_) {
            if (memtable->get(key, row)) {
                return true;
            }
        }
    }
    
    {
        std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
        for (auto it = sstables_.rbegin(); it != sstables_.rend(); ++it) {
            if ((*it)->get(key, row)) {
                return true;
            }
        }
    }
    
    return false;
}

bool StorageEngine::remove(const std::string& key) {
    std::lock_guard<std::mutex> lock(write_mutex_);
    
    if (wal_) {
        wal_->appendDelete(key);
    }
    
    if (current_memtable_->isFull()) {
        flushMemTable();
    }
    
    return current_memtable_->remove(key);
}

void StorageEngine::flush() {
    std::lock_guard<std::mutex> lock(write_mutex_);
    flushMemTable();
    
    if (wal_) {
        wal_->sync();
    }
}

void StorageEngine::compact() {
    triggerCompaction();
}

void StorageEngine::shutdown() {
    if (shutdown_.exchange(true)) {
        return;
    }
    
    flush();
    
    {
        std::lock_guard<std::mutex> lock(compaction_mutex_);
        compaction_cv_.notify_all();
    }
    
    if (compaction_thread_.joinable()) {
        compaction_thread_.join();
    }
}

size_t StorageEngine::memtableSize() const {
    return current_memtable_->size();
}

size_t StorageEngine::sstableCount() const {
    std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
    return sstables_.size();
}

void StorageEngine::getStats(std::map<std::string, uint64_t>& stats) {
    stats["memtable_size"] = current_memtable_->size();
    stats["memtable_entries"] = current_memtable_->numEntries();
    stats["immutable_memtables"] = immutable_memtables_.size();
    stats["sstable_count"] = sstableCount();
    stats["total_sstable_size"] = getTotalSSTableSize();
    stats["total_writes"] = total_writes_.load();
    stats["total_reads"] = total_reads_.load();
    stats["total_compactions"] = total_compactions_.load();
}

std::vector<std::string> StorageEngine::getAllKeys(const std::string& prefix) {
    std::vector<std::string> keys;
    
    current_memtable_->forEach([&keys, &prefix](const std::string& key, const Row&) {
        if (prefix.empty() || key.substr(0, prefix.size()) == prefix) {
            keys.push_back(key);
        }
    });
    
    return keys;
}

bool StorageEngine::exists(const std::string& key) {
    Row row;
    return get(key, row);
}

void StorageEngine::createDataDirectory() {
    #ifdef __linux__
    mkdir(config_.data_dir.c_str(), 0755);
    #endif
}

void StorageEngine::flushMemTable() {
    auto snapshot = current_memtable_->snapshot();
    if (snapshot.empty()) {
        return;
    }
    
    {
        std::unique_lock<std::shared_mutex> lock(immutable_mutex_);
        immutable_memtables_.push_back(current_memtable_);
    }
    
    current_memtable_ = std::make_shared<MemTable>(config_.memtable_size);
    
    std::thread([this, snapshot = std::move(snapshot)]() mutable {
        writeSSTable(snapshot);
    }).detach();
    
    if (wal_) {
        wal_->truncate();
    }
}

void StorageEngine::writeSSTable(const std::map<std::string, std::vector<uint8_t>>& data) {
    uint64_t id = next_sstable_id_++;
    std::string filename = config_.data_dir + "/sstable_" + std::to_string(id) + ".sst";
    
    auto sstable = SSTable::create(filename, id, data);
    
    {
        std::unique_lock<std::shared_mutex> lock(sstable_mutex_);
        sstables_.push_back(sstable);
    }
    
    {
        std::unique_lock<std::shared_mutex> lock(immutable_mutex_);
        if (!immutable_memtables_.empty()) {
            immutable_memtables_.erase(immutable_memtables_.begin());
        }
    }
    
    if (sstables_.size() >= config_.compaction_threshold) {
        triggerCompaction();
    }
}

void StorageEngine::loadSSTables() {
    // TODO: Scan data_dir for existing SSTable files and load them
}

void StorageEngine::recoverFromWAL() {
    if (!wal_) return;
    
    auto entries = wal_->replay();
    for (const auto& entry : entries) {
        if (entry.op_type == WriteAheadLog::OpType::PUT) {
            Row row = Row::deserialize(entry.value.data(), entry.value.size());
            current_memtable_->put(entry.key, row);
        } else if (entry.op_type == WriteAheadLog::OpType::DELETE) {
            current_memtable_->remove(entry.key);
        }
    }
}

void StorageEngine::triggerCompaction() {
    std::lock_guard<std::mutex> lock(compaction_mutex_);
    if (!compaction_running_) {
        compaction_cv_.notify_one();
    }
}

void StorageEngine::compactionWorker() {
    while (!shutdown_) {
        std::unique_lock<std::mutex> lock(compaction_mutex_);
        compaction_cv_.wait(lock, [this] {
            return shutdown_ || sstables_.size() >= config_.compaction_threshold;
        });
        
        if (shutdown_) break;
        
        compaction_running_ = true;
        lock.unlock();
        
        performCompaction();
        
        compaction_running_ = false;
        total_compactions_++;
    }
}

void StorageEngine::performCompaction() {
    std::unique_lock<std::shared_mutex> lock(sstable_mutex_);
    
    if (sstables_.size() < 2) {
        return;
    }
    
    std::map<std::string, std::vector<uint8_t>> merged_data;
    
    for (size_t i = 0; i < std::min(sstables_.size(), size_t(4)); ++i) {
        sstables_[i]->forEach([&merged_data](const std::string& key, const Row& row) {
            merged_data[key] = row.serialize();
        });
    }
    
    uint64_t new_id = next_sstable_id_++;
    std::string filename = config_.data_dir + "/sstable_" + std::to_string(new_id) + ".sst";
    auto new_sstable = SSTable::create(filename, new_id, merged_data);
    
    sstables_.erase(sstables_.begin(), 
                   sstables_.begin() + std::min(sstables_.size(), size_t(4)));
    sstables_.push_back(new_sstable);
}

uint64_t StorageEngine::getTotalSSTableSize() const {
    std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
    uint64_t total = 0;
    for (const auto& sst : sstables_) {
        total += sst->size();
    }
    return total;
}

} // namespace kotana
