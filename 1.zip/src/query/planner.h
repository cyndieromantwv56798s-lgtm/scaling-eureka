#pragma once

#include "ast.h"
#include "optimizer.h"
#include "core/types.h"
#include <memory>
#include <vector>
#include <map>
#include <set>

namespace kotana {

enum class JoinType {
    INNER,
    LEFT,
    RIGHT,
    FULL,
    CROSS
};

enum class JoinAlgorithm {
    NESTED_LOOP,
    HASH_JOIN,
    MERGE_JOIN,
    INDEX_NESTED_LOOP
};

struct JoinCondition {
    std::string left_table;
    std::string left_column;
    std::string right_table;
    std::string right_column;
    std::string op;
    
    JoinCondition();
};

struct JoinPlan {
    JoinType type;
    JoinAlgorithm algorithm;
    std::string left_input;
    std::string right_input;
    std::vector<JoinCondition> conditions;
    double estimated_cost;
    size_t estimated_cardinality;
    
    JoinPlan();
};

struct ScanPlan {
    std::string table_name;
    AccessMethod access_method;
    std::vector<std::string> columns;
    std::vector<std::string> filter_columns;
    std::vector<Value> filter_values;
    std::string index_name;
    double selectivity;
    
    ScanPlan();
};

struct AggregationPlan {
    std::vector<std::string> group_by_columns;
    std::vector<std::string> aggregate_functions;
    std::vector<std::string> aggregate_columns;
    bool has_having_clause;
    std::string having_condition;
    
    AggregationPlan();
};

struct SortPlan {
    std::vector<std::string> sort_columns;
    std::vector<bool> ascending;
    size_t limit;
    bool use_index;
    std::string index_name;
    
    SortPlan();
};

struct ExecutionPlan {
    std::vector<std::shared_ptr<ScanPlan>> scans;
    std::vector<std::shared_ptr<JoinPlan>> joins;
    std::shared_ptr<AggregationPlan> aggregation;
    std::shared_ptr<SortPlan> sort;
    std::vector<std::string> output_columns;
    double total_estimated_cost;
    size_t estimated_result_size;
    
    ExecutionPlan();
    std::string toString() const;
};

class QueryPlanner {
public:
    QueryPlanner();
    ~QueryPlanner();
    
    ExecutionPlan createPlan(std::shared_ptr<SelectStatement> stmt);
    ExecutionPlan optimizePlan(const ExecutionPlan& plan);
    
    std::vector<ExecutionPlan> generateAlternativePlans(std::shared_ptr<SelectStatement> stmt);
    ExecutionPlan chooseBestPlan(const std::vector<ExecutionPlan>& plans);
    
    void setOptimizer(std::shared_ptr<QueryOptimizer> optimizer);
    std::shared_ptr<QueryOptimizer> getOptimizer();
    
    void enableJoinReordering(bool enable);
    void enableSubqueryFlattening(bool enable);
    void enablePredicatePushdown(bool enable);
    void enableIndexSuggestions(bool enable);
    
    std::vector<std::string> suggestIndexes(std::shared_ptr<SelectStatement> stmt);
    std::string explainPlan(const ExecutionPlan& plan);

private:
    std::shared_ptr<ScanPlan> createScanPlan(const std::string& table,
                                            const std::vector<std::string>& columns,
                                            const std::vector<std::string>& filters);
    std::shared_ptr<JoinPlan> createJoinPlan(const ScanPlan& left,
                                            const ScanPlan& right,
                                            const JoinCondition& condition);
    
    JoinAlgorithm chooseJoinAlgorithm(const ScanPlan& left,
                                     const ScanPlan& right,
                                     const JoinCondition& condition);
    
    std::vector<std::vector<std::string>> generateJoinOrders(
        const std::vector<std::string>& tables);
    
    ExecutionPlan applyPredicatePushdown(const ExecutionPlan& plan);
    ExecutionPlan applyJoinReordering(const ExecutionPlan& plan);
    ExecutionPlan applySubqueryFlattening(const ExecutionPlan& plan);
    
    double estimateScanCost(const ScanPlan& scan);
    double estimateJoinCost(const JoinPlan& join);
    double estimateAggregationCost(const AggregationPlan& agg, size_t input_size);
    double estimateSortCost(const SortPlan& sort, size_t input_size);
    
    std::shared_ptr<QueryOptimizer> optimizer_;
    bool enable_join_reordering_;
    bool enable_subquery_flattening_;
    bool enable_predicate_pushdown_;
    bool enable_index_suggestions_;
};

} // namespace kotana
