#pragma once

#include "ast.h"
#include "core/types.h"
#include <memory>
#include <vector>
#include <map>
#include <set>
#include <string>

namespace kotana {

enum class AccessMethod {
    FULL_SCAN,
    INDEX_SCAN,
    PRIMARY_KEY_LOOKUP
};

struct QueryPlan {
    AccessMethod access_method;
    std::vector<std::string> selected_columns;
    std::string table_name;
    std::string index_name;
    
    std::vector<std::string> filter_columns;
    std::vector<Value> filter_values;
    
    int limit;
    bool has_aggregation;
    std::vector<std::string> group_by_columns;
    
    double estimated_cost;
    size_t estimated_rows;
    
    QueryPlan();
};

struct TableStatistics {
    size_t row_count;
    size_t avg_row_size;
    std::map<std::string, size_t> column_cardinality;
    std::map<std::string, bool> has_index;
    
    TableStatistics();
};

class QueryOptimizer {
public:
    QueryOptimizer();
    
    QueryPlan optimize(std::shared_ptr<Statement> stmt);
    void updateStatistics(const std::string& table, const TableStatistics& stats);
    const TableStatistics* getStatistics(const std::string& table) const;
    
    std::vector<QueryPlan> generateAlternativePlans(std::shared_ptr<SelectStatement> stmt);
    QueryPlan chooseBestPlan(const std::vector<QueryPlan>& plans);

private:
    QueryPlan optimizeSelect(std::shared_ptr<SelectStatement> stmt);
    QueryPlan optimizeInsert(std::shared_ptr<InsertStatement> stmt);
    QueryPlan optimizeUpdate(std::shared_ptr<UpdateStatement> stmt);
    QueryPlan optimizeDelete(std::shared_ptr<DeleteStatement> stmt);
    
    double estimateCost(const QueryPlan& plan);
    size_t estimateRows(const QueryPlan& plan);
    
    std::map<std::string, TableStatistics> statistics_;
};

} // namespace kotana
