#include "planner.h"
#include <algorithm>
#include <sstream>
#include <cmath>

namespace kotana {

JoinCondition::JoinCondition() : op("=") {}

JoinPlan::JoinPlan()
    : type(JoinType::INNER),
      algorithm(JoinAlgorithm::HASH_JOIN),
      estimated_cost(0.0),
      estimated_cardinality(0) {}

ScanPlan::ScanPlan()
    : access_method(AccessMethod::FULL_SCAN),
      selectivity(1.0) {}

AggregationPlan::AggregationPlan()
    : has_having_clause(false) {}

SortPlan::SortPlan()
    : limit(0),
      use_index(false) {}

ExecutionPlan::ExecutionPlan()
    : total_estimated_cost(0.0),
      estimated_result_size(0) {}

std::string ExecutionPlan::toString() const {
    std::ostringstream oss;
    oss << "Execution Plan:\n";
    oss << "  Estimated cost: " << total_estimated_cost << "\n";
    oss << "  Estimated result size: " << estimated_result_size << "\n";
    
    if (!scans.empty()) {
        oss << "  Scans:\n";
        for (const auto& scan : scans) {
            oss << "    - Table: " << scan->table_name << "\n";
            oss << "      Method: ";
            switch (scan->access_method) {
                case AccessMethod::FULL_SCAN:
                    oss << "Full Scan\n";
                    break;
                case AccessMethod::INDEX_SCAN:
                    oss << "Index Scan (" << scan->index_name << ")\n";
                    break;
                case AccessMethod::PRIMARY_KEY_LOOKUP:
                    oss << "Primary Key Lookup\n";
                    break;
            }
        }
    }
    
    if (!joins.empty()) {
        oss << "  Joins:\n";
        for (const auto& join : joins) {
            oss << "    - Type: ";
            switch (join->type) {
                case JoinType::INNER:
                    oss << "Inner\n";
                    break;
                case JoinType::LEFT:
                    oss << "Left\n";
                    break;
                case JoinType::RIGHT:
                    oss << "Right\n";
                    break;
                case JoinType::FULL:
                    oss << "Full\n";
                    break;
                case JoinType::CROSS:
                    oss << "Cross\n";
                    break;
            }
            oss << "      Algorithm: ";
            switch (join->algorithm) {
                case JoinAlgorithm::NESTED_LOOP:
                    oss << "Nested Loop\n";
                    break;
                case JoinAlgorithm::HASH_JOIN:
                    oss << "Hash Join\n";
                    break;
                case JoinAlgorithm::MERGE_JOIN:
                    oss << "Merge Join\n";
                    break;
                case JoinAlgorithm::INDEX_NESTED_LOOP:
                    oss << "Index Nested Loop\n";
                    break;
            }
        }
    }
    
    return oss.str();
}

QueryPlanner::QueryPlanner()
    : optimizer_(std::make_shared<QueryOptimizer>()),
      enable_join_reordering_(true),
      enable_subquery_flattening_(true),
      enable_predicate_pushdown_(true),
      enable_index_suggestions_(true) {}

QueryPlanner::~QueryPlanner() = default;

ExecutionPlan QueryPlanner::createPlan(std::shared_ptr<SelectStatement> stmt) {
    ExecutionPlan plan;
    
    auto scan = createScanPlan(stmt->table_name, stmt->columns, {});
    plan.scans.push_back(scan);
    
    if (stmt->select_all) {
        plan.output_columns = {"*"};
    } else {
        plan.output_columns = stmt->columns;
    }
    
    if (stmt->limit > 0) {
        plan.sort = std::make_shared<SortPlan>();
        plan.sort->limit = stmt->limit;
    }
    
    plan.total_estimated_cost = estimateScanCost(*scan);
    plan.estimated_result_size = 100;
    
    return plan;
}

ExecutionPlan QueryPlanner::optimizePlan(const ExecutionPlan& plan) {
    ExecutionPlan optimized = plan;
    
    if (enable_predicate_pushdown_) {
        optimized = applyPredicatePushdown(optimized);
    }
    
    if (enable_join_reordering_) {
        optimized = applyJoinReordering(optimized);
    }
    
    if (enable_subquery_flattening_) {
        optimized = applySubqueryFlattening(optimized);
    }
    
    return optimized;
}

std::vector<ExecutionPlan> QueryPlanner::generateAlternativePlans(
    std::shared_ptr<SelectStatement> stmt) {
    std::vector<ExecutionPlan> plans;
    
    auto base_plan = createPlan(stmt);
    plans.push_back(base_plan);
    
    ExecutionPlan index_plan = base_plan;
    if (!index_plan.scans.empty()) {
        index_plan.scans[0]->access_method = AccessMethod::INDEX_SCAN;
        index_plan.scans[0]->index_name = stmt->table_name + "_idx";
        index_plan.total_estimated_cost = estimateScanCost(*index_plan.scans[0]);
    }
    plans.push_back(index_plan);
    
    return plans;
}

ExecutionPlan QueryPlanner::chooseBestPlan(const std::vector<ExecutionPlan>& plans) {
    if (plans.empty()) {
        return ExecutionPlan();
    }
    
    auto best = std::min_element(plans.begin(), plans.end(),
        [](const ExecutionPlan& a, const ExecutionPlan& b) {
            return a.total_estimated_cost < b.total_estimated_cost;
        });
    
    return *best;
}

void QueryPlanner::setOptimizer(std::shared_ptr<QueryOptimizer> optimizer) {
    optimizer_ = optimizer;
}

std::shared_ptr<QueryOptimizer> QueryPlanner::getOptimizer() {
    return optimizer_;
}

void QueryPlanner::enableJoinReordering(bool enable) {
    enable_join_reordering_ = enable;
}

void QueryPlanner::enableSubqueryFlattening(bool enable) {
    enable_subquery_flattening_ = enable;
}

void QueryPlanner::enablePredicatePushdown(bool enable) {
    enable_predicate_pushdown_ = enable;
}

void QueryPlanner::enableIndexSuggestions(bool enable) {
    enable_index_suggestions_ = enable;
}

std::vector<std::string> QueryPlanner::suggestIndexes(std::shared_ptr<SelectStatement> stmt) {
    std::vector<std::string> suggestions;
    
    if (!stmt->where_column.empty()) {
        suggestions.push_back("CREATE INDEX idx_" + stmt->table_name + "_" +
                            stmt->where_column + " ON " + stmt->table_name +
                            " (" + stmt->where_column + ")");
    }
    
    for (const auto& col : stmt->columns) {
        if (col != "*") {
            suggestions.push_back("CREATE INDEX idx_" + stmt->table_name + "_" +
                                col + " ON " + stmt->table_name + " (" + col + ")");
        }
    }
    
    return suggestions;
}

std::string QueryPlanner::explainPlan(const ExecutionPlan& plan) {
    return plan.toString();
}

std::shared_ptr<ScanPlan> QueryPlanner::createScanPlan(
    const std::string& table,
    const std::vector<std::string>& columns,
    const std::vector<std::string>& filters) {
    
    auto scan = std::make_shared<ScanPlan>();
    scan->table_name = table;
    scan->columns = columns;
    scan->filter_columns = filters;
    
    if (filters.empty()) {
        scan->access_method = AccessMethod::FULL_SCAN;
    } else {
        scan->access_method = AccessMethod::INDEX_SCAN;
        scan->index_name = table + "_idx";
    }
    
    scan->selectivity = filters.empty() ? 1.0 : 0.1;
    
    return scan;
}

std::shared_ptr<JoinPlan> QueryPlanner::createJoinPlan(
    const ScanPlan& left,
    const ScanPlan& right,
    const JoinCondition& condition) {
    
    auto join = std::make_shared<JoinPlan>();
    join->left_input = left.table_name;
    join->right_input = right.table_name;
    join->conditions.push_back(condition);
    join->algorithm = chooseJoinAlgorithm(left, right, condition);
    join->type = JoinType::INNER;
    
    join->estimated_cost = estimateJoinCost(*join);
    join->estimated_cardinality = 1000;
    
    return join;
}

JoinAlgorithm QueryPlanner::chooseJoinAlgorithm(
    const ScanPlan& left,
    const ScanPlan& right,
    const JoinCondition& condition) {
    
    if (left.access_method == AccessMethod::INDEX_SCAN ||
        right.access_method == AccessMethod::INDEX_SCAN) {
        return JoinAlgorithm::INDEX_NESTED_LOOP;
    }
    
    return JoinAlgorithm::HASH_JOIN;
}

std::vector<std::vector<std::string>> QueryPlanner::generateJoinOrders(
    const std::vector<std::string>& tables) {
    
    std::vector<std::vector<std::string>> orders;
    
    if (tables.size() <= 1) {
        orders.push_back(tables);
        return orders;
    }
    
    orders.push_back(tables);
    
    auto reversed = tables;
    std::reverse(reversed.begin(), reversed.end());
    orders.push_back(reversed);
    
    return orders;
}

ExecutionPlan QueryPlanner::applyPredicatePushdown(const ExecutionPlan& plan) {
    return plan;
}

ExecutionPlan QueryPlanner::applyJoinReordering(const ExecutionPlan& plan) {
    return plan;
}

ExecutionPlan QueryPlanner::applySubqueryFlattening(const ExecutionPlan& plan) {
    return plan;
}

double QueryPlanner::estimateScanCost(const ScanPlan& scan) {
    double base_cost = 100.0;
    
    switch (scan.access_method) {
        case AccessMethod::PRIMARY_KEY_LOOKUP:
            return 1.0;
        case AccessMethod::INDEX_SCAN:
            return base_cost * 0.1 * scan.selectivity;
        case AccessMethod::FULL_SCAN:
            return base_cost * scan.selectivity;
    }
    
    return base_cost;
}

double QueryPlanner::estimateJoinCost(const JoinPlan& join) {
    double base_cost = 1000.0;
    
    switch (join.algorithm) {
        case JoinAlgorithm::NESTED_LOOP:
            return base_cost * 10;
        case JoinAlgorithm::HASH_JOIN:
            return base_cost;
        case JoinAlgorithm::MERGE_JOIN:
            return base_cost * 1.5;
        case JoinAlgorithm::INDEX_NESTED_LOOP:
            return base_cost * 0.5;
    }
    
    return base_cost;
}

double QueryPlanner::estimateAggregationCost(const AggregationPlan& agg, size_t input_size) {
    double base_cost = input_size * 0.1;
    
    if (!agg.group_by_columns.empty()) {
        base_cost *= std::log2(input_size + 1);
    }
    
    return base_cost;
}

double QueryPlanner::estimateSortCost(const SortPlan& sort, size_t input_size) {
    if (sort.use_index) {
        return input_size * 0.01;
    }
    
    return input_size * std::log2(input_size + 1);
}

} // namespace kotana
