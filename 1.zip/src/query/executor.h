#pragma once

#include "ast.h"
#include "core/types.h"
#include "storage/storage_engine.h"
#include <memory>
#include <map>
#include <string>
#include <mutex>

namespace kotana {

class QueryExecutor {
public:
    explicit QueryExecutor(std::shared_ptr<StorageEngine> storage);
    
    QueryResult execute(const std::string& query);
    QueryResult executeStatement(std::shared_ptr<Statement> stmt);

private:
    QueryResult executeCreate(std::shared_ptr<CreateTableStatement> stmt);
    QueryResult executeInsert(std::shared_ptr<InsertStatement> stmt);
    QueryResult executeSelect(std::shared_ptr<SelectStatement> stmt);
    QueryResult executeUpdate(std::shared_ptr<UpdateStatement> stmt);
    QueryResult executeDelete(std::shared_ptr<DeleteStatement> stmt);
    QueryResult executeUse(std::shared_ptr<UseStatement> stmt);
    
    Value parseValue(const std::string& str, DataType type);
    
    std::shared_ptr<StorageEngine> storage_;
    std::map<std::string, TableSchema> schemas_;
    std::string current_keyspace_;
    std::mutex schema_mutex_;
};

} // namespace kotana
