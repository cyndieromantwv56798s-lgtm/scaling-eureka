#pragma once

#include "core/types.h"
#include <string>
#include <vector>
#include <map>
#include <memory>

namespace kotana {

enum class StatementType {
    CREATE_TABLE,
    INSERT,
    SELECT,
    UPDATE,
    DELETE,
    USE
};

struct Statement {
    virtual ~Statement() = default;
    virtual StatementType type() const = 0;
};

struct CreateTableStatement : public Statement {
    std::string table_name;
    std::vector<ColumnDef> columns;
    
    StatementType type() const override { return StatementType::CREATE_TABLE; }
};

struct InsertStatement : public Statement {
    std::string table_name;
    std::vector<std::string> columns;
    std::vector<std::string> values;
    
    StatementType type() const override { return StatementType::INSERT; }
};

struct SelectStatement : public Statement {
    std::string table_name;
    std::vector<std::string> columns;
    bool select_all = false;
    std::string where_column;
    std::string where_value;
    int limit = -1;
    
    StatementType type() const override { return StatementType::SELECT; }
};

struct UpdateStatement : public Statement {
    std::string table_name;
    std::map<std::string, std::string> updates;
    std::string where_column;
    std::string where_value;
    
    StatementType type() const override { return StatementType::UPDATE; }
};

struct DeleteStatement : public Statement {
    std::string table_name;
    std::string where_column;
    std::string where_value;
    
    StatementType type() const override { return StatementType::DELETE; }
};

struct UseStatement : public Statement {
    std::string keyspace_name;
    
    StatementType type() const override { return StatementType::USE; }
};

} // namespace kotana
