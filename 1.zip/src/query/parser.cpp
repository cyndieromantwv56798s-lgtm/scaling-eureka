#include "parser.h"
#include <algorithm>
#include <cctype>
#include <stdexcept>

namespace kotana {

std::shared_ptr<Statement> QueryParser::parse(const std::string& query) {
    QueryParser parser(query);
    return parser.parseStatement();
}

QueryParser::QueryParser(const std::string& query) 
    : query_(query), pos_(0), token_pos_(0) {
    tokenize();
}

void QueryParser::tokenize() {
    size_t i = 0;
    while (i < query_.size()) {
        if (std::isspace(query_[i])) {
            ++i;
            continue;
        }
        
        if (query_[i] == '(' || query_[i] == ')' || 
            query_[i] == ',' || query_[i] == ';' ||
            query_[i] == '=' || query_[i] == '*') {
            tokens_.push_back(std::string(1, query_[i]));
            ++i;
            continue;
        }
        
        if (query_[i] == '\'' || query_[i] == '"') {
            char quote = query_[i];
            size_t start = ++i;
            while (i < query_.size() && query_[i] != quote) {
                ++i;
            }
            tokens_.push_back(query_.substr(start, i - start));
            ++i;
            continue;
        }
        
        size_t start = i;
        while (i < query_.size() && 
               !std::isspace(query_[i]) && 
               query_[i] != '(' && query_[i] != ')' && 
               query_[i] != ',' && query_[i] != ';' &&
               query_[i] != '=' && query_[i] != '\'' && 
               query_[i] != '"') {
            ++i;
        }
        tokens_.push_back(query_.substr(start, i - start));
    }
}

std::string QueryParser::currentToken() const {
    if (token_pos_ >= tokens_.size()) {
        return "";
    }
    return tokens_[token_pos_];
}

std::string QueryParser::nextToken() {
    if (token_pos_ >= tokens_.size()) {
        return "";
    }
    return tokens_[token_pos_++];
}

bool QueryParser::matchToken(const std::string& expected) {
    std::string token = currentToken();
    std::transform(token.begin(), token.end(), token.begin(), ::toupper);
    return token == expected;
}

void QueryParser::expectToken(const std::string& expected) {
    std::string token = nextToken();
    std::transform(token.begin(), token.end(), token.begin(), ::toupper);
    if (token != expected) {
        throw std::runtime_error("Expected '" + expected + "', got '" + token + "'");
    }
}

std::shared_ptr<Statement> QueryParser::parseStatement() {
    std::string first = currentToken();
    std::transform(first.begin(), first.end(), first.begin(), ::toupper);
    
    if (first == "CREATE") {
        return parseCreate();
    } else if (first == "INSERT") {
        return parseInsert();
    } else if (first == "SELECT") {
        return parseSelect();
    } else if (first == "UPDATE") {
        return parseUpdate();
    } else if (first == "DELETE") {
        return parseDelete();
    } else if (first == "USE") {
        return parseUse();
    } else {
        throw std::runtime_error("Unknown statement type: " + first);
    }
}

std::shared_ptr<Statement> QueryParser::parseCreate() {
    auto stmt = std::make_shared<CreateTableStatement>();
    
    expectToken("CREATE");
    expectToken("TABLE");
    
    stmt->table_name = nextToken();
    
    expectToken("(");
    
    while (currentToken() != ")") {
        std::string col_name = nextToken();
        std::string type_str = nextToken();
        
        std::transform(type_str.begin(), type_str.end(), type_str.begin(), ::toupper);
        
        DataType type = DataType::STRING;
        if (type_str == "INT" || type_str == "INT32") {
            type = DataType::INT32;
        } else if (type_str == "BIGINT" || type_str == "INT64") {
            type = DataType::INT64;
        } else if (type_str == "FLOAT") {
            type = DataType::FLOAT;
        } else if (type_str == "DOUBLE") {
            type = DataType::DOUBLE;
        } else if (type_str == "TEXT" || type_str == "VARCHAR" || type_str == "STRING") {
            type = DataType::STRING;
        } else if (type_str == "BOOLEAN" || type_str == "BOOL") {
            type = DataType::BOOLEAN;
        }
        
        bool is_primary = false;
        if (matchToken("PRIMARY")) {
            nextToken();
            expectToken("KEY");
            is_primary = true;
        }
        
        stmt->columns.emplace_back(col_name, type, is_primary, false);
        
        if (currentToken() == ",") {
            nextToken();
        }
    }
    
    expectToken(")");
    
    return stmt;
}

std::shared_ptr<Statement> QueryParser::parseInsert() {
    auto stmt = std::make_shared<InsertStatement>();
    
    expectToken("INSERT");
    expectToken("INTO");
    
    stmt->table_name = nextToken();
    
    expectToken("(");
    
    while (currentToken() != ")") {
        stmt->columns.push_back(nextToken());
        if (currentToken() == ",") {
            nextToken();
        }
    }
    
    expectToken(")");
    expectToken("VALUES");
    expectToken("(");
    
    while (currentToken() != ")") {
        stmt->values.push_back(nextToken());
        if (currentToken() == ",") {
            nextToken();
        }
    }
    
    expectToken(")");
    
    return stmt;
}

std::shared_ptr<Statement> QueryParser::parseSelect() {
    auto stmt = std::make_shared<SelectStatement>();
    
    expectToken("SELECT");
    
    while (currentToken() != "FROM" && currentToken() != "") {
        if (currentToken() == "*") {
            stmt->select_all = true;
            nextToken();
            break;
        }
        
        stmt->columns.push_back(nextToken());
        if (currentToken() == ",") {
            nextToken();
        }
    }
    
    expectToken("FROM");
    stmt->table_name = nextToken();
    
    if (matchToken("WHERE")) {
        nextToken();
        stmt->where_column = nextToken();
        expectToken("=");
        stmt->where_value = nextToken();
    }
    
    if (matchToken("LIMIT")) {
        nextToken();
        stmt->limit = std::stoi(nextToken());
    }
    
    return stmt;
}

std::shared_ptr<Statement> QueryParser::parseUpdate() {
    auto stmt = std::make_shared<UpdateStatement>();
    
    expectToken("UPDATE");
    stmt->table_name = nextToken();
    expectToken("SET");
    
    while (!matchToken("WHERE") && currentToken() != "") {
        std::string col = nextToken();
        expectToken("=");
        std::string val = nextToken();
        
        stmt->updates[col] = val;
        
        if (currentToken() == ",") {
            nextToken();
        }
    }
    
    if (matchToken("WHERE")) {
        nextToken();
        stmt->where_column = nextToken();
        expectToken("=");
        stmt->where_value = nextToken();
    }
    
    return stmt;
}

std::shared_ptr<Statement> QueryParser::parseDelete() {
    auto stmt = std::make_shared<DeleteStatement>();
    
    expectToken("DELETE");
    expectToken("FROM");
    stmt->table_name = nextToken();
    
    if (matchToken("WHERE")) {
        nextToken();
        stmt->where_column = nextToken();
        expectToken("=");
        stmt->where_value = nextToken();
    }
    
    return stmt;
}

std::shared_ptr<Statement> QueryParser::parseUse() {
    auto stmt = std::make_shared<UseStatement>();
    expectToken("USE");
    stmt->keyspace_name = nextToken();
    return stmt;
}

} // namespace kotana
