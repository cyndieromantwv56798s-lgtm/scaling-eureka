#pragma once

#include "ast.h"
#include <string>
#include <vector>
#include <memory>

namespace kotana {

class QueryParser {
public:
    static std::shared_ptr<Statement> parse(const std::string& query);

private:
    explicit QueryParser(const std::string& query);
    
    void tokenize();
    std::string currentToken() const;
    std::string nextToken();
    bool matchToken(const std::string& expected);
    void expectToken(const std::string& expected);
    
    std::shared_ptr<Statement> parseStatement();
    std::shared_ptr<Statement> parseCreate();
    std::shared_ptr<Statement> parseInsert();
    std::shared_ptr<Statement> parseSelect();
    std::shared_ptr<Statement> parseUpdate();
    std::shared_ptr<Statement> parseDelete();
    std::shared_ptr<Statement> parseUse();
    
    std::string query_;
    size_t pos_;
    std::vector<std::string> tokens_;
    size_t token_pos_;
};

} // namespace kotana
