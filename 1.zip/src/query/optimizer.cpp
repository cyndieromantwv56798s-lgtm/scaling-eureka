#include "optimizer.h"
#include <algorithm>
#include <cmath>

namespace kotana {

QueryPlan::QueryPlan()
    : access_method(AccessMethod::FULL_SCAN),
      limit(-1),
      has_aggregation(false),
      estimated_cost(0.0),
      estimated_rows(0) {}

TableStatistics::TableStatistics()
    : row_count(0), avg_row_size(0) {}

QueryOptimizer::QueryOptimizer() = default;

QueryPlan QueryOptimizer::optimize(std::shared_ptr<Statement> stmt) {
    switch (stmt->type()) {
        case StatementType::SELECT:
            return optimizeSelect(std::static_pointer_cast<SelectStatement>(stmt));
        case StatementType::INSERT:
            return optimizeInsert(std::static_pointer_cast<InsertStatement>(stmt));
        case StatementType::UPDATE:
            return optimizeUpdate(std::static_pointer_cast<UpdateStatement>(stmt));
        case StatementType::DELETE:
            return optimizeDelete(std::static_pointer_cast<DeleteStatement>(stmt));
        default:
            return QueryPlan();
    }
}

void QueryOptimizer::updateStatistics(const std::string& table, const TableStatistics& stats) {
    statistics_[table] = stats;
}

const TableStatistics* QueryOptimizer::getStatistics(const std::string& table) const {
    auto it = statistics_.find(table);
    return it != statistics_.end() ? &it->second : nullptr;
}

QueryPlan QueryOptimizer::optimizeSelect(std::shared_ptr<SelectStatement> stmt) {
    QueryPlan plan;
    plan.table_name = stmt->table_name;
    plan.limit = stmt->limit;
    
    if (stmt->select_all) {
        plan.access_method = AccessMethod::FULL_SCAN;
    } else {
        plan.selected_columns = stmt->columns;
    }
    
    if (!stmt->where_column.empty() && !stmt->where_value.empty()) {
        plan.filter_columns.push_back(stmt->where_column);
        plan.filter_values.push_back(Value(stmt->where_value));
        
        auto stats = getStatistics(stmt->table_name);
        if (stats && stats->has_index.count(stmt->where_column) > 0 &&
            stats->has_index.at(stmt->where_column)) {
            plan.access_method = AccessMethod::INDEX_SCAN;
            plan.index_name = stmt->where_column + "_idx";
        } else {
            plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
        }
    }
    
    plan.estimated_cost = estimateCost(plan);
    plan.estimated_rows = estimateRows(plan);
    
    return plan;
}

QueryPlan QueryOptimizer::optimizeInsert(std::shared_ptr<InsertStatement> stmt) {
    QueryPlan plan;
    plan.table_name = stmt->table_name;
    plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
    plan.estimated_cost = 1.0;
    plan.estimated_rows = 1;
    return plan;
}

QueryPlan QueryOptimizer::optimizeUpdate(std::shared_ptr<UpdateStatement> stmt) {
    QueryPlan plan;
    plan.table_name = stmt->table_name;
    plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
    plan.estimated_cost = 2.0;
    plan.estimated_rows = 1;
    return plan;
}

QueryPlan QueryOptimizer::optimizeDelete(std::shared_ptr<DeleteStatement> stmt) {
    QueryPlan plan;
    plan.table_name = stmt->table_name;
    plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
    plan.estimated_cost = 1.5;
    plan.estimated_rows = 1;
    return plan;
}

double QueryOptimizer::estimateCost(const QueryPlan& plan) {
    auto stats = getStatistics(plan.table_name);
    if (!stats) {
        return 100.0;
    }
    
    double cost = 0.0;
    
    switch (plan.access_method) {
        case AccessMethod::PRIMARY_KEY_LOOKUP:
            cost = 1.0;
            break;
        case AccessMethod::INDEX_SCAN:
            cost = std::log2(stats->row_count + 1) + plan.filter_columns.size();
            break;
        case AccessMethod::FULL_SCAN:
            cost = stats->row_count * 0.1;
            break;
    }
    
    if (plan.has_aggregation) {
        cost += stats->row_count * 0.05;
    }
    
    if (!plan.group_by_columns.empty()) {
        cost += stats->row_count * std::log2(stats->row_count + 1) * 0.01;
    }
    
    return cost;
}

size_t QueryOptimizer::estimateRows(const QueryPlan& plan) {
    auto stats = getStatistics(plan.table_name);
    if (!stats) {
        return 1000;
    }
    
    size_t rows = stats->row_count;
    
    for (const auto& col : plan.filter_columns) {
        auto it = stats->column_cardinality.find(col);
        if (it != stats->column_cardinality.end() && it->second > 0) {
            rows = rows / it->second;
        } else {
            rows = rows / 10;
        }
    }
    
    if (plan.limit > 0) {
        rows = std::min(rows, static_cast<size_t>(plan.limit));
    }
    
    return std::max(rows, size_t(1));
}

std::vector<QueryPlan> QueryOptimizer::generateAlternativePlans(std::shared_ptr<SelectStatement> stmt) {
    std::vector<QueryPlan> plans;
    
    QueryPlan full_scan = optimizeSelect(stmt);
    full_scan.access_method = AccessMethod::FULL_SCAN;
    full_scan.estimated_cost = estimateCost(full_scan);
    plans.push_back(full_scan);
    
    if (!stmt->where_column.empty()) {
        QueryPlan index_scan = optimizeSelect(stmt);
        index_scan.access_method = AccessMethod::INDEX_SCAN;
        index_scan.estimated_cost = estimateCost(index_scan);
        plans.push_back(index_scan);
    }
    
    return plans;
}

QueryPlan QueryOptimizer::chooseBestPlan(const std::vector<QueryPlan>& plans) {
    if (plans.empty()) {
        return QueryPlan();
    }
    
    auto best = std::min_element(plans.begin(), plans.end(),
        [](const QueryPlan& a, const QueryPlan& b) {
            return a.estimated_cost < b.estimated_cost;
        });
    
    return *best;
}

} // namespace kotana
