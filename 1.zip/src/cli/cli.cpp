#include "network/protocol.h"
#include <iostream>
#include <string>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>

using namespace kotana;

class KotanaClient {
public:
    KotanaClient(const std::string& host, uint16_t port)
        : host_(host), port_(port), connected_(false), sock_(-1) {}
    
    ~KotanaClient() {
        disconnect();
    }
    
    bool connect() {
        sock_ = socket(AF_INET, SOCK_STREAM, 0);
        if (sock_ < 0) {
            std::cerr << "Failed to create socket\n";
            return false;
        }
        
        struct sockaddr_in server_addr;
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(port_);
        
        if (inet_pton(AF_INET, host_.c_str(), &server_addr.sin_addr) <= 0) {
            std::cerr << "Invalid address\n";
            close(sock_);
            return false;
        }
        
        if (::connect(sock_, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
            std::cerr << "Connection failed\n";
            close(sock_);
            return false;
        }
        
        connected_ = true;
        return true;
    }
    
    void disconnect() {
        if (sock_ >= 0) {
            close(sock_);
            sock_ = -1;
        }
        connected_ = false;
    }
    
    std::string executeQuery(const std::string& query) {
        if (!connected_) {
            return "Not connected to server";
        }
        
        Message request = Message::createQuery(query);
        auto request_data = request.serialize();
        
        if (send(sock_, request_data.data(), request_data.size(), 0) < 0) {
            return "Failed to send query";
        }
        
        std::vector<uint8_t> buffer(8192);
        ssize_t bytes_received = recv(sock_, buffer.data(), buffer.size(), 0);
        
        if (bytes_received <= 0) {
            return "Failed to receive response";
        }
        
        try {
            Message response = Message::deserialize(buffer.data(), bytes_received);
            
            if (response.type == MessageType::ERROR) {
                return "Error: " + response.payloadAsString();
            }
            
            return response.payloadAsString();
            
        } catch (const std::exception& e) {
            return std::string("Error parsing response: ") + e.what();
        }
    }
    
    bool isConnected() const { return connected_; }

private:
    std::string host_;
    uint16_t port_;
    bool connected_;
    int sock_;
};

void printBanner() {
    std::cout << "\n";
    std::cout << "  _  __     _                  _       _ _     _  __     _                  \n";
    std::cout << " | |/ /    | |                | |     (_) |   | |/ /    | |                 \n";
    std::cout << " | ' / ___ | |_ ___  ___ _ __ | | ___  _| |_  | ' / ___ | |_ __ _ _ __   __ _ \n";
    std::cout << " |  < / _ \\| __/ _ \\/ __| '_ \\| |/ _ \\| | __| |  < / _ \\| __/ _` | '_ \\ / _` |\n";
    std::cout << " | . \\ (_) | || (_) \\__ \\ |_) | | (_) | | |_  | . \\ (_) | || (_| | | | | (_| |\n";
    std::cout << " |_|\\_\\___/ \\__\\___/|___/ .__/|_|\\___/|_|\\__| |_|\\_\\___/ \\__\\__,_|_| |_|\\__,_|\n";
    std::cout << "                        | |                                                   \n";
    std::cout << "                        |_|                                                   \n";
    std::cout << "\n";
    std::cout << "  High-Performance Distributed Database System\n";
    std::cout << "  Version 1.0.0\n\n";
}

void printHelp() {
    std::cout << "\nAvailable commands:\n";
    std::cout << "  CREATE TABLE <name> (col1 type1, col2 type2, ...)\n";
    std::cout << "  INSERT INTO <table> (col1, col2, ...) VALUES (val1, val2, ...)\n";
    std::cout << "  SELECT * FROM <table> WHERE <col> = <value>\n";
    std::cout << "  UPDATE <table> SET col1 = val1 WHERE <col> = <value>\n";
    std::cout << "  DELETE FROM <table> WHERE <col> = <value>\n";
    std::cout << "  \\help    - Show this help message\n";
    std::cout << "  \\quit    - Exit the CLI\n";
    std::cout << std::endl;
}

int main(int argc, char* argv[]) {
    std::string host = "127.0.0.1";
    uint16_t port = 9042;
    
    if (argc > 1) {
        host = argv[1];
    }
    if (argc > 2) {
        port = std::atoi(argv[2]);
    }
    
    printBanner();
    
    KotanaClient client(host, port);
    
    std::cout << "Connecting to " << host << ":" << port << "...\n";
    
    if (!client.connect()) {
        std::cerr << "Failed to connect to server\n";
        return 1;
    }
    
    std::cout << "Connected successfully!\n";
    std::cout << "Type \\help for available commands, \\quit to exit\n\n";
    
    std::string line;
    std::string query;
    
    while (true) {
        if (query.empty()) {
            std::cout << "kotana> ";
        } else {
            std::cout << "     -> ";
        }
        
        if (!std::getline(std::cin, line)) {
            break;
        }
        
        if (line == "\\quit" || line == "\\exit") {
            break;
        }
        
        if (line == "\\help") {
            printHelp();
            continue;
        }
        
        if (line.empty()) {
            continue;
        }
        
        query += line + " ";
        
        if (line.back() == ';') {
            query.pop_back();
            
            std::string result = client.executeQuery(query);
            std::cout << result << "\n\n";
            
            query.clear();
        }
    }
    
    std::cout << "\nGoodbye!\n";
    
    return 0;
}
