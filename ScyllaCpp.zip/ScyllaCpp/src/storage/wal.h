#pragma once

#include "core/types.h"
#include <string>
#include <fstream>
#include <vector>
#include <mutex>
#include <cstdint>

namespace kotana {

class WriteAheadLog {
public:
    enum class OpType : uint8_t {
        PUT = 1,
        DELETE = 2,
        BATCH_START = 3,
        BATCH_END = 4
    };
    
    struct LogEntry {
        OpType op_type;
        std::string key;
        std::vector<uint8_t> value;
        uint64_t timestamp;
        
        LogEntry() : op_type(OpType::PUT), timestamp(0) {}
        LogEntry(OpType op, const std::string& k, const std::vector<uint8_t>& v, uint64_t ts)
            : op_type(op), key(k), value(v), timestamp(ts) {}
    };
    
    explicit WriteAheadLog(const std::string& filename)
        : filename_(filename), entry_count_(0), file_size_(0) {
        
        file_.open(filename_, std::ios::binary | std::ios::app);
        if (!file_) {
            throw std::runtime_error("Failed to open WAL file: " + filename_);
        }
        
        file_.seekp(0, std::ios::end);
        file_size_ = file_.tellp();
    }
    
    ~WriteAheadLog() {
        if (file_.is_open()) {
            sync();
            file_.close();
        }
    }
    
    void append(OpType op_type, const std::string& key, const std::vector<uint8_t>& value) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        uint64_t timestamp = getCurrentTimestamp();
        
        file_.write(reinterpret_cast<const char*>(&op_type), sizeof(op_type));
        file_.write(reinterpret_cast<const char*>(&timestamp), sizeof(timestamp));
        
        uint32_t key_size = key.size();
        file_.write(reinterpret_cast<const char*>(&key_size), sizeof(key_size));
        file_.write(key.data(), key_size);
        
        uint32_t value_size = value.size();
        file_.write(reinterpret_cast<const char*>(&value_size), sizeof(value_size));
        file_.write(reinterpret_cast<const char*>(value.data()), value_size);
        
        ++entry_count_;
        file_size_ += sizeof(op_type) + sizeof(timestamp) + 
                      sizeof(key_size) + key_size + 
                      sizeof(value_size) + value_size;
    }
    
    void appendPut(const std::string& key, const Row& row) {
        auto serialized = row.serialize();
        append(OpType::PUT, key, serialized);
    }
    
    void appendDelete(const std::string& key) {
        append(OpType::DELETE, key, {});
    }
    
    void sync() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (file_.is_open()) {
            file_.flush();
            
            #ifdef __linux__
            int fd = fileno(fopen(filename_.c_str(), "r"));
            if (fd >= 0) {
                fsync(fd);
                close(fd);
            }
            #endif
        }
    }
    
    std::vector<LogEntry> replay() {
        std::vector<LogEntry> entries;
        
        std::ifstream read_file(filename_, std::ios::binary);
        if (!read_file) {
            return entries;
        }
        
        while (read_file) {
            OpType op_type;
            read_file.read(reinterpret_cast<char*>(&op_type), sizeof(op_type));
            if (read_file.eof()) break;
            
            uint64_t timestamp;
            read_file.read(reinterpret_cast<char*>(&timestamp), sizeof(timestamp));
            
            uint32_t key_size;
            read_file.read(reinterpret_cast<char*>(&key_size), sizeof(key_size));
            
            std::string key(key_size, '\0');
            read_file.read(&key[0], key_size);
            
            uint32_t value_size;
            read_file.read(reinterpret_cast<char*>(&value_size), sizeof(value_size));
            
            std::vector<uint8_t> value(value_size);
            read_file.read(reinterpret_cast<char*>(value.data()), value_size);
            
            entries.emplace_back(op_type, key, value, timestamp);
        }
        
        return entries;
    }
    
    void truncate() {
        std::lock_guard<std::mutex> lock(mutex_);
        
        if (file_.is_open()) {
            file_.close();
        }
        
        file_.open(filename_, std::ios::binary | std::ios::trunc);
        entry_count_ = 0;
        file_size_ = 0;
    }
    
    size_t size() const { return file_size_; }
    size_t entryCount() const { return entry_count_; }

private:
    uint64_t getCurrentTimestamp() const {
        auto now = std::chrono::system_clock::now();
        auto duration = now.time_since_epoch();
        return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    }
    
    std::string filename_;
    std::fstream file_;
    size_t entry_count_;
    size_t file_size_;
    std::mutex mutex_;
};

} // namespace kotana
