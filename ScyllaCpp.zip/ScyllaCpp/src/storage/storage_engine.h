#pragma once

#include "memtable.h"
#include "sstable.h"
#include "wal.h"
#include "core/types.h"
#include <vector>
#include <memory>
#include <string>
#include <mutex>
#include <thread>
#include <atomic>
#include <condition_variable>
#include <sys/stat.h>

namespace kotana {

class StorageEngine {
public:
    struct Config {
        std::string data_dir;
        size_t memtable_size;
        size_t num_memtables;
        size_t compaction_threshold;
        bool enable_wal;
        
        Config() : data_dir("./data"), memtable_size(64 * 1024 * 1024), 
                  num_memtables(3), compaction_threshold(4), enable_wal(true) {}
    };
    
    StorageEngine() : StorageEngine(Config()) {}
    
    explicit StorageEngine(const Config& config)
        : config_(config),
          next_sstable_id_(0),
          compaction_running_(false),
          shutdown_(false) {
        
        createDataDirectory();
        
        current_memtable_ = std::make_shared<MemTable>(config_.memtable_size);
        
        if (config_.enable_wal) {
            wal_ = std::make_unique<WriteAheadLog>(config_.data_dir + "/wal.log");
            recoverFromWAL();
        }
        
        loadSSTables();
        
        compaction_thread_ = std::thread(&StorageEngine::compactionWorker, this);
    }
    
    ~StorageEngine() {
        shutdown();
    }
    
    bool put(const std::string& key, const Row& row) {
        std::lock_guard<std::mutex> lock(write_mutex_);
        
        if (wal_) {
            wal_->appendPut(key, row);
        }
        
        if (current_memtable_->isFull()) {
            flushMemTable();
        }
        
        return current_memtable_->put(key, row);
    }
    
    bool get(const std::string& key, Row& row) {
        if (current_memtable_->get(key, row)) {
            return true;
        }
        
        {
            std::shared_lock<std::shared_mutex> lock(immutable_mutex_);
            for (const auto& memtable : immutable_memtables_) {
                if (memtable->get(key, row)) {
                    return true;
                }
            }
        }
        
        {
            std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
            for (auto it = sstables_.rbegin(); it != sstables_.rend(); ++it) {
                if ((*it)->get(key, row)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    bool remove(const std::string& key) {
        std::lock_guard<std::mutex> lock(write_mutex_);
        
        if (wal_) {
            wal_->appendDelete(key);
        }
        
        if (current_memtable_->isFull()) {
            flushMemTable();
        }
        
        return current_memtable_->remove(key);
    }
    
    void flush() {
        std::lock_guard<std::mutex> lock(write_mutex_);
        flushMemTable();
        
        if (wal_) {
            wal_->sync();
        }
    }
    
    void compact() {
        triggerCompaction();
    }
    
    void shutdown() {
        if (shutdown_.exchange(true)) {
            return;
        }
        
        flush();
        
        {
            std::lock_guard<std::mutex> lock(compaction_mutex_);
            compaction_cv_.notify_all();
        }
        
        if (compaction_thread_.joinable()) {
            compaction_thread_.join();
        }
    }
    
    size_t memtableSize() const { return current_memtable_->size(); }
    size_t sstableCount() const {
        std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
        return sstables_.size();
    }
    
    void getStats(std::map<std::string, uint64_t>& stats) {
        stats["memtable_size"] = current_memtable_->size();
        stats["memtable_entries"] = current_memtable_->numEntries();
        stats["immutable_memtables"] = immutable_memtables_.size();
        stats["sstable_count"] = sstableCount();
        stats["total_sstable_size"] = getTotalSSTableSize();
    }

private:
    void createDataDirectory() {
        #ifdef __linux__
        mkdir(config_.data_dir.c_str(), 0755);
        #endif
    }
    
    void flushMemTable() {
        auto snapshot = current_memtable_->snapshot();
        if (snapshot.empty()) {
            return;
        }
        
        {
            std::unique_lock<std::shared_mutex> lock(immutable_mutex_);
            immutable_memtables_.push_back(current_memtable_);
        }
        
        current_memtable_ = std::make_shared<MemTable>(config_.memtable_size);
        
        std::thread([this, snapshot = std::move(snapshot)]() mutable {
            writeSSTable(snapshot);
        }).detach();
        
        if (wal_) {
            wal_->truncate();
        }
    }
    
    void writeSSTable(const std::map<std::string, std::vector<uint8_t>>& data) {
        uint64_t id = next_sstable_id_++;
        std::string filename = config_.data_dir + "/sstable_" + std::to_string(id) + ".sst";
        
        auto sstable = SSTable::create(filename, id, data);
        
        {
            std::unique_lock<std::shared_mutex> lock(sstable_mutex_);
            sstables_.push_back(sstable);
        }
        
        {
            std::unique_lock<std::shared_mutex> lock(immutable_mutex_);
            if (!immutable_memtables_.empty()) {
                immutable_memtables_.erase(immutable_memtables_.begin());
            }
        }
        
        if (sstables_.size() >= config_.compaction_threshold) {
            triggerCompaction();
        }
    }
    
    void loadSSTables() {
        // In a real implementation, scan data_dir for existing SSTable files
        // For now, we start fresh
    }
    
    void recoverFromWAL() {
        if (!wal_) return;
        
        auto entries = wal_->replay();
        for (const auto& entry : entries) {
            if (entry.op_type == WriteAheadLog::OpType::PUT) {
                Row row = Row::deserialize(entry.value.data(), entry.value.size());
                current_memtable_->put(entry.key, row);
            } else if (entry.op_type == WriteAheadLog::OpType::DELETE) {
                current_memtable_->remove(entry.key);
            }
        }
    }
    
    void triggerCompaction() {
        std::lock_guard<std::mutex> lock(compaction_mutex_);
        if (!compaction_running_) {
            compaction_cv_.notify_one();
        }
    }
    
    void compactionWorker() {
        while (!shutdown_) {
            std::unique_lock<std::mutex> lock(compaction_mutex_);
            compaction_cv_.wait(lock, [this] {
                return shutdown_ || sstables_.size() >= config_.compaction_threshold;
            });
            
            if (shutdown_) break;
            
            compaction_running_ = true;
            lock.unlock();
            
            performCompaction();
            
            compaction_running_ = false;
        }
    }
    
    void performCompaction() {
        std::unique_lock<std::shared_mutex> lock(sstable_mutex_);
        
        if (sstables_.size() < 2) {
            return;
        }
        
        std::map<std::string, std::vector<uint8_t>> merged_data;
        
        for (size_t i = 0; i < std::min(sstables_.size(), size_t(4)); ++i) {
            sstables_[i]->forEach([&merged_data](const std::string& key, const Row& row) {
                merged_data[key] = row.serialize();
            });
        }
        
        uint64_t new_id = next_sstable_id_++;
        std::string filename = config_.data_dir + "/sstable_" + std::to_string(new_id) + ".sst";
        auto new_sstable = SSTable::create(filename, new_id, merged_data);
        
        sstables_.erase(sstables_.begin(), 
                       sstables_.begin() + std::min(sstables_.size(), size_t(4)));
        sstables_.push_back(new_sstable);
    }
    
    uint64_t getTotalSSTableSize() const {
        std::shared_lock<std::shared_mutex> lock(sstable_mutex_);
        uint64_t total = 0;
        for (const auto& sst : sstables_) {
            total += sst->size();
        }
        return total;
    }
    
    Config config_;
    std::shared_ptr<MemTable> current_memtable_;
    std::vector<std::shared_ptr<MemTable>> immutable_memtables_;
    std::vector<std::shared_ptr<SSTable>> sstables_;
    std::unique_ptr<WriteAheadLog> wal_;
    
    std::atomic<uint64_t> next_sstable_id_;
    std::atomic<bool> compaction_running_;
    std::atomic<bool> shutdown_;
    
    std::mutex write_mutex_;
    mutable std::shared_mutex immutable_mutex_;
    mutable std::shared_mutex sstable_mutex_;
    std::mutex compaction_mutex_;
    std::condition_variable compaction_cv_;
    std::thread compaction_thread_;
};

} // namespace kotana
