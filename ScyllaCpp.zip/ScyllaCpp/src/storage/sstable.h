#pragma once

#include "core/types.h"
#include "core/bloom_filter.h"
#include <string>
#include <vector>
#include <fstream>
#include <memory>
#include <map>

namespace kotana {

class SSTable {
public:
    struct IndexEntry {
        std::string key;
        uint64_t offset;
        uint32_t size;
        
        IndexEntry() : offset(0), size(0) {}
        IndexEntry(const std::string& k, uint64_t o, uint32_t s)
            : key(k), offset(o), size(s) {}
    };
    
    SSTable(const std::string& filename, uint64_t id)
        : filename_(filename), id_(id), file_size_(0) {}
    
    static std::shared_ptr<SSTable> create(
        const std::string& filename,
        uint64_t id,
        const std::map<std::string, std::vector<uint8_t>>& data) {
        
        auto sstable = std::make_shared<SSTable>(filename, id);
        sstable->write(data);
        return sstable;
    }
    
    static std::shared_ptr<SSTable> open(const std::string& filename, uint64_t id) {
        auto sstable = std::make_shared<SSTable>(filename, id);
        sstable->load();
        return sstable;
    }
    
    bool get(const std::string& key, Row& row) const {
        if (!bloom_filter_.mightContain(key)) {
            return false;
        }
        
        auto it = index_.find(key);
        if (it == index_.end()) {
            return false;
        }
        
        std::ifstream file(filename_, std::ios::binary);
        if (!file) {
            return false;
        }
        
        file.seekg(it->second.offset);
        std::vector<uint8_t> data(it->second.size);
        file.read(reinterpret_cast<char*>(data.data()), it->second.size);
        
        row = Row::deserialize(data.data(), data.size());
        return true;
    }
    
    bool contains(const std::string& key) const {
        if (!bloom_filter_.mightContain(key)) {
            return false;
        }
        return index_.find(key) != index_.end();
    }
    
    std::vector<std::string> keys() const {
        std::vector<std::string> result;
        result.reserve(index_.size());
        for (const auto& [key, _] : index_) {
            result.push_back(key);
        }
        return result;
    }
    
    const std::string& filename() const { return filename_; }
    uint64_t id() const { return id_; }
    size_t size() const { return file_size_; }
    size_t numEntries() const { return index_.size(); }
    
    void forEach(std::function<void(const std::string&, const Row&)> callback) const {
        std::ifstream file(filename_, std::ios::binary);
        if (!file) return;
        
        for (const auto& [key, entry] : index_) {
            file.seekg(entry.offset);
            std::vector<uint8_t> data(entry.size);
            file.read(reinterpret_cast<char*>(data.data()), entry.size);
            
            Row row = Row::deserialize(data.data(), data.size());
            callback(key, row);
        }
    }

private:
    void write(const std::map<std::string, std::vector<uint8_t>>& data) {
        std::ofstream file(filename_, std::ios::binary | std::ios::trunc);
        if (!file) {
            throw std::runtime_error("Failed to create SSTable file: " + filename_);
        }
        
        bloom_filter_ = BloomFilter(data.size(), 0.01);
        
        uint64_t offset = 0;
        for (const auto& [key, value] : data) {
            uint32_t key_size = key.size();
            uint32_t value_size = value.size();
            
            file.write(reinterpret_cast<const char*>(&key_size), sizeof(key_size));
            file.write(key.data(), key_size);
            file.write(reinterpret_cast<const char*>(&value_size), sizeof(value_size));
            file.write(reinterpret_cast<const char*>(value.data()), value_size);
            
            size_t entry_size = sizeof(key_size) + key_size + sizeof(value_size) + value_size;
            index_[key] = IndexEntry(key, offset + sizeof(key_size) + key_size + sizeof(value_size), value_size);
            
            bloom_filter_.add(key);
            offset += entry_size;
        }
        
        file_size_ = offset;
        
        writeMetadata(file);
    }
    
    void load() {
        std::ifstream file(filename_, std::ios::binary);
        if (!file) {
            throw std::runtime_error("Failed to open SSTable file: " + filename_);
        }
        
        file.seekg(0, std::ios::end);
        file_size_ = file.tellg();
        file.seekg(0, std::ios::beg);
        
        uint64_t offset = 0;
        while (offset < file_size_) {
            uint32_t key_size;
            file.read(reinterpret_cast<char*>(&key_size), sizeof(key_size));
            if (file.eof()) break;
            
            std::string key(key_size, '\0');
            file.read(&key[0], key_size);
            
            uint32_t value_size;
            file.read(reinterpret_cast<char*>(&value_size), sizeof(value_size));
            
            index_[key] = IndexEntry(key, offset + sizeof(key_size) + key_size + sizeof(value_size), value_size);
            
            file.seekg(value_size, std::ios::cur);
            offset += sizeof(key_size) + key_size + sizeof(value_size) + value_size;
        }
        
        bloom_filter_ = BloomFilter(index_.size(), 0.01);
        for (const auto& [key, _] : index_) {
            bloom_filter_.add(key);
        }
    }
    
    void writeMetadata(std::ofstream& file) {
        auto bloom_data = bloom_filter_.serialize();
        uint32_t bloom_size = bloom_data.size();
        
        file.write(reinterpret_cast<const char*>(&bloom_size), sizeof(bloom_size));
        file.write(reinterpret_cast<const char*>(bloom_data.data()), bloom_size);
        
        uint32_t index_size = index_.size();
        file.write(reinterpret_cast<const char*>(&index_size), sizeof(index_size));
        
        for (const auto& [key, entry] : index_) {
            uint32_t key_size = key.size();
            file.write(reinterpret_cast<const char*>(&key_size), sizeof(key_size));
            file.write(key.data(), key_size);
            file.write(reinterpret_cast<const char*>(&entry.offset), sizeof(entry.offset));
            file.write(reinterpret_cast<const char*>(&entry.size), sizeof(entry.size));
        }
    }
    
    std::string filename_;
    uint64_t id_;
    size_t file_size_;
    std::map<std::string, IndexEntry> index_;
    BloomFilter bloom_filter_{1, 0.01};
};

} // namespace kotana
