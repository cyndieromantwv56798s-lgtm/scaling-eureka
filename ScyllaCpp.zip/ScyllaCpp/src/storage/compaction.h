#pragma once

#include "sstable.h"
#include "core/metrics.h"
#include <vector>
#include <memory>
#include <algorithm>
#include <map>

namespace kotana {

enum class CompactionStrategy {
    SIZE_TIERED,
    LEVELED,
    TIME_WINDOW
};

class CompactionManager {
public:
    struct CompactionTask {
        std::vector<std::shared_ptr<SSTable>> input_sstables;
        int level;
        CompactionStrategy strategy;
        
        CompactionTask(CompactionStrategy s = CompactionStrategy::SIZE_TIERED)
            : level(0), strategy(s) {}
    };
    
    explicit CompactionManager(CompactionStrategy strategy = CompactionStrategy::SIZE_TIERED)
        : strategy_(strategy), total_compactions_(0) {}
    
    CompactionTask selectCompaction(const std::vector<std::shared_ptr<SSTable>>& sstables) {
        CompactionTask task(strategy_);
        
        switch (strategy_) {
            case CompactionStrategy::SIZE_TIERED:
                return selectSizeTieredCompaction(sstables);
            case CompactionStrategy::LEVELED:
                return selectLeveledCompaction(sstables);
            case CompactionStrategy::TIME_WINDOW:
                return selectTimeWindowCompaction(sstables);
            default:
                return task;
        }
    }
    
    std::shared_ptr<SSTable> performCompaction(
        const CompactionTask& task,
        const std::string& output_dir,
        uint64_t output_id) {
        
        if (task.input_sstables.empty()) {
            return nullptr;
        }
        
        std::map<std::string, std::vector<uint8_t>> merged_data;
        
        for (const auto& sstable : task.input_sstables) {
            sstable->forEach([&merged_data](const std::string& key, const Row& row) {
                merged_data[key] = row.serialize();
            });
        }
        
        std::string output_filename = output_dir + "/sstable_" + 
                                     std::to_string(output_id) + ".sst";
        
        auto output_sstable = SSTable::create(output_filename, output_id, merged_data);
        
        ++total_compactions_;
        MetricsCollector::instance().incrementCompactions();
        MetricsCollector::instance().incrementSSTablesCreated();
        
        return output_sstable;
    }
    
    bool shouldCompact(const std::vector<std::shared_ptr<SSTable>>& sstables, 
                      size_t threshold) const {
        return sstables.size() >= threshold;
    }
    
    uint64_t totalCompactions() const { return total_compactions_; }
    
    void setStrategy(CompactionStrategy strategy) { strategy_ = strategy; }
    CompactionStrategy getStrategy() const { return strategy_; }

private:
    CompactionTask selectSizeTieredCompaction(
        const std::vector<std::shared_ptr<SSTable>>& sstables) {
        
        CompactionTask task(CompactionStrategy::SIZE_TIERED);
        
        if (sstables.size() < 4) {
            return task;
        }
        
        std::vector<std::shared_ptr<SSTable>> sorted_sstables = sstables;
        std::sort(sorted_sstables.begin(), sorted_sstables.end(),
            [](const auto& a, const auto& b) {
                return a->size() < b->size();
            });
        
        size_t bucket_size = 4;
        for (size_t i = 0; i < sorted_sstables.size() && i < bucket_size; ++i) {
            task.input_sstables.push_back(sorted_sstables[i]);
        }
        
        return task;
    }
    
    CompactionTask selectLeveledCompaction(
        const std::vector<std::shared_ptr<SSTable>>& sstables) {
        
        CompactionTask task(CompactionStrategy::LEVELED);
        
        std::map<int, std::vector<std::shared_ptr<SSTable>>> levels;
        
        for (const auto& sst : sstables) {
            int level = calculateLevel(sst->size());
            levels[level].push_back(sst);
        }
        
        for (auto& [level, level_sstables] : levels) {
            size_t max_size_for_level = 10 * (1 << level);
            
            if (level_sstables.size() > max_size_for_level) {
                task.level = level;
                task.input_sstables = level_sstables;
                break;
            }
        }
        
        return task;
    }
    
    CompactionTask selectTimeWindowCompaction(
        const std::vector<std::shared_ptr<SSTable>>& sstables) {
        
        CompactionTask task(CompactionStrategy::TIME_WINDOW);
        
        if (sstables.size() < 4) {
            return task;
        }
        
        std::vector<std::shared_ptr<SSTable>> sorted_by_id = sstables;
        std::sort(sorted_by_id.begin(), sorted_by_id.end(),
            [](const auto& a, const auto& b) {
                return a->id() < b->id();
            });
        
        for (size_t i = 0; i < std::min(sorted_by_id.size(), size_t(4)); ++i) {
            task.input_sstables.push_back(sorted_by_id[i]);
        }
        
        return task;
    }
    
    int calculateLevel(size_t size) const {
        const size_t base_size = 10 * 1024 * 1024;
        int level = 0;
        size_t threshold = base_size;
        
        while (size > threshold && level < 10) {
            ++level;
            threshold *= 10;
        }
        
        return level;
    }
    
    CompactionStrategy strategy_;
    uint64_t total_compactions_;
};

} // namespace kotana
