#pragma once

#include "core/types.h"
#include "core/metrics.h"
#include <unordered_map>
#include <list>
#include <mutex>
#include <shared_mutex>
#include <memory>
#include <optional>

namespace kotana {

template<typename Key, typename Value>
class LRUCache {
public:
    explicit LRUCache(size_t capacity) 
        : capacity_(capacity), current_size_(0) {}
    
    bool get(const Key& key, Value& value) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        auto it = cache_map_.find(key);
        if (it == cache_map_.end()) {
            MetricsCollector::instance().incrementCacheMisses();
            return false;
        }
        
        lru_list_.splice(lru_list_.begin(), lru_list_, it->second);
        value = it->second->second;
        
        MetricsCollector::instance().incrementCacheHits();
        return true;
    }
    
    void put(const Key& key, const Value& value) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        auto it = cache_map_.find(key);
        if (it != cache_map_.end()) {
            lru_list_.erase(it->second);
            cache_map_.erase(it);
            --current_size_;
        }
        
        if (current_size_ >= capacity_) {
            auto last = lru_list_.end();
            --last;
            cache_map_.erase(last->first);
            lru_list_.pop_back();
            --current_size_;
        }
        
        lru_list_.push_front(std::make_pair(key, value));
        cache_map_[key] = lru_list_.begin();
        ++current_size_;
    }
    
    bool contains(const Key& key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return cache_map_.find(key) != cache_map_.end();
    }
    
    void remove(const Key& key) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        auto it = cache_map_.find(key);
        if (it != cache_map_.end()) {
            lru_list_.erase(it->second);
            cache_map_.erase(it);
            --current_size_;
        }
    }
    
    void clear() {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        cache_map_.clear();
        lru_list_.clear();
        current_size_ = 0;
    }
    
    size_t size() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return current_size_;
    }
    
    size_t capacity() const { return capacity_; }
    
    double hitRate() const {
        uint64_t hits = MetricsCollector::instance().getMetrics().cache_hits.load();
        uint64_t misses = MetricsCollector::instance().getMetrics().cache_misses.load();
        uint64_t total = hits + misses;
        return total > 0 ? static_cast<double>(hits) / total : 0.0;
    }

private:
    size_t capacity_;
    size_t current_size_;
    
    std::list<std::pair<Key, Value>> lru_list_;
    std::unordered_map<Key, typename std::list<std::pair<Key, Value>>::iterator> cache_map_;
    
    mutable std::shared_mutex mutex_;
};

class RowCache {
public:
    explicit RowCache(size_t capacity_mb)
        : cache_(capacity_mb * 1024) {}
    
    bool get(const std::string& key, Row& row) {
        return cache_.get(key, row);
    }
    
    void put(const std::string& key, const Row& row) {
        cache_.put(key, row);
    }
    
    bool contains(const std::string& key) const {
        return cache_.contains(key);
    }
    
    void remove(const std::string& key) {
        cache_.remove(key);
    }
    
    void clear() {
        cache_.clear();
    }
    
    size_t size() const {
        return cache_.size();
    }
    
    double hitRate() const {
        return cache_.hitRate();
    }

private:
    LRUCache<std::string, Row> cache_;
};

class QueryCache {
public:
    struct CachedResult {
        QueryResult result;
        uint64_t timestamp;
        uint64_t ttl_ms;
        
        CachedResult() : timestamp(0), ttl_ms(0) {}
        CachedResult(const QueryResult& r, uint64_t ttl)
            : result(r), 
              timestamp(std::chrono::duration_cast<std::chrono::milliseconds>(
                  std::chrono::system_clock::now().time_since_epoch()).count()),
              ttl_ms(ttl) {}
        
        bool isExpired() const {
            if (ttl_ms == 0) return false;
            
            uint64_t now = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            
            return (now - timestamp) > ttl_ms;
        }
    };
    
    explicit QueryCache(size_t capacity, uint64_t default_ttl_ms = 60000)
        : cache_(capacity), default_ttl_ms_(default_ttl_ms) {}
    
    bool get(const std::string& query, QueryResult& result) {
        CachedResult cached;
        if (cache_.get(query, cached)) {
            if (!cached.isExpired()) {
                result = cached.result;
                return true;
            } else {
                cache_.remove(query);
            }
        }
        return false;
    }
    
    void put(const std::string& query, const QueryResult& result) {
        put(query, result, default_ttl_ms_);
    }
    
    void put(const std::string& query, const QueryResult& result, uint64_t ttl_ms) {
        CachedResult cached(result, ttl_ms);
        cache_.put(query, cached);
    }
    
    void invalidate(const std::string& query) {
        cache_.remove(query);
    }
    
    void clear() {
        cache_.clear();
    }
    
    size_t size() const {
        return cache_.size();
    }

private:
    LRUCache<std::string, CachedResult> cache_;
    uint64_t default_ttl_ms_;
};

} // namespace kotana
