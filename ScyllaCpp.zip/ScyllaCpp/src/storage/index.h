#pragma once

#include "core/types.h"
#include <map>
#include <set>
#include <vector>
#include <memory>
#include <shared_mutex>

namespace kotana {

class SecondaryIndex {
public:
    explicit SecondaryIndex(const std::string& column_name)
        : column_name_(column_name), entry_count_(0) {}
    
    void insert(const Value& indexed_value, const std::string& row_key) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        std::string value_str = indexed_value.toString();
        index_[value_str].insert(row_key);
        ++entry_count_;
    }
    
    void remove(const Value& indexed_value, const std::string& row_key) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        std::string value_str = indexed_value.toString();
        auto it = index_.find(value_str);
        if (it != index_.end()) {
            it->second.erase(row_key);
            if (it->second.empty()) {
                index_.erase(it);
            }
            --entry_count_;
        }
    }
    
    std::vector<std::string> lookup(const Value& indexed_value) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::string value_str = indexed_value.toString();
        auto it = index_.find(value_str);
        
        if (it != index_.end()) {
            return std::vector<std::string>(it->second.begin(), it->second.end());
        }
        
        return {};
    }
    
    std::vector<std::string> range(const Value& start, const Value& end) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::string start_str = start.toString();
        std::string end_str = end.toString();
        
        std::vector<std::string> results;
        
        auto it_start = index_.lower_bound(start_str);
        auto it_end = index_.upper_bound(end_str);
        
        for (auto it = it_start; it != it_end; ++it) {
            results.insert(results.end(), it->second.begin(), it->second.end());
        }
        
        return results;
    }
    
    void clear() {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        index_.clear();
        entry_count_ = 0;
    }
    
    size_t size() const { return entry_count_; }
    const std::string& columnName() const { return column_name_; }
    
    size_t memoryUsage() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        size_t total = 0;
        for (const auto& [key, values] : index_) {
            total += key.size();
            for (const auto& val : values) {
                total += val.size();
            }
        }
        return total;
    }

private:
    std::string column_name_;
    std::map<std::string, std::set<std::string>> index_;
    size_t entry_count_;
    mutable std::shared_mutex mutex_;
};

class IndexManager {
public:
    IndexManager() = default;
    
    bool createIndex(const std::string& table_name, const std::string& column_name) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        std::string index_key = makeIndexKey(table_name, column_name);
        
        if (indexes_.find(index_key) != indexes_.end()) {
            return false;
        }
        
        indexes_[index_key] = std::make_shared<SecondaryIndex>(column_name);
        return true;
    }
    
    bool dropIndex(const std::string& table_name, const std::string& column_name) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        
        std::string index_key = makeIndexKey(table_name, column_name);
        return indexes_.erase(index_key) > 0;
    }
    
    std::shared_ptr<SecondaryIndex> getIndex(const std::string& table_name, 
                                            const std::string& column_name) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::string index_key = makeIndexKey(table_name, column_name);
        auto it = indexes_.find(index_key);
        
        return it != indexes_.end() ? it->second : nullptr;
    }
    
    bool hasIndex(const std::string& table_name, const std::string& column_name) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::string index_key = makeIndexKey(table_name, column_name);
        return indexes_.find(index_key) != indexes_.end();
    }
    
    std::vector<std::string> listIndexes(const std::string& table_name) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::vector<std::string> result;
        std::string prefix = table_name + ":";
        
        for (const auto& [key, _] : indexes_) {
            if (key.find(prefix) == 0) {
                result.push_back(key.substr(prefix.size()));
            }
        }
        
        return result;
    }
    
    void updateIndex(const std::string& table_name, 
                    const std::string& column_name,
                    const Value& indexed_value,
                    const std::string& row_key) {
        auto index = getIndex(table_name, column_name);
        if (index) {
            index->insert(indexed_value, row_key);
        }
    }
    
    void removeFromIndex(const std::string& table_name,
                        const std::string& column_name,
                        const Value& indexed_value,
                        const std::string& row_key) {
        auto index = getIndex(table_name, column_name);
        if (index) {
            index->remove(indexed_value, row_key);
        }
    }
    
    size_t totalIndexes() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return indexes_.size();
    }
    
    size_t totalMemoryUsage() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        size_t total = 0;
        for (const auto& [_, index] : indexes_) {
            total += index->memoryUsage();
        }
        return total;
    }

private:
    std::string makeIndexKey(const std::string& table_name, 
                            const std::string& column_name) const {
        return table_name + ":" + column_name;
    }
    
    std::map<std::string, std::shared_ptr<SecondaryIndex>> indexes_;
    mutable std::shared_mutex mutex_;
};

class PartitionIndex {
public:
    PartitionIndex() = default;
    
    void addPartition(const std::string& partition_key, uint64_t partition_id) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        partition_map_[partition_key] = partition_id;
    }
    
    uint64_t getPartition(const std::string& partition_key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        auto it = partition_map_.find(partition_key);
        return it != partition_map_.end() ? it->second : 0;
    }
    
    bool hasPartition(const std::string& partition_key) const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return partition_map_.find(partition_key) != partition_map_.end();
    }
    
    void removePartition(const std::string& partition_key) {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        partition_map_.erase(partition_key);
    }
    
    std::vector<std::string> getAllPartitionKeys() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        
        std::vector<std::string> keys;
        keys.reserve(partition_map_.size());
        
        for (const auto& [key, _] : partition_map_) {
            keys.push_back(key);
        }
        
        return keys;
    }
    
    size_t size() const {
        std::shared_lock<std::shared_mutex> lock(mutex_);
        return partition_map_.size();
    }
    
    void clear() {
        std::unique_lock<std::shared_mutex> lock(mutex_);
        partition_map_.clear();
    }

private:
    std::map<std::string, uint64_t> partition_map_;
    mutable std::shared_mutex mutex_;
};

} // namespace kotana
