#pragma once

#include "core/types.h"
#include "core/utils.h"
#include <vector>
#include <string>
#include <memory>
#include <mutex>
#include <map>
#include <set>
#include <atomic>

namespace kotana {

enum class ConsistencyLevel {
    ONE,
    QUORUM,
    ALL,
    LOCAL_ONE,
    LOCAL_QUORUM,
    EACH_QUORUM
};

enum class ReplicaState {
    ACTIVE,
    SYNCING,
    OFFLINE,
    FAILED
};

class Replica {
public:
    Replica(const std::string& id, const std::string& address, uint16_t port)
        : id_(id), address_(address), port_(port), state_(ReplicaState::ACTIVE),
          last_sync_timestamp_(0), lag_bytes_(0) {}
    
    const std::string& id() const { return id_; }
    const std::string& address() const { return address_; }
    uint16_t port() const { return port_; }
    
    ReplicaState state() const { return state_; }
    void setState(ReplicaState state) { state_ = state; }
    
    uint64_t lastSyncTimestamp() const { return last_sync_timestamp_; }
    void updateLastSync() { last_sync_timestamp_ = Utils::getCurrentTimestamp(); }
    
    uint64_t lagBytes() const { return lag_bytes_; }
    void setLagBytes(uint64_t lag) { lag_bytes_ = lag; }
    
    bool isHealthy() const {
        return state_ == ReplicaState::ACTIVE || state_ == ReplicaState::SYNCING;
    }
    
    uint64_t lagMilliseconds() const {
        if (last_sync_timestamp_ == 0) return 0;
        uint64_t now = Utils::getCurrentTimestamp();
        return (now - last_sync_timestamp_) / 1000;
    }

private:
    std::string id_;
    std::string address_;
    uint16_t port_;
    ReplicaState state_;
    uint64_t last_sync_timestamp_;
    uint64_t lag_bytes_;
};

class ReplicationGroup {
public:
    explicit ReplicationGroup(const std::string& name, size_t replication_factor = 3)
        : name_(name), replication_factor_(replication_factor) {}
    
    const std::string& name() const { return name_; }
    size_t replicationFactor() const { return replication_factor_; }
    
    void addReplica(std::shared_ptr<Replica> replica) {
        std::unique_lock<std::mutex> lock(mutex_);
        replicas_[replica->id()] = replica;
    }
    
    void removeReplica(const std::string& replica_id) {
        std::unique_lock<std::mutex> lock(mutex_);
        replicas_.erase(replica_id);
    }
    
    std::shared_ptr<Replica> getReplica(const std::string& replica_id) const {
        std::unique_lock<std::mutex> lock(mutex_);
        auto it = replicas_.find(replica_id);
        return it != replicas_.end() ? it->second : nullptr;
    }
    
    std::vector<std::shared_ptr<Replica>> getAllReplicas() const {
        std::unique_lock<std::mutex> lock(mutex_);
        std::vector<std::shared_ptr<Replica>> result;
        result.reserve(replicas_.size());
        for (const auto& [_, replica] : replicas_) {
            result.push_back(replica);
        }
        return result;
    }
    
    std::vector<std::shared_ptr<Replica>> getHealthyReplicas() const {
        std::unique_lock<std::mutex> lock(mutex_);
        std::vector<std::shared_ptr<Replica>> result;
        for (const auto& [_, replica] : replicas_) {
            if (replica->isHealthy()) {
                result.push_back(replica);
            }
        }
        return result;
    }
    
    size_t healthyReplicaCount() const {
        std::unique_lock<std::mutex> lock(mutex_);
        size_t count = 0;
        for (const auto& [_, replica] : replicas_) {
            if (replica->isHealthy()) {
                ++count;
            }
        }
        return count;
    }
    
    size_t quorumSize() const {
        return (replication_factor_ / 2) + 1;
    }
    
    bool hasQuorum() const {
        return healthyReplicaCount() >= quorumSize();
    }

private:
    std::string name_;
    size_t replication_factor_;
    std::map<std::string, std::shared_ptr<Replica>> replicas_;
    mutable std::mutex mutex_;
};

class ReplicationLog {
public:
    struct LogEntry {
        uint64_t sequence_number;
        std::string operation;
        std::string key;
        std::vector<uint8_t> value;
        uint64_t timestamp;
        
        LogEntry() : sequence_number(0), timestamp(0) {}
        LogEntry(uint64_t seq, const std::string& op, const std::string& k, 
                const std::vector<uint8_t>& v)
            : sequence_number(seq), operation(op), key(k), value(v),
              timestamp(Utils::getCurrentTimestamp()) {}
    };
    
    ReplicationLog() : next_sequence_(1) {}
    
    uint64_t append(const std::string& operation, const std::string& key, 
                   const std::vector<uint8_t>& value) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        uint64_t seq = next_sequence_++;
        log_.emplace_back(seq, operation, key, value);
        
        if (log_.size() > 10000) {
            compactLog();
        }
        
        return seq;
    }
    
    std::vector<LogEntry> getEntriesSince(uint64_t sequence_number) const {
        std::unique_lock<std::mutex> lock(mutex_);
        
        std::vector<LogEntry> result;
        
        for (const auto& entry : log_) {
            if (entry.sequence_number > sequence_number) {
                result.push_back(entry);
            }
        }
        
        return result;
    }
    
    std::vector<LogEntry> getEntriesRange(uint64_t start_seq, uint64_t end_seq) const {
        std::unique_lock<std::mutex> lock(mutex_);
        
        std::vector<LogEntry> result;
        
        for (const auto& entry : log_) {
            if (entry.sequence_number >= start_seq && entry.sequence_number <= end_seq) {
                result.push_back(entry);
            }
        }
        
        return result;
    }
    
    uint64_t latestSequence() const {
        return next_sequence_.load() - 1;
    }
    
    size_t size() const {
        std::unique_lock<std::mutex> lock(mutex_);
        return log_.size();
    }
    
    void truncate(uint64_t before_sequence) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        log_.erase(
            std::remove_if(log_.begin(), log_.end(),
                [before_sequence](const LogEntry& e) {
                    return e.sequence_number < before_sequence;
                }),
            log_.end()
        );
    }

private:
    void compactLog() {
        if (log_.size() <= 5000) {
            return;
        }
        
        size_t keep_count = 5000;
        size_t remove_count = log_.size() - keep_count;
        
        log_.erase(log_.begin(), log_.begin() + remove_count);
    }
    
    std::vector<LogEntry> log_;
    std::atomic<uint64_t> next_sequence_;
    mutable std::mutex mutex_;
};

class ReplicationManager {
public:
    struct Config {
        size_t replication_factor = 3;
        ConsistencyLevel default_consistency = ConsistencyLevel::QUORUM;
        uint64_t sync_interval_ms = 100;
        uint64_t heartbeat_interval_ms = 1000;
        uint64_t max_lag_bytes = 10 * 1024 * 1024;
        
        Config() = default;
    };
    
    explicit ReplicationManager(const Config& config = Config())
        : config_(config),
          local_replica_id_(Utils::generateUUID()),
          total_replications_(0),
          failed_replications_(0) {}
    
    void setLocalReplicaId(const std::string& id) {
        local_replica_id_ = id;
    }
    
    std::string localReplicaId() const {
        return local_replica_id_;
    }
    
    std::shared_ptr<ReplicationGroup> createGroup(const std::string& name) {
        std::unique_lock<std::mutex> lock(mutex_);
        
        auto group = std::make_shared<ReplicationGroup>(name, config_.replication_factor);
        groups_[name] = group;
        
        return group;
    }
    
    std::shared_ptr<ReplicationGroup> getGroup(const std::string& name) const {
        std::unique_lock<std::mutex> lock(mutex_);
        
        auto it = groups_.find(name);
        return it != groups_.end() ? it->second : nullptr;
    }
    
    bool replicate(const std::string& group_name, const std::string& operation,
                  const std::string& key, const std::vector<uint8_t>& value,
                  ConsistencyLevel consistency = ConsistencyLevel::QUORUM) {
        
        auto group = getGroup(group_name);
        if (!group) {
            return false;
        }
        
        uint64_t sequence = replication_log_.append(operation, key, value);
        
        auto replicas = group->getHealthyReplicas();
        
        size_t required_acks = calculateRequiredAcks(consistency, group);
        size_t acks = 1;
        
        for (const auto& replica : replicas) {
            if (replica->id() == local_replica_id_) {
                continue;
            }
            
            if (replicateToReplica(replica, operation, key, value, sequence)) {
                ++acks;
                ++total_replications_;
            } else {
                ++failed_replications_;
            }
            
            if (acks >= required_acks) {
                break;
            }
        }
        
        return acks >= required_acks;
    }
    
    std::vector<ReplicationLog::LogEntry> getReplicationLog(uint64_t since_sequence) const {
        return replication_log_.getEntriesSince(since_sequence);
    }
    
    uint64_t latestSequence() const {
        return replication_log_.latestSequence();
    }
    
    void getStats(std::map<std::string, uint64_t>& stats) const {
        stats["total_replications"] = total_replications_.load();
        stats["failed_replications"] = failed_replications_.load();
        stats["replication_log_size"] = replication_log_.size();
        
        std::unique_lock<std::mutex> lock(mutex_);
        stats["replication_groups"] = groups_.size();
        
        size_t total_replicas = 0;
        size_t healthy_replicas = 0;
        
        for (const auto& [_, group] : groups_) {
            total_replicas += group->getAllReplicas().size();
            healthy_replicas += group->healthyReplicaCount();
        }
        
        stats["total_replicas"] = total_replicas;
        stats["healthy_replicas"] = healthy_replicas;
    }

private:
    size_t calculateRequiredAcks(ConsistencyLevel consistency, 
                                 std::shared_ptr<ReplicationGroup> group) const {
        switch (consistency) {
            case ConsistencyLevel::ONE:
            case ConsistencyLevel::LOCAL_ONE:
                return 1;
            
            case ConsistencyLevel::QUORUM:
            case ConsistencyLevel::LOCAL_QUORUM:
                return group->quorumSize();
            
            case ConsistencyLevel::ALL:
                return group->replicationFactor();
            
            case ConsistencyLevel::EACH_QUORUM:
                return group->quorumSize();
            
            default:
                return 1;
        }
    }
    
    bool replicateToReplica(std::shared_ptr<Replica> replica,
                           const std::string& operation,
                           const std::string& key,
                           const std::vector<uint8_t>& value,
                           uint64_t sequence) {
        
        replica->updateLastSync();
        return true;
    }
    
    Config config_;
    std::string local_replica_id_;
    
    std::map<std::string, std::shared_ptr<ReplicationGroup>> groups_;
    mutable std::mutex mutex_;
    
    ReplicationLog replication_log_;
    
    std::atomic<uint64_t> total_replications_;
    std::atomic<uint64_t> failed_replications_;
};

} // namespace kotana
