#pragma once

#include <memory>
#include <vector>
#include <mutex>
#include <atomic>
#include <cstdint>
#include <cstdlib>

namespace kotana {

class MemoryPool {
public:
    static constexpr size_t DEFAULT_BLOCK_SIZE = 4096;
    static constexpr size_t DEFAULT_POOL_SIZE = 1024 * 1024 * 64; // 64MB
    
    MemoryPool(size_t block_size = DEFAULT_BLOCK_SIZE, 
               size_t pool_size = DEFAULT_POOL_SIZE)
        : block_size_(block_size),
          pool_size_(pool_size),
          allocated_bytes_(0),
          total_allocations_(0) {
        
        size_t num_blocks = pool_size / block_size;
        blocks_.reserve(num_blocks);
        
        for (size_t i = 0; i < num_blocks; ++i) {
            void* block = std::aligned_alloc(64, block_size);
            if (block) {
                free_blocks_.push_back(block);
            }
        }
    }
    
    ~MemoryPool() {
        for (void* block : blocks_) {
            std::free(block);
        }
        for (void* block : free_blocks_) {
            std::free(block);
        }
    }
    
    void* allocate(size_t size) {
        if (size > block_size_) {
            return std::malloc(size);
        }
        
        std::lock_guard<std::mutex> lock(mutex_);
        
        if (free_blocks_.empty()) {
            void* new_block = std::aligned_alloc(64, block_size_);
            if (!new_block) {
                return nullptr;
            }
            blocks_.push_back(new_block);
            allocated_bytes_ += block_size_;
            ++total_allocations_;
            return new_block;
        }
        
        void* block = free_blocks_.back();
        free_blocks_.pop_back();
        ++total_allocations_;
        
        return block;
    }
    
    void deallocate(void* ptr, size_t size) {
        if (!ptr) return;
        
        if (size > block_size_) {
            std::free(ptr);
            return;
        }
        
        std::lock_guard<std::mutex> lock(mutex_);
        free_blocks_.push_back(ptr);
    }
    
    size_t allocatedBytes() const { return allocated_bytes_.load(); }
    size_t totalAllocations() const { return total_allocations_.load(); }
    size_t availableBlocks() const {
        std::lock_guard<std::mutex> lock(mutex_);
        return free_blocks_.size();
    }

private:
    size_t block_size_;
    size_t pool_size_;
    std::atomic<size_t> allocated_bytes_;
    std::atomic<size_t> total_allocations_;
    
    std::vector<void*> blocks_;
    std::vector<void*> free_blocks_;
    mutable std::mutex mutex_;
};

template<typename T>
class PoolAllocator {
public:
    using value_type = T;
    
    explicit PoolAllocator(MemoryPool& pool) : pool_(&pool) {}
    
    template<typename U>
    PoolAllocator(const PoolAllocator<U>& other) : pool_(other.pool_) {}
    
    T* allocate(size_t n) {
        return static_cast<T*>(pool_->allocate(n * sizeof(T)));
    }
    
    void deallocate(T* ptr, size_t n) {
        pool_->deallocate(ptr, n * sizeof(T));
    }
    
    template<typename U>
    struct rebind {
        using other = PoolAllocator<U>;
    };
    
private:
    MemoryPool* pool_;
    
    template<typename U>
    friend class PoolAllocator;
};

} // namespace kotana
