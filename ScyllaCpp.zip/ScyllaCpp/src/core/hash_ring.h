#pragma once

#include <string>
#include <map>
#include <vector>
#include <functional>
#include <algorithm>

namespace kotana {

class ConsistentHashRing {
public:
    static constexpr size_t DEFAULT_VIRTUAL_NODES = 150;
    
    explicit ConsistentHashRing(size_t virtual_nodes = DEFAULT_VIRTUAL_NODES)
        : virtual_nodes_per_node_(virtual_nodes) {}
    
    void addNode(const std::string& node) {
        for (size_t i = 0; i < virtual_nodes_per_node_; ++i) {
            std::string vnode = node + ":" + std::to_string(i);
            uint64_t hash = computeHash(vnode);
            ring_[hash] = node;
        }
        nodes_.push_back(node);
    }
    
    void removeNode(const std::string& node) {
        for (size_t i = 0; i < virtual_nodes_per_node_; ++i) {
            std::string vnode = node + ":" + std::to_string(i);
            uint64_t hash = computeHash(vnode);
            ring_.erase(hash);
        }
        
        auto it = std::find(nodes_.begin(), nodes_.end(), node);
        if (it != nodes_.end()) {
            nodes_.erase(it);
        }
    }
    
    std::string getNode(const std::string& key) const {
        if (ring_.empty()) {
            return "";
        }
        
        uint64_t hash = computeHash(key);
        auto it = ring_.lower_bound(hash);
        
        if (it == ring_.end()) {
            it = ring_.begin();
        }
        
        return it->second;
    }
    
    std::vector<std::string> getNodes(const std::string& key, size_t count) const {
        std::vector<std::string> result;
        if (ring_.empty() || count == 0) {
            return result;
        }
        
        uint64_t hash = computeHash(key);
        auto it = ring_.lower_bound(hash);
        
        std::set<std::string> unique_nodes;
        
        while (unique_nodes.size() < count && unique_nodes.size() < nodes_.size()) {
            if (it == ring_.end()) {
                it = ring_.begin();
            }
            
            unique_nodes.insert(it->second);
            ++it;
        }
        
        result.assign(unique_nodes.begin(), unique_nodes.end());
        return result;
    }
    
    const std::vector<std::string>& nodes() const { return nodes_; }
    size_t nodeCount() const { return nodes_.size(); }
    
private:
    uint64_t computeHash(const std::string& key) const {
        std::hash<std::string> hasher;
        uint64_t h = hasher(key);
        
        h ^= h >> 33;
        h *= 0xff51afd7ed558ccdULL;
        h ^= h >> 33;
        h *= 0xc4ceb9fe1a85ec53ULL;
        h ^= h >> 33;
        
        return h;
    }
    
    size_t virtual_nodes_per_node_;
    std::map<uint64_t, std::string> ring_;
    std::vector<std::string> nodes_;
};

} // namespace kotana
