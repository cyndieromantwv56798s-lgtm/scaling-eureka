#include "types.h"
#include <cstring>
#include <sstream>
#include <iomanip>

namespace kotana {

std::string Value::toString() const {
    std::ostringstream oss;
    switch (type_) {
        case DataType::INT32:
            oss << asInt32();
            break;
        case DataType::INT64:
            oss << asInt64();
            break;
        case DataType::FLOAT:
            oss << asFloat();
            break;
        case DataType::DOUBLE:
            oss << asDouble();
            break;
        case DataType::STRING:
            oss << "\"" << asString() << "\"";
            break;
        case DataType::BOOLEAN:
            oss << (asBool() ? "true" : "false");
            break;
        case DataType::BLOB:
            oss << "<blob:" << asBlob().size() << " bytes>";
            break;
        case DataType::TIMESTAMP:
            oss << std::get<uint64_t>(data_);
            break;
        default:
            oss << "<unknown>";
    }
    return oss.str();
}

size_t Value::serializedSize() const {
    size_t size = sizeof(uint8_t); // type
    switch (type_) {
        case DataType::INT32:
            return size + sizeof(int32_t);
        case DataType::INT64:
        case DataType::TIMESTAMP:
            return size + sizeof(int64_t);
        case DataType::FLOAT:
            return size + sizeof(float);
        case DataType::DOUBLE:
            return size + sizeof(double);
        case DataType::BOOLEAN:
            return size + sizeof(bool);
        case DataType::STRING:
            return size + sizeof(uint32_t) + asString().size();
        case DataType::BLOB:
            return size + sizeof(uint32_t) + asBlob().size();
        default:
            return size;
    }
}

std::vector<uint8_t> Value::serialize() const {
    std::vector<uint8_t> buffer;
    buffer.reserve(serializedSize());
    
    buffer.push_back(static_cast<uint8_t>(type_));
    
    switch (type_) {
        case DataType::INT32: {
            int32_t v = asInt32();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&v), 
                reinterpret_cast<uint8_t*>(&v) + sizeof(v));
            break;
        }
        case DataType::INT64:
        case DataType::TIMESTAMP: {
            int64_t v = asInt64();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&v), 
                reinterpret_cast<uint8_t*>(&v) + sizeof(v));
            break;
        }
        case DataType::FLOAT: {
            float v = asFloat();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&v), 
                reinterpret_cast<uint8_t*>(&v) + sizeof(v));
            break;
        }
        case DataType::DOUBLE: {
            double v = asDouble();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&v), 
                reinterpret_cast<uint8_t*>(&v) + sizeof(v));
            break;
        }
        case DataType::BOOLEAN: {
            buffer.push_back(asBool() ? 1 : 0);
            break;
        }
        case DataType::STRING: {
            const auto& s = asString();
            uint32_t len = s.size();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&len), 
                reinterpret_cast<uint8_t*>(&len) + sizeof(len));
            buffer.insert(buffer.end(), s.begin(), s.end());
            break;
        }
        case DataType::BLOB: {
            const auto& b = asBlob();
            uint32_t len = b.size();
            buffer.insert(buffer.end(), 
                reinterpret_cast<uint8_t*>(&len), 
                reinterpret_cast<uint8_t*>(&len) + sizeof(len));
            buffer.insert(buffer.end(), b.begin(), b.end());
            break;
        }
        default:
            break;
    }
    
    return buffer;
}

Value Value::deserialize(const uint8_t* data, size_t& offset) {
    DataType type = static_cast<DataType>(data[offset++]);
    
    switch (type) {
        case DataType::INT32: {
            int32_t v;
            std::memcpy(&v, data + offset, sizeof(v));
            offset += sizeof(v);
            return Value(v);
        }
        case DataType::INT64:
        case DataType::TIMESTAMP: {
            int64_t v;
            std::memcpy(&v, data + offset, sizeof(v));
            offset += sizeof(v);
            return Value(v);
        }
        case DataType::FLOAT: {
            float v;
            std::memcpy(&v, data + offset, sizeof(v));
            offset += sizeof(v);
            return Value(v);
        }
        case DataType::DOUBLE: {
            double v;
            std::memcpy(&v, data + offset, sizeof(v));
            offset += sizeof(v);
            return Value(v);
        }
        case DataType::BOOLEAN: {
            bool v = data[offset++] != 0;
            return Value(v);
        }
        case DataType::STRING: {
            uint32_t len;
            std::memcpy(&len, data + offset, sizeof(len));
            offset += sizeof(len);
            std::string s(reinterpret_cast<const char*>(data + offset), len);
            offset += len;
            return Value(s);
        }
        case DataType::BLOB: {
            uint32_t len;
            std::memcpy(&len, data + offset, sizeof(len));
            offset += sizeof(len);
            std::vector<uint8_t> b(data + offset, data + offset + len);
            offset += len;
            return Value(b);
        }
        default:
            return Value(int32_t(0));
    }
}

std::vector<uint8_t> Row::serialize() const {
    std::vector<uint8_t> buffer;
    
    uint32_t num_cols = columns_.size();
    buffer.insert(buffer.end(), 
        reinterpret_cast<uint8_t*>(&num_cols), 
        reinterpret_cast<uint8_t*>(&num_cols) + sizeof(num_cols));
    
    for (const auto& [name, value] : columns_) {
        uint32_t name_len = name.size();
        buffer.insert(buffer.end(), 
            reinterpret_cast<uint8_t*>(&name_len), 
            reinterpret_cast<uint8_t*>(&name_len) + sizeof(name_len));
        buffer.insert(buffer.end(), name.begin(), name.end());
        
        auto val_data = value.serialize();
        buffer.insert(buffer.end(), val_data.begin(), val_data.end());
    }
    
    return buffer;
}

Row Row::deserialize(const uint8_t* data, size_t size) {
    Row row;
    size_t offset = 0;
    
    uint32_t num_cols;
    std::memcpy(&num_cols, data + offset, sizeof(num_cols));
    offset += sizeof(num_cols);
    
    for (uint32_t i = 0; i < num_cols && offset < size; ++i) {
        uint32_t name_len;
        std::memcpy(&name_len, data + offset, sizeof(name_len));
        offset += sizeof(name_len);
        
        std::string name(reinterpret_cast<const char*>(data + offset), name_len);
        offset += name_len;
        
        Value value = Value::deserialize(data, offset);
        row.addColumn(name, std::move(value));
    }
    
    return row;
}

} // namespace kotana
