#pragma once

#include <vector>
#include <string>
#include <cstdint>
#include <cmath>
#include <functional>
#include <cstring>

namespace kotana {

class BloomFilter {
public:
    BloomFilter(size_t expected_elements, double false_positive_rate = 0.01)
        : num_elements_(0) {
        
        size_t m = optimal_num_bits(expected_elements, false_positive_rate);
        num_hashes_ = optimal_num_hashes(m, expected_elements);
        
        bits_.resize((m + 7) / 8, 0);
        num_bits_ = m;
    }
    
    void add(const std::string& key) {
        for (size_t i = 0; i < num_hashes_; ++i) {
            size_t hash = compute_hash(key, i);
            size_t bit_pos = hash % num_bits_;
            bits_[bit_pos / 8] |= (1 << (bit_pos % 8));
        }
        ++num_elements_;
    }
    
    bool mightContain(const std::string& key) const {
        for (size_t i = 0; i < num_hashes_; ++i) {
            size_t hash = compute_hash(key, i);
            size_t bit_pos = hash % num_bits_;
            if ((bits_[bit_pos / 8] & (1 << (bit_pos % 8))) == 0) {
                return false;
            }
        }
        return true;
    }
    
    void clear() {
        std::fill(bits_.begin(), bits_.end(), 0);
        num_elements_ = 0;
    }
    
    size_t size() const { return num_elements_; }
    size_t bitSize() const { return num_bits_; }
    
    const std::vector<uint8_t>& data() const { return bits_; }
    
    static BloomFilter deserialize(const std::vector<uint8_t>& data) {
        BloomFilter bf(1, 0.01);
        if (data.size() >= 16) {
            memcpy(&bf.num_bits_, data.data(), 8);
            memcpy(&bf.num_hashes_, data.data() + 8, 8);
            bf.bits_.assign(data.begin() + 16, data.end());
        }
        return bf;
    }
    
    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> result;
        result.reserve(16 + bits_.size());
        
        result.insert(result.end(), 
            reinterpret_cast<const uint8_t*>(&num_bits_), 
            reinterpret_cast<const uint8_t*>(&num_bits_) + 8);
        result.insert(result.end(), 
            reinterpret_cast<const uint8_t*>(&num_hashes_), 
            reinterpret_cast<const uint8_t*>(&num_hashes_) + 8);
        result.insert(result.end(), bits_.begin(), bits_.end());
        
        return result;
    }

private:
    static size_t optimal_num_bits(size_t n, double p) {
        return static_cast<size_t>(-n * std::log(p) / (std::log(2) * std::log(2)));
    }
    
    static size_t optimal_num_hashes(size_t m, size_t n) {
        return std::max(1UL, static_cast<size_t>(m / n * std::log(2)));
    }
    
    size_t compute_hash(const std::string& key, size_t seed) const {
        std::hash<std::string> hasher;
        size_t h = hasher(key);
        
        h ^= seed;
        h ^= h >> 33;
        h *= 0xff51afd7ed558ccdULL;
        h ^= h >> 33;
        h *= 0xc4ceb9fe1a85ec53ULL;
        h ^= h >> 33;
        
        return h;
    }
    
    std::vector<uint8_t> bits_;
    size_t num_bits_;
    size_t num_hashes_;
    size_t num_elements_;
};

} // namespace kotana
