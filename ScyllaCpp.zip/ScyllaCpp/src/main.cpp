#include "storage/storage_engine.h"
#include "network/server.h"
#include "query/executor.h"
#include <iostream>
#include <csignal>
#include <memory>
#include <thread>
#include <chrono>

using namespace kotana;

std::shared_ptr<Server> g_server;

void signalHandler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        std::cout << "\nShutting down Kotosploit Kotana server...\n";
        if (g_server) {
            g_server->stop();
        }
        exit(0);
    }
}

void printBanner() {
    std::cout << "\n";
    std::cout << "╔═══════════════════════════════════════════════════════════════════════╗\n";
    std::cout << "║                                                                       ║\n";
    std::cout << "║   _  __     _                  _       _ _     _  __     _            ║\n";
    std::cout << "║  | |/ /    | |                | |     (_) |   | |/ /    | |           ║\n";
    std::cout << "║  | ' / ___ | |_ ___  ___ _ __ | | ___  _| |_  | ' / ___ | |_ __ _ _ __║\n";
    std::cout << "║  |  < / _ \\| __/ _ \\/ __| '_ \\| |/ _ \\| | __| |  < / _ \\| __/ _` | '_ \\  \n";
    std::cout << "║  | . \\ (_) | || (_) \\__ \\ |_) | | (_) | | |_  | . \\ (_) | || (_| | | | |\n";
    std::cout << "║  |_|\\_\\___/ \\__\\___/|___/ .__/|_|\\___/|_|\\__| |_|\\_\\___/ \\__\\__,_|_| |_|\n";
    std::cout << "║                         | |                                           ║\n";
    std::cout << "║                         |_|                                           ║\n";
    std::cout << "║                                                                       ║\n";
    std::cout << "║              High-Performance Distributed Database System             ║\n";
    std::cout << "║                         Version 1.0.0                                 ║\n";
    std::cout << "║                                                                       ║\n";
    std::cout << "╚═══════════════════════════════════════════════════════════════════════╝\n";
    std::cout << "\n";
}

void printInfo() {
    std::cout << "System Information:\n";
    std::cout << "  CPU Cores:           " << std::thread::hardware_concurrency() << "\n";
    std::cout << "  Architecture:        Thread-per-core (ScyllaDB-inspired)\n";
    std::cout << "  Storage Engine:      LSM-Tree with MemTable & SSTable\n";
    std::cout << "  Query Language:      CQL-compatible\n";
    std::cout << "  Network Protocol:    Custom Binary Protocol\n";
    std::cout << "  Default Port:        9042\n";
    std::cout << "\n";
}

void printUsage(const char* program) {
    std::cout << "Usage: " << program << " [options]\n";
    std::cout << "\nOptions:\n";
    std::cout << "  --port <port>        Server port (default: 9042)\n";
    std::cout << "  --data-dir <path>    Data directory (default: ./data)\n";
    std::cout << "  --memtable-size <MB> MemTable size in MB (default: 64)\n";
    std::cout << "  --threads <n>        Number of worker threads (default: auto)\n";
    std::cout << "  --help               Show this help message\n";
    std::cout << "\n";
}

int main(int argc, char* argv[]) {
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);
    
    printBanner();
    
    StorageEngine::Config storage_config;
    Server::Config server_config;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        
        if (arg == "--help" || arg == "-h") {
            printUsage(argv[0]);
            return 0;
        } else if (arg == "--port" && i + 1 < argc) {
            server_config.port = std::atoi(argv[++i]);
        } else if (arg == "--data-dir" && i + 1 < argc) {
            storage_config.data_dir = argv[++i];
        } else if (arg == "--memtable-size" && i + 1 < argc) {
            storage_config.memtable_size = std::stoull(argv[++i]) * 1024 * 1024;
        } else if (arg == "--threads" && i + 1 < argc) {
            server_config.num_threads = std::stoull(argv[++i]);
        } else {
            std::cerr << "Unknown option: " << arg << "\n";
            printUsage(argv[0]);
            return 1;
        }
    }
    
    printInfo();
    
    std::cout << "Initializing Storage Engine...\n";
    auto storage = std::make_shared<StorageEngine>(storage_config);
    
    std::cout << "  Data Directory:      " << storage_config.data_dir << "\n";
    std::cout << "  MemTable Size:       " << (storage_config.memtable_size / 1024 / 1024) << " MB\n";
    std::cout << "  WAL Enabled:         " << (storage_config.enable_wal ? "Yes" : "No") << "\n";
    std::cout << "\n";
    
    std::cout << "Starting Network Server...\n";
    g_server = std::make_shared<Server>(storage, server_config);
    
    if (!g_server->start()) {
        std::cerr << "Failed to start server\n";
        return 1;
    }
    
    std::cout << "\n";
    std::cout << "╔═══════════════════════════════════════════════════════════════════╗\n";
    std::cout << "║  Kotosploit Kotana is ready to accept connections!               ║\n";
    std::cout << "║  Connect using: kotana_cli 127.0.0.1 " << server_config.port << "                        ║\n";
    std::cout << "╚═══════════════════════════════════════════════════════════════════╝\n";
    std::cout << "\n";
    
    while (g_server->isRunning()) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    
    storage->shutdown();
    
    std::cout << "Kotosploit Kotana shutdown complete.\n";
    
    return 0;
}
