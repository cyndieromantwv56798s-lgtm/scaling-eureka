#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <cstring>
#include <stdexcept>

namespace kotana {

enum class MessageType : uint8_t {
    QUERY_REQUEST = 1,
    QUERY_RESPONSE = 2,
    ERROR = 3,
    PING = 4,
    PONG = 5
};

struct Message {
    MessageType type;
    uint32_t payload_size;
    std::vector<uint8_t> payload;
    
    Message() : type(MessageType::PING), payload_size(0) {}
    Message(MessageType t, const std::vector<uint8_t>& p)
        : type(t), payload_size(p.size()), payload(p) {}
    Message(MessageType t, std::vector<uint8_t>&& p)
        : type(t), payload_size(p.size()), payload(std::move(p)) {}
    
    std::vector<uint8_t> serialize() const {
        std::vector<uint8_t> buffer;
        buffer.reserve(1 + 4 + payload_size);
        
        buffer.push_back(static_cast<uint8_t>(type));
        
        buffer.push_back((payload_size >> 24) & 0xFF);
        buffer.push_back((payload_size >> 16) & 0xFF);
        buffer.push_back((payload_size >> 8) & 0xFF);
        buffer.push_back(payload_size & 0xFF);
        
        buffer.insert(buffer.end(), payload.begin(), payload.end());
        
        return buffer;
    }
    
    static Message deserialize(const uint8_t* data, size_t size) {
        if (size < 5) {
            throw std::runtime_error("Invalid message size");
        }
        
        Message msg;
        msg.type = static_cast<MessageType>(data[0]);
        
        msg.payload_size = (static_cast<uint32_t>(data[1]) << 24) |
                          (static_cast<uint32_t>(data[2]) << 16) |
                          (static_cast<uint32_t>(data[3]) << 8) |
                          static_cast<uint32_t>(data[4]);
        
        if (size < 5 + msg.payload_size) {
            throw std::runtime_error("Incomplete message");
        }
        
        msg.payload.assign(data + 5, data + 5 + msg.payload_size);
        
        return msg;
    }
    
    std::string payloadAsString() const {
        return std::string(payload.begin(), payload.end());
    }
    
    static Message createQuery(const std::string& query) {
        std::vector<uint8_t> payload(query.begin(), query.end());
        return Message(MessageType::QUERY_REQUEST, std::move(payload));
    }
    
    static Message createResponse(const std::string& response) {
        std::vector<uint8_t> payload(response.begin(), response.end());
        return Message(MessageType::QUERY_RESPONSE, std::move(payload));
    }
    
    static Message createError(const std::string& error) {
        std::vector<uint8_t> payload(error.begin(), error.end());
        return Message(MessageType::ERROR, std::move(payload));
    }
    
    static Message createPing() {
        return Message(MessageType::PING, std::vector<uint8_t>());
    }
    
    static Message createPong() {
        return Message(MessageType::PONG, std::vector<uint8_t>());
    }
};

} // namespace kotana
