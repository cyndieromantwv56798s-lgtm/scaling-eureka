#pragma once

#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <memory>
#include <atomic>
#include <chrono>

namespace kotana {

template<typename Connection>
class ConnectionPool {
public:
    struct Config {
        size_t min_connections = 5;
        size_t max_connections = 100;
        uint64_t connection_timeout_ms = 5000;
        uint64_t idle_timeout_ms = 60000;
        bool validate_on_acquire = true;
        
        Config() = default;
    };
    
    using ConnectionFactory = std::function<std::shared_ptr<Connection>()>;
    using ConnectionValidator = std::function<bool(const std::shared_ptr<Connection>&)>;
    
    ConnectionPool(ConnectionFactory factory, 
                  ConnectionValidator validator,
                  const Config& config = Config())
        : factory_(factory),
          validator_(validator),
          config_(config),
          total_connections_(0),
          active_connections_(0),
          shutdown_(false) {
        
        for (size_t i = 0; i < config_.min_connections; ++i) {
            createConnection();
        }
    }
    
    ~ConnectionPool() {
        shutdown();
    }
    
    std::shared_ptr<Connection> acquire() {
        std::unique_lock<std::mutex> lock(mutex_);
        
        auto timeout = std::chrono::milliseconds(config_.connection_timeout_ms);
        auto deadline = std::chrono::steady_clock::now() + timeout;
        
        while (true) {
            if (shutdown_) {
                return nullptr;
            }
            
            if (!available_connections_.empty()) {
                auto conn = available_connections_.front();
                available_connections_.pop();
                
                if (!config_.validate_on_acquire || validator_(conn)) {
                    ++active_connections_;
                    return conn;
                } else {
                    --total_connections_;
                    continue;
                }
            }
            
            if (total_connections_ < config_.max_connections) {
                lock.unlock();
                auto conn = createConnection();
                lock.lock();
                
                if (conn) {
                    ++active_connections_;
                    return conn;
                }
            }
            
            if (std::chrono::steady_clock::now() >= deadline) {
                return nullptr;
            }
            
            cv_.wait_until(lock, deadline);
        }
    }
    
    void release(std::shared_ptr<Connection> conn) {
        if (!conn) return;
        
        std::unique_lock<std::mutex> lock(mutex_);
        
        if (shutdown_) {
            --total_connections_;
            --active_connections_;
            return;
        }
        
        if (validator_(conn)) {
            available_connections_.push(conn);
        } else {
            --total_connections_;
        }
        
        --active_connections_;
        cv_.notify_one();
    }
    
    void shutdown() {
        if (shutdown_.exchange(true)) {
            return;
        }
        
        std::unique_lock<std::mutex> lock(mutex_);
        
        while (!available_connections_.empty()) {
            available_connections_.pop();
        }
        
        total_connections_ = 0;
        active_connections_ = 0;
        
        cv_.notify_all();
    }
    
    size_t totalConnections() const { return total_connections_.load(); }
    size_t activeConnections() const { return active_connections_.load(); }
    size_t availableConnections() const {
        std::unique_lock<std::mutex> lock(mutex_);
        return available_connections_.size();
    }
    
    void getStats(std::map<std::string, uint64_t>& stats) const {
        stats["total_connections"] = total_connections_.load();
        stats["active_connections"] = active_connections_.load();
        stats["available_connections"] = availableConnections();
        stats["max_connections"] = config_.max_connections;
    }

private:
    std::shared_ptr<Connection> createConnection() {
        try {
            auto conn = factory_();
            if (conn) {
                ++total_connections_;
                return conn;
            }
        } catch (...) {
        }
        return nullptr;
    }
    
    ConnectionFactory factory_;
    ConnectionValidator validator_;
    Config config_;
    
    std::atomic<size_t> total_connections_;
    std::atomic<size_t> active_connections_;
    std::atomic<bool> shutdown_;
    
    std::queue<std::shared_ptr<Connection>> available_connections_;
    mutable std::mutex mutex_;
    std::condition_variable cv_;
};

class TCPConnection {
public:
    explicit TCPConnection(int socket_fd) 
        : socket_fd_(socket_fd), valid_(true) {}
    
    ~TCPConnection() {
        if (socket_fd_ >= 0) {
            close(socket_fd_);
        }
    }
    
    int socketFd() const { return socket_fd_; }
    bool isValid() const { return valid_; }
    void invalidate() { valid_ = false; }
    
    bool send(const std::vector<uint8_t>& data) {
        if (!valid_ || socket_fd_ < 0) return false;
        
        ssize_t sent = ::send(socket_fd_, data.data(), data.size(), 0);
        if (sent != static_cast<ssize_t>(data.size())) {
            valid_ = false;
            return false;
        }
        return true;
    }
    
    bool receive(std::vector<uint8_t>& data, size_t max_size = 8192) {
        if (!valid_ || socket_fd_ < 0) return false;
        
        data.resize(max_size);
        ssize_t received = recv(socket_fd_, data.data(), max_size, 0);
        
        if (received <= 0) {
            valid_ = false;
            return false;
        }
        
        data.resize(received);
        return true;
    }

private:
    int socket_fd_;
    bool valid_;
};

} // namespace kotana
