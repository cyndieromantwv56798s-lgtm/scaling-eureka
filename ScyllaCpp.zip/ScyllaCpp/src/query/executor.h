#pragma once

#include "ast.h"
#include "parser.h"
#include "core/types.h"
#include "storage/storage_engine.h"
#include <memory>
#include <map>
#include <string>
#include <mutex>

namespace kotana {

class QueryExecutor {
public:
    explicit QueryExecutor(std::shared_ptr<StorageEngine> storage)
        : storage_(storage) {}
    
    QueryResult execute(const std::string& query) {
        try {
            auto stmt = QueryParser::parse(query);
            return executeStatement(stmt);
        } catch (const std::exception& e) {
            return QueryResult::error(std::string("Parse error: ") + e.what());
        }
    }
    
    QueryResult executeStatement(std::shared_ptr<Statement> stmt) {
        switch (stmt->type()) {
            case StatementType::CREATE_TABLE:
                return executeCreate(std::static_pointer_cast<CreateTableStatement>(stmt));
            case StatementType::INSERT:
                return executeInsert(std::static_pointer_cast<InsertStatement>(stmt));
            case StatementType::SELECT:
                return executeSelect(std::static_pointer_cast<SelectStatement>(stmt));
            case StatementType::UPDATE:
                return executeUpdate(std::static_pointer_cast<UpdateStatement>(stmt));
            case StatementType::DELETE:
                return executeDelete(std::static_pointer_cast<DeleteStatement>(stmt));
            case StatementType::USE:
                return executeUse(std::static_pointer_cast<UseStatement>(stmt));
            default:
                return QueryResult::error("Unknown statement type");
        }
    }

private:
    QueryResult executeCreate(std::shared_ptr<CreateTableStatement> stmt) {
        std::lock_guard<std::mutex> lock(schema_mutex_);
        
        if (schemas_.find(stmt->table_name) != schemas_.end()) {
            return QueryResult::error("Table already exists: " + stmt->table_name);
        }
        
        TableSchema schema(stmt->table_name);
        for (const auto& col : stmt->columns) {
            schema.addColumn(col);
        }
        
        schemas_[stmt->table_name] = schema;
        
        return QueryResult::ok();
    }
    
    QueryResult executeInsert(std::shared_ptr<InsertStatement> stmt) {
        std::lock_guard<std::mutex> lock(schema_mutex_);
        
        auto it = schemas_.find(stmt->table_name);
        if (it == schemas_.end()) {
            return QueryResult::error("Table not found: " + stmt->table_name);
        }
        
        const TableSchema& schema = it->second;
        
        if (stmt->columns.size() != stmt->values.size()) {
            return QueryResult::error("Column count mismatch");
        }
        
        Row row;
        std::string partition_key;
        
        for (size_t i = 0; i < stmt->columns.size(); ++i) {
            const std::string& col_name = stmt->columns[i];
            const std::string& value_str = stmt->values[i];
            
            const ColumnDef* col_def = schema.findColumn(col_name);
            if (!col_def) {
                return QueryResult::error("Unknown column: " + col_name);
            }
            
            Value value = parseValue(value_str, col_def->type);
            row.addColumn(col_name, std::move(value));
            
            if (col_def->is_primary_key) {
                partition_key = value_str;
            }
        }
        
        if (partition_key.empty()) {
            return QueryResult::error("Primary key value required");
        }
        
        std::string storage_key = stmt->table_name + ":" + partition_key;
        
        if (!storage_->put(storage_key, row)) {
            return QueryResult::error("Failed to insert row");
        }
        
        return QueryResult::ok(1);
    }
    
    QueryResult executeSelect(std::shared_ptr<SelectStatement> stmt) {
        std::lock_guard<std::mutex> lock(schema_mutex_);
        
        auto it = schemas_.find(stmt->table_name);
        if (it == schemas_.end()) {
            return QueryResult::error("Table not found: " + stmt->table_name);
        }
        
        QueryResult result;
        result.success = true;
        
        if (!stmt->where_column.empty() && !stmt->where_value.empty()) {
            std::string storage_key = stmt->table_name + ":" + stmt->where_value;
            Row row;
            
            if (storage_->get(storage_key, row)) {
                result.rows.push_back(std::move(row));
            }
        }
        
        return result;
    }
    
    QueryResult executeUpdate(std::shared_ptr<UpdateStatement> stmt) {
        std::lock_guard<std::mutex> lock(schema_mutex_);
        
        auto it = schemas_.find(stmt->table_name);
        if (it == schemas_.end()) {
            return QueryResult::error("Table not found: " + stmt->table_name);
        }
        
        const TableSchema& schema = it->second;
        
        if (stmt->where_column.empty() || stmt->where_value.empty()) {
            return QueryResult::error("WHERE clause required for UPDATE");
        }
        
        std::string storage_key = stmt->table_name + ":" + stmt->where_value;
        Row row;
        
        if (!storage_->get(storage_key, row)) {
            return QueryResult::error("Row not found");
        }
        
        for (const auto& [col_name, value_str] : stmt->updates) {
            const ColumnDef* col_def = schema.findColumn(col_name);
            if (!col_def) {
                return QueryResult::error("Unknown column: " + col_name);
            }
            
            Value value = parseValue(value_str, col_def->type);
            row.addColumn(col_name, std::move(value));
        }
        
        if (!storage_->put(storage_key, row)) {
            return QueryResult::error("Failed to update row");
        }
        
        return QueryResult::ok(1);
    }
    
    QueryResult executeDelete(std::shared_ptr<DeleteStatement> stmt) {
        if (stmt->where_column.empty() || stmt->where_value.empty()) {
            return QueryResult::error("WHERE clause required for DELETE");
        }
        
        std::string storage_key = stmt->table_name + ":" + stmt->where_value;
        
        if (storage_->remove(storage_key)) {
            return QueryResult::ok(1);
        } else {
            return QueryResult::error("Row not found");
        }
    }
    
    QueryResult executeUse(std::shared_ptr<UseStatement> stmt) {
        current_keyspace_ = stmt->keyspace_name;
        return QueryResult::ok();
    }
    
    Value parseValue(const std::string& str, DataType type) {
        switch (type) {
            case DataType::INT32:
                return Value(static_cast<int32_t>(std::stoi(str)));
            case DataType::INT64:
                return Value(static_cast<int64_t>(std::stoll(str)));
            case DataType::FLOAT:
                return Value(std::stof(str));
            case DataType::DOUBLE:
                return Value(std::stod(str));
            case DataType::BOOLEAN:
                return Value(str == "true" || str == "TRUE" || str == "1");
            case DataType::STRING:
            default:
                return Value(str);
        }
    }
    
    std::shared_ptr<StorageEngine> storage_;
    std::map<std::string, TableSchema> schemas_;
    std::string current_keyspace_;
    std::mutex schema_mutex_;
};

} // namespace kotana
