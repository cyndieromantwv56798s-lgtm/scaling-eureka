#pragma once

#include "ast.h"
#include "core/types.h"
#include <memory>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

namespace kotana {

enum class AccessMethod {
    FULL_SCAN,
    INDEX_SCAN,
    PRIMARY_KEY_LOOKUP
};

struct QueryPlan {
    AccessMethod access_method;
    std::vector<std::string> selected_columns;
    std::string table_name;
    std::string index_name;
    
    std::vector<std::string> filter_columns;
    std::vector<Value> filter_values;
    
    int limit;
    bool has_aggregation;
    std::vector<std::string> group_by_columns;
    
    double estimated_cost;
    size_t estimated_rows;
    
    QueryPlan()
        : access_method(AccessMethod::FULL_SCAN),
          limit(-1),
          has_aggregation(false),
          estimated_cost(0.0),
          estimated_rows(0) {}
};

class QueryOptimizer {
public:
    struct TableStatistics {
        size_t row_count;
        size_t avg_row_size;
        std::map<std::string, size_t> column_cardinality;
        std::map<std::string, bool> has_index;
        
        TableStatistics()
            : row_count(0), avg_row_size(0) {}
    };
    
    QueryOptimizer() = default;
    
    QueryPlan optimize(std::shared_ptr<Statement> stmt) {
        switch (stmt->type()) {
            case StatementType::SELECT:
                return optimizeSelect(std::static_pointer_cast<SelectStatement>(stmt));
            case StatementType::INSERT:
                return optimizeInsert(std::static_pointer_cast<InsertStatement>(stmt));
            case StatementType::UPDATE:
                return optimizeUpdate(std::static_pointer_cast<UpdateStatement>(stmt));
            case StatementType::DELETE:
                return optimizeDelete(std::static_pointer_cast<DeleteStatement>(stmt));
            default:
                return QueryPlan();
        }
    }
    
    void updateStatistics(const std::string& table, const TableStatistics& stats) {
        statistics_[table] = stats;
    }
    
    const TableStatistics* getStatistics(const std::string& table) const {
        auto it = statistics_.find(table);
        return it != statistics_.end() ? &it->second : nullptr;
    }

private:
    QueryPlan optimizeSelect(std::shared_ptr<SelectStatement> stmt) {
        QueryPlan plan;
        plan.table_name = stmt->table_name;
        plan.limit = stmt->limit;
        
        if (stmt->select_all) {
            plan.access_method = AccessMethod::FULL_SCAN;
        } else {
            plan.selected_columns = stmt->columns;
        }
        
        if (!stmt->where_column.empty() && !stmt->where_value.empty()) {
            plan.filter_columns.push_back(stmt->where_column);
            plan.filter_values.push_back(Value(stmt->where_value));
            
            auto stats = getStatistics(stmt->table_name);
            if (stats && stats->has_index.count(stmt->where_column) > 0 &&
                stats->has_index.at(stmt->where_column)) {
                plan.access_method = AccessMethod::INDEX_SCAN;
                plan.index_name = stmt->where_column + "_idx";
            } else {
                plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
            }
        }
        
        plan.estimated_cost = estimateCost(plan);
        plan.estimated_rows = estimateRows(plan);
        
        return plan;
    }
    
    QueryPlan optimizeInsert(std::shared_ptr<InsertStatement> stmt) {
        QueryPlan plan;
        plan.table_name = stmt->table_name;
        plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
        plan.estimated_cost = 1.0;
        plan.estimated_rows = 1;
        return plan;
    }
    
    QueryPlan optimizeUpdate(std::shared_ptr<UpdateStatement> stmt) {
        QueryPlan plan;
        plan.table_name = stmt->table_name;
        
        if (!stmt->where_column.empty()) {
            plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
            plan.filter_columns.push_back(stmt->where_column);
            plan.filter_values.push_back(Value(stmt->where_value));
        } else {
            plan.access_method = AccessMethod::FULL_SCAN;
        }
        
        plan.estimated_cost = estimateCost(plan);
        plan.estimated_rows = estimateRows(plan);
        
        return plan;
    }
    
    QueryPlan optimizeDelete(std::shared_ptr<DeleteStatement> stmt) {
        QueryPlan plan;
        plan.table_name = stmt->table_name;
        
        if (!stmt->where_column.empty()) {
            plan.access_method = AccessMethod::PRIMARY_KEY_LOOKUP;
            plan.filter_columns.push_back(stmt->where_column);
            plan.filter_values.push_back(Value(stmt->where_value));
        } else {
            plan.access_method = AccessMethod::FULL_SCAN;
        }
        
        plan.estimated_cost = estimateCost(plan);
        plan.estimated_rows = estimateRows(plan);
        
        return plan;
    }
    
    double estimateCost(const QueryPlan& plan) const {
        auto stats = getStatistics(plan.table_name);
        if (!stats) {
            return 1000.0;
        }
        
        double cost = 0.0;
        
        switch (plan.access_method) {
            case AccessMethod::PRIMARY_KEY_LOOKUP:
                cost = 1.0;
                break;
            
            case AccessMethod::INDEX_SCAN:
                cost = std::log2(stats->row_count) + 1;
                break;
            
            case AccessMethod::FULL_SCAN:
                cost = stats->row_count * 1.0;
                break;
        }
        
        if (!plan.filter_columns.empty()) {
            cost *= 0.1;
        }
        
        if (plan.limit > 0 && plan.limit < static_cast<int>(stats->row_count)) {
            cost = std::min(cost, static_cast<double>(plan.limit));
        }
        
        return cost;
    }
    
    size_t estimateRows(const QueryPlan& plan) const {
        auto stats = getStatistics(plan.table_name);
        if (!stats) {
            return 1;
        }
        
        size_t estimated = stats->row_count;
        
        if (!plan.filter_columns.empty()) {
            for (const auto& col : plan.filter_columns) {
                auto it = stats->column_cardinality.find(col);
                if (it != stats->column_cardinality.end() && it->second > 0) {
                    estimated = estimated / it->second;
                } else {
                    estimated = estimated / 10;
                }
            }
        }
        
        if (plan.limit > 0) {
            estimated = std::min(estimated, static_cast<size_t>(plan.limit));
        }
        
        return std::max(estimated, size_t(1));
    }
    
    std::map<std::string, TableStatistics> statistics_;
};

class ExecutionContext {
public:
    ExecutionContext(const QueryPlan& plan)
        : plan_(plan), rows_processed_(0), bytes_processed_(0) {}
    
    const QueryPlan& plan() const { return plan_; }
    
    void incrementRowsProcessed() { ++rows_processed_; }
    void addBytesProcessed(size_t bytes) { bytes_processed_ += bytes; }
    
    size_t rowsProcessed() const { return rows_processed_; }
    size_t bytesProcessed() const { return bytes_processed_; }
    
    void setResult(const QueryResult& result) { result_ = result; }
    const QueryResult& result() const { return result_; }

private:
    QueryPlan plan_;
    size_t rows_processed_;
    size_t bytes_processed_;
    QueryResult result_;
};

} // namespace kotana
