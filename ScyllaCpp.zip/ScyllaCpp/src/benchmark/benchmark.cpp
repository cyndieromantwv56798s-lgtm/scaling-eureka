#include "storage/storage_engine.h"
#include "query/executor.h"
#include "core/types.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <vector>
#include <random>
#include <atomic>
#include <iomanip>
#include <algorithm>

using namespace kotana;

class Benchmark {
public:
    struct Config {
        size_t num_threads;
        size_t num_operations;
        size_t warmup_ops;
        double read_ratio;
        size_t key_range;
        bool verbose;
        
        Config() : num_threads(std::thread::hardware_concurrency()), num_operations(1000000),
                  warmup_ops(10000), read_ratio(0.5), key_range(1000000), verbose(true) {}
    };
    
    explicit Benchmark(std::shared_ptr<StorageEngine> storage) 
        : Benchmark(storage, Config()) {}
    
    explicit Benchmark(std::shared_ptr<StorageEngine> storage, const Config& config)
        : storage_(storage),
          executor_(std::make_shared<QueryExecutor>(storage)),
          config_(config),
          total_ops_(0),
          successful_ops_(0),
          failed_ops_(0) {}
    
    void run() {
        if (config_.verbose) {
            printHeader();
        }
        
        setupSchema();
        
        if (config_.verbose) {
            std::cout << "\n=== Warmup Phase ===\n";
        }
        warmup();
        
        if (config_.verbose) {
            std::cout << "\n=== Benchmark Phase ===\n";
        }
        
        auto start = std::chrono::high_resolution_clock::now();
        
        std::vector<std::thread> threads;
        size_t ops_per_thread = config_.num_operations / config_.num_threads;
        
        for (size_t i = 0; i < config_.num_threads; ++i) {
            threads.emplace_back(&Benchmark::workerThread, this, ops_per_thread, i);
        }
        
        for (auto& thread : threads) {
            thread.join();
        }
        
        auto end = std::chrono::high_resolution_clock::now();
        
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
        
        printResults(duration.count());
    }

private:
    void printHeader() {
        std::cout << "\n";
        std::cout << "╔══════════════════════════════════════════════════════════════╗\n";
        std::cout << "║       KOTOSPLOIT KOTANA PERFORMANCE BENCHMARK v1.0           ║\n";
        std::cout << "╚══════════════════════════════════════════════════════════════╝\n\n";
        std::cout << "Configuration:\n";
        std::cout << "  Threads:        " << config_.num_threads << "\n";
        std::cout << "  Operations:     " << config_.num_operations << "\n";
        std::cout << "  Read Ratio:     " << (config_.read_ratio * 100) << "%\n";
        std::cout << "  Write Ratio:    " << ((1.0 - config_.read_ratio) * 100) << "%\n";
        std::cout << "  Key Range:      " << config_.key_range << "\n";
    }
    
    void setupSchema() {
        std::string create_query = 
            "CREATE TABLE benchmark_table (id INT PRIMARY KEY, value STRING, timestamp INT64)";
        
        executor_->execute(create_query);
    }
    
    void warmup() {
        for (size_t i = 0; i < config_.warmup_ops; ++i) {
            std::string key = std::to_string(i);
            std::string insert_query = 
                "INSERT INTO benchmark_table (id, value, timestamp) VALUES (" + 
                key + ", 'warmup_value_" + key + "', " + std::to_string(i) + ")";
            
            executor_->execute(insert_query);
        }
        
        if (config_.verbose) {
            std::cout << "Warmup completed: " << config_.warmup_ops << " operations\n";
        }
    }
    
    void workerThread(size_t num_ops, size_t thread_id) {
        std::random_device rd;
        std::mt19937 gen(rd() + thread_id);
        std::uniform_int_distribution<> key_dist(0, config_.key_range - 1);
        std::uniform_real_distribution<> op_dist(0.0, 1.0);
        
        std::vector<uint64_t> latencies;
        latencies.reserve(num_ops);
        
        for (size_t i = 0; i < num_ops; ++i) {
            int key = key_dist(gen);
            bool is_read = op_dist(gen) < config_.read_ratio;
            
            auto start = std::chrono::high_resolution_clock::now();
            
            bool success = false;
            if (is_read) {
                std::string query = 
                    "SELECT * FROM benchmark_table WHERE id = " + std::to_string(key);
                auto result = executor_->execute(query);
                success = result.success;
            } else {
                std::string query = 
                    "INSERT INTO benchmark_table (id, value, timestamp) VALUES (" + 
                    std::to_string(key) + ", 'value_" + std::to_string(key) + 
                    "', " + std::to_string(i) + ")";
                auto result = executor_->execute(query);
                success = result.success;
            }
            
            auto end = std::chrono::high_resolution_clock::now();
            auto latency = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
            
            latencies.push_back(latency.count());
            
            if (success) {
                successful_ops_++;
            } else {
                failed_ops_++;
            }
            total_ops_++;
        }
        
        std::lock_guard<std::mutex> lock(latency_mutex_);
        all_latencies_.insert(all_latencies_.end(), latencies.begin(), latencies.end());
    }
    
    void printResults(uint64_t total_time_us) {
        double total_time_sec = total_time_us / 1000000.0;
        double ops_per_sec = total_ops_.load() / total_time_sec;
        
        std::sort(all_latencies_.begin(), all_latencies_.end());
        
        uint64_t p50 = all_latencies_[all_latencies_.size() * 50 / 100];
        uint64_t p95 = all_latencies_[all_latencies_.size() * 95 / 100];
        uint64_t p99 = all_latencies_[all_latencies_.size() * 99 / 100];
        uint64_t p999 = all_latencies_[all_latencies_.size() * 999 / 1000];
        
        uint64_t avg_latency = 0;
        for (auto lat : all_latencies_) {
            avg_latency += lat;
        }
        avg_latency /= all_latencies_.size();
        
        std::map<std::string, uint64_t> stats;
        storage_->getStats(stats);
        
        std::cout << "\n";
        std::cout << "╔══════════════════════════════════════════════════════════════╗\n";
        std::cout << "║                    BENCHMARK RESULTS                         ║\n";
        std::cout << "╚══════════════════════════════════════════════════════════════╝\n\n";
        
        std::cout << std::fixed << std::setprecision(2);
        
        std::cout << "Performance Metrics:\n";
        std::cout << "  Total Operations:     " << total_ops_.load() << "\n";
        std::cout << "  Successful Ops:       " << successful_ops_.load() << "\n";
        std::cout << "  Failed Ops:           " << failed_ops_.load() << "\n";
        std::cout << "  Total Time:           " << total_time_sec << " seconds\n";
        std::cout << "\n";
        std::cout << "  ┌─────────────────────────────────────────────────────────┐\n";
        std::cout << "  │  THROUGHPUT:  " << std::setw(12) << static_cast<int>(ops_per_sec) 
                  << " ops/sec                        │\n";
        std::cout << "  └─────────────────────────────────────────────────────────┘\n";
        std::cout << "\n";
        
        std::cout << "Latency Distribution (microseconds):\n";
        std::cout << "  Average:    " << std::setw(10) << avg_latency << " μs\n";
        std::cout << "  P50:        " << std::setw(10) << p50 << " μs\n";
        std::cout << "  P95:        " << std::setw(10) << p95 << " μs\n";
        std::cout << "  P99:        " << std::setw(10) << p99 << " μs\n";
        std::cout << "  P99.9:      " << std::setw(10) << p999 << " μs\n";
        std::cout << "  Min:        " << std::setw(10) << all_latencies_.front() << " μs\n";
        std::cout << "  Max:        " << std::setw(10) << all_latencies_.back() << " μs\n";
        std::cout << "\n";
        
        std::cout << "Storage Engine Stats:\n";
        std::cout << "  MemTable Size:        " << (stats["memtable_size"] / 1024) << " KB\n";
        std::cout << "  MemTable Entries:     " << stats["memtable_entries"] << "\n";
        std::cout << "  SSTable Count:        " << stats["sstable_count"] << "\n";
        std::cout << "  Total SSTable Size:   " << (stats["total_sstable_size"] / 1024) << " KB\n";
        std::cout << "\n";
        
        std::cout << "System Configuration:\n";
        std::cout << "  Thread Count:         " << config_.num_threads << "\n";
        std::cout << "  Hardware Threads:     " << std::thread::hardware_concurrency() << "\n";
        std::cout << "\n";
    }
    
    std::shared_ptr<StorageEngine> storage_;
    std::shared_ptr<QueryExecutor> executor_;
    Config config_;
    
    std::atomic<uint64_t> total_ops_;
    std::atomic<uint64_t> successful_ops_;
    std::atomic<uint64_t> failed_ops_;
    
    std::vector<uint64_t> all_latencies_;
    std::mutex latency_mutex_;
};

int main(int argc, char* argv[]) {
    StorageEngine::Config storage_config;
    storage_config.data_dir = "./bench_data";
    storage_config.memtable_size = 128 * 1024 * 1024;
    storage_config.enable_wal = false;
    
    auto storage = std::make_shared<StorageEngine>(storage_config);
    
    Benchmark::Config bench_config;
    
    if (argc > 1) {
        bench_config.num_operations = std::stoull(argv[1]);
    }
    if (argc > 2) {
        bench_config.num_threads = std::stoull(argv[2]);
    }
    if (argc > 3) {
        bench_config.read_ratio = std::stod(argv[3]);
    }
    
    Benchmark benchmark(storage, bench_config);
    benchmark.run();
    
    storage->shutdown();
    
    return 0;
}
